-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:23:31Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(n: number): (number, nil, number)
    table.insert(list, n)
    return n, nil, 99
end

local first = ("before%% {%*} after `%*"):format((true and mark)(1) + 2, not (true and mark)(2))
local second = ("zero\000%*\255"):format(-0)
print(first, #second, string.byte(second, 5, #second))
print(table.concat(list, ","))

local function report(...)
    print(select("#", ...), ...)
end

local literalString = ("%*"):format("literal")
local propagatedString = ("%*"):format("constant")
print(literalString, propagatedString)
print(("%d / %s"):format(3, "four"))
if replace_format then
    local original = string.format
    replace_format(function(value2, ...)
        print("format", value2, select("#", ...), ...)
        return "first", nil, "third", nil
    end)
    local scalar = ("a%*%%"):format(7 + (true and mark)(3))
    print("scalar", scalar)
    report(("b%*"):format(8))
    local a, b, c, d = ("c%*"):format(9)
    report(a, b, c, d);
    ("unused%*"):format(10)
    local stringArg = ("literal%*"):format("held")
    local propagated = ("propagated%*"):format("constant")
    print(stringArg, propagated)
    local function switch(): number
        replace_format(function(format, value)
            print("replacement", format, value)
            return "switched", "extra"
        end)
        return 11
    end

    local switched = ("late%*"):format((true and switch)() + 1)
    print(switched)
    replace_format(original)
end
local object = setmetatable({}, {
    __unm = function()
    table.insert(list, "unm")
    return "from metamethod"
end,
})
local result = ("%*"):format(-object)
print(result, table.concat(list, ","))
