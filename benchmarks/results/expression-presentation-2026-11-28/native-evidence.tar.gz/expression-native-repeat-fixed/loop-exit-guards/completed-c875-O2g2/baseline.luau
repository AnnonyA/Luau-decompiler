-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:23:30Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(name, value)
    table.insert(list, name)
    return value, nil, "extra"
end

local result: number = -1
local list2 = {}
for index = 1, 5 do
    local value = "left" .. index
    local value2 = index > 1
    table.insert(list, value)
    if not value2 then
        continue
    end
    local value3 = "right" .. index
    local value4 = index == 3
    table.insert(list, value3)
    if not value4 then
        continue
    end
    local function_ = function()
        return index
    end
    list2[#list2 + 1] = function_
    result = index
    break
end
print("pick", result, list2[1](), list2[1] == list2[1], table.concat(list, ","))
list = {}

local function pack(value)
    table.insert(list, "pack" .. value)
    return value, nil, value + 1, nil
end

local function selectItem(items)
    for _, value2 in items do
        local value3 = "try" .. value2
        local value = value2 > 2
        table.insert(list, value3)
        if not value then
            continue
        end
        table.insert(list, "chosen" .. value2)
        return (true and pack)(value2)
    end
    return false
end

local function report(...)
    print(select("#", ...), ...)
end

report((true and selectItem)({ 1, 2, 4, 8 }))
report((true and selectItem)({ 1, 2 }))
print(table.concat(list, ","))
list = {}
local count: number = 0
while count < 5 do
    count += 1
    local value5 = "while" .. count
    local value6 = count == 2
    table.insert(list, value5)
    if not value6 then
        continue
    end
    table.insert(list, "inside")
    break
end
print(count, "outside", table.concat(list, ","))
list = {}
count = 0
repeat
    count += 1
    local value7 = "repeat" .. count
    local value8 = count == 2
    table.insert(list, value7)
    if value8 then
        table.insert(list, "stopped")
        break
    end
    local value9 = "until" .. count
    value8 = count == 4
    table.insert(list, value7)
until value8
print(count, table.concat(list, ","))
list = {}

local function __lt(_, other)
    table.insert(list, "compare" .. other.n)
    return other.n == 2
end

local data = { __lt = 0 }
data.__lt = __lt
local a = setmetatable({}, data)
for i = 1, 3 do
    if a < setmetatable({ n = i }, data) then
        table.insert(list, "ordered")
        break
    end
end
table.insert(list, "nan")
print(table.concat(list, ","))
list = {}
local result6 = nil
for i2 = 1, 4 do
    if i2 ~= 3 then
        continue
    end
    result6 = function()
        return i2
    end

    table.insert(list, "captured" .. i2)
    break
end
print(result6(), table.concat(list, ","))

local function directReturn(items)
    for _, value2 in items do
        if value2 ~= 2 then
            continue
        end
        table.insert(list, "direct")
        return (true and pack)(value2)
    end
    return false
end

report((true and directReturn)({ 1, 2, 3 }))
print(table.concat(list, ","))
