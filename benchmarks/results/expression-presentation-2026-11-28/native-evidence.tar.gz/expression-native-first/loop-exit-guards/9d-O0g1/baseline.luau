-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:18:30Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(p, p2)
    (table.insert)(list, p)
    return p2, nil, "extra"
end

local i = -1
local list2 = {}
for i2 = 1, 5 do
    if (true and mark)("left" .. i2, i2 > 1) then
        if not (true and mark)("right" .. i2, i2 == 3) then
            continue
        end
        local i3 = i2
        local function_ = function()
            return i3
        end
        list2[#list2 + 1] = function_
        i = i2
        break
    end
end
print("pick", i, list2[1](), list2[1] == list2[1], (table.concat)(list, ","))
list = {}

local function pack(p)
    (table.insert)(list, "pack" .. p)
    return p, nil, p + 1, nil
end

local function selectItem(items)
    for _, value in items do
        if (true and mark)("try" .. value, value > 2) then
            (table.insert)(list, "chosen" .. value)
            return (true and pack)(value)
        end
    end
    return false
end

local function report(...)
    print(select("#", ...), ...)
end

report((true and selectItem)({ 1, 2, 4, 8 }))
report((true and selectItem)({ 1, 2 }))
print((table.concat)(list, ","))
list = {}
local count: number = 0
while count < 5 do
    count += 1
    if (true and mark)("while" .. count, count == 2) then
        (table.insert)(list, "inside")
        break
    end
end
print(count, "outside", (table.concat)(list, ","))
list = {}
count = 0
repeat
    count += 1
    local value2 = "repeat" .. count
    local result = count == 2
    local snapshot = result
    if (true and mark)(value2, snapshot) then
        (table.insert)(list, "stopped")
        break
    end
    local value3 = "until" .. count
    result = count == 4
until (true and mark)(value2, snapshot)(value2, result)
print(count, (table.concat)(list, ","))
list = {}
local setmetatable2 = setmetatable

local function __lt(p, p2)
    (table.insert)(list, "compare" .. p2.n)
    return p2.n == 2
end

local value4 = setmetatable2({}, { __lt = __lt })
for i4 = 1, 3 do
    if value4 < { n = i4 } then
        (table.insert)(list, "ordered")
        break
    end
end
local value5 = 0 / 0
for i5 = 1, 2 do
    if value5 < i5 then
        continue
    end;
    (table.insert)(list, "nan")
    break
end
print((table.concat)(list, ","))
