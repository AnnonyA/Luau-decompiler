-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:18:32Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(p, p2)
    table.insert(list, p)
    return p2, nil, "extra"
end

local i: number = -1
local list2 = {}
for i2 = 1, 5 do
    local value = "left" .. i2
    local result = i2 > 1
    table.insert(list, value)
    if not result then
        continue
    end
    local value2 = "right" .. i2
    local result2 = i2 == 3
    table.insert(list, value2)
    if not result2 then
        continue
    end
    local function_ = function()
        return i2
    end
    list2[#list2 + 1] = function_
    i = i2
    break
end
print("pick", i, list2[1](), list2[1] == list2[1], table.concat(list, ","))
list = {}

local function pack(p)
    table.insert(list, "pack" .. p)
    return p, nil, p + 1, nil
end

local function selectItem(items)
    for _, value in items do
        local value2 = "try" .. value
        local result = value > 2
        table.insert(list, value2)
        if not result then
            continue
        end
        table.insert(list, "chosen" .. value)
        return (true and pack)(value)
    end
    return false
end

local function report(...)
    print(select("#", ...), ...)
end

report((true and selectItem)({ 1, 2, 4, 8 }))
report((true and selectItem)({ 1, 2 }))
print(table.concat(list, ","))
list = {}
local count: number = 0
while count < 5 do
    count += 1
    local value3 = "while" .. count
    local result3 = count == 2
    table.insert(list, value3)
    if not result3 then
        continue
    end
    table.insert(list, "inside")
    break
end
print(count, "outside", table.concat(list, ","))
list = {}
count = 0
repeat
    count += 1
    local value4 = "repeat" .. count
    local result4 = count == 2
    table.insert(list, value4)
    if result4 then
        table.insert(list, "stopped")
        break
    end
    local value5 = "until" .. count
    result4 = count == 4
    table.insert(list, value4)
until result4
print(count, table.concat(list, ","))
list = {}

local function __lt(p, p2)
    table.insert(list, "compare" .. p2.n)
    return p2.n == 2
end

local data = { __lt = 0 }
data.__lt = __lt
local value6 = setmetatable({}, data)
for i3 = 1, 3 do
    if value6 < { n = i3 } then
        table.insert(list, "ordered")
        break
    end
end
table.insert(list, "nan")
print(table.concat(list, ","))
