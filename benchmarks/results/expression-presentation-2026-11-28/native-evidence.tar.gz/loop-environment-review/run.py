from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess
work=Path('/workspace/scratch/1c4124dc88e4/loop-environment-review')
root=work.parent; refs=Path('/workspace/scratch/eb5e4be57451')
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
candidate=work/'first-engine-dist'
shutil.copytree(root/'engine-expressions/dist',candidate)
baseline=root/'measurements/baseline-replay/engine-dist'
pins={'9d':refs/'reference-luau-ci','c875':refs/'reference-luau'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot={str(p.relative_to(candidate)):sha(p) for p in sorted(candidate.rglob('*.js'))}
(work/'first-engine-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
def check(entry):
    pin,profile=entry;folder=work/(pin+'-'+profile);folder.mkdir()
    compiler=pins[pin]/'build/release/luau-compile'
    host=root/'expression-native-first'/('run-bytecode-'+pin);commands=[]
    def run(command,name):
        command=list(map(str,command));p=subprocess.run(command,capture_output=True,timeout=30)
        (folder/(name+'.stdout')).write_bytes(p.stdout);(folder/(name+'.stderr')).write_bytes(p.stderr)
        commands.append({'command':command,'exitCode':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'})
        return p
    args=['--binary','-O'+profile[1],'-g'+profile[3]]
    original_compile=run([compiler,*args,work/'controls.luau'],'original-compile')
    original_bc=folder/'original.luauc';original_bc.write_bytes(original_compile.stdout)
    original=run([host,original_bc],'original')
    variants={}
    for label,dist in [('baseline',baseline),('candidate',candidate)]:
        decompiled=run([node,dist/'cli.js','decompile',original_bc],label+'-decompile')
        source=folder/(label+'.luau');source.write_bytes(decompiled.stdout)
        compiled=run([compiler,*args,source],label+'-compile')
        bc=folder/(label+'.luauc');bc.write_bytes(compiled.stdout)
        actual=run([host,bc],label+'-actual')
        variants[label]={'match':original_compile.returncode==original.returncode==decompiled.returncode==compiled.returncode==actual.returncode==0 and actual.stdout==original.stdout and actual.stderr==original.stderr,'stdout':actual.stdout.decode(),'stderr':actual.stderr.decode(),'codes':[decompiled.returncode,compiled.returncode,actual.returncode],'sourceSha256':sha(source)}
    (folder/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    return {'pin':pin,'profile':profile,'originalBytecodeSha256':sha(original_bc),'originalStdout':original.stdout.decode(),'variants':variants}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(check,[(pin,f'O{o}g{g}') for pin in pins for o in range(3) for g in [1,2]]))
summary={'kind':'independent-loop-environment-review','sourceSha256':sha(work/'controls.luau'),'rows':rows,'passed':{key:sum(row['variants'][key]['match'] for row in rows) for key in ['baseline','candidate']}}
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':summary['passed'],'rows':[{key:row[key] for key in ['pin','profile']}|{'baseline':row['variants']['baseline']['match'],'candidate':row['variants']['candidate']['match'],'codes':row['variants']['candidate']['codes']} for row in rows]},indent=2))
