from pathlib import Path
import json, hashlib, subprocess, concurrent.futures
root=Path('/workspace/scratch/1c4124dc88e4'); work=root/'interpolation-review'
refs=Path('/workspace/scratch/eb5e4be57451')
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
dists={'baseline':root/'measurements/baseline-replay/engine-dist','candidate':root/'expression-format-candidate/engine-dist'}
pins={'9d':refs/'reference-luau-ci','c875':refs/'reference-luau'}
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def run_case(entry):
 pin,profile=entry; folder=work/(pin+'-'+profile); folder.mkdir()
 compiler=pins[pin]/'build/release/luau-compile';host=root/'expression-native-first'/('run-bytecode-'+pin)
 def run(cmd,label):
  p=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=40)
  (folder/(label+'.stdout')).write_bytes(p.stdout);(folder/(label+'.stderr')).write_bytes(p.stderr)
  return p
 original=run([compiler,'--binary','-O'+profile[1],'-g'+profile[3],work/'controls.luau'],'original-compile')
 (folder/'original.luauc').write_bytes(original.stdout)
 expected=run([host,folder/'original.luauc'],'original')
 results={}
 for variant,dist in dists.items():
  printed=run([node,dist/'cli.js','decompile',folder/'original.luauc'],variant+'-decompile')
  (folder/(variant+'.luau')).write_bytes(printed.stdout)
  compiled=run([compiler,'--binary','-O'+profile[1],'-g'+profile[3],folder/(variant+'.luau')],variant+'-compile')
  (folder/(variant+'.luauc')).write_bytes(compiled.stdout)
  actual=run([host,folder/(variant+'.luauc')],variant+'-actual')
  results[variant]={'match':all(p.returncode==0 for p in [original,expected,printed,compiled,actual]) and expected.stdout==actual.stdout and expected.stderr==actual.stderr,
    'codes':[p.returncode for p in [original,expected,printed,compiled,actual]],'stdoutSha256':hashlib.sha256(actual.stdout).hexdigest(),
    'interpolations':printed.stdout.count(b'`'),'sourceSha256':hashlib.sha256(printed.stdout).hexdigest()}
 return {'pin':pin,'profile':profile,'originalStdoutSha256':hashlib.sha256(expected.stdout).hexdigest(),'variants':results}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 rows=list(pool.map(run_case,[(pin,f'O{o}g{g}') for pin in pins for o in range(3) for g in [1,2]]))
summary={'sourceSha256':sha(work/'controls.luau'),'rows':rows,'totals':{v:{'passed':sum(r['variants'][v]['match'] for r in rows),'total':len(rows)} for v in dists}}
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['totals']))
for r in rows:
 if not all(x['match'] for x in r['variants'].values()):print(json.dumps(r))
