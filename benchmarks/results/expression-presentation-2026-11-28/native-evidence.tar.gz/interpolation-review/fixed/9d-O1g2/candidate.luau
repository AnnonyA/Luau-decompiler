-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:21:25Z
-- Luau bytecode version: 14 | Luau type version: 3

local mode: number = 3
local list = {}

local function formatObserve(value, ...)
    local caller = debug.info(2, "n")
    local n = select("#", ...)
    local list2 = { caller, tostring(#value), tostring(n) }
    for index = 1, #value do
        table.insert(list2, tostring(string.byte(value, index)))
    end
    for index2 = 1, n do
        local value3 = select(index2, ...)
        local kind: string = type(value3)
        if kind == "function" then
            table.insert(list2, "fn:" .. debug.info(value3, "n"))
            continue
        end
        if kind == "table" then
            table.insert(list2, "table:" .. tostring(value3.marker))
            continue
        end
        table.insert(list2, kind .. ":" .. tostring(value3))
    end
    table.insert(list, table.concat(list2, "|"))
    if mode == 0 then
        return
    end
    if mode == 1 then
        return nil, false, 7
    end
    if mode == 2 then
        return false, nil, 7
    end
    return "replaced", nil, 7
end

replace_format(formatObserve)

local function probe1(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    return size
end

local function probe2(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    return size
end

local function probe3(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    return size
end

local function probe4(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    return size
end

local function probe5(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    return size
end

local function probe6(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    return size
end

local function probe7(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    return size
end

local function probe8(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    return size
end

local function probe9(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    return size
end

local function probe10(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    return size
end

local function probe11(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    return size
end

local function probe12(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    return size
end

local function probe13(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    return size
end

local function probe14(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    return size
end

local function probe15(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    return size
end

local function probe16(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    local value15 = `n{x + 15}`
    size += #value15
    return size
end

local function probe17(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    local value15 = `n{x + 15}`
    size += #value15
    local value16 = `n{x + 16}`
    size += #value16
    return size
end

local function probe18(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    local value15 = `n{x + 15}`
    size += #value15
    local value16 = `n{x + 16}`
    size += #value16
    local value17 = `n{x + 17}`
    size += #value17
    return size
end

local function probe19(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    local value15 = `n{x + 15}`
    size += #value15
    local value16 = `n{x + 16}`
    size += #value16
    local value17 = `n{x + 17}`
    size += #value17
    local value18 = `n{x + 18}`
    size += #value18
    return size
end

local function probe20(x: number)
    local size: number = 0
    local value0 = `n{x + 0}`
    size += #value0
    local value1 = `n{x + 1}`
    size += #value1
    local value2 = `n{x + 2}`
    size += #value2
    local value3 = `n{x + 3}`
    size += #value3
    local value4 = `n{x + 4}`
    size += #value4
    local value5 = `n{x + 5}`
    size += #value5
    local value6 = `n{x + 6}`
    size += #value6
    local value7 = `n{x + 7}`
    size += #value7
    local value8 = `n{x + 8}`
    size += #value8
    local value9 = `n{x + 9}`
    size += #value9
    local value10 = `n{x + 10}`
    size += #value10
    local value11 = `n{x + 11}`
    size += #value11
    local value12 = `n{x + 12}`
    size += #value12
    local value13 = `n{x + 13}`
    size += #value13
    local value14 = `n{x + 14}`
    size += #value14
    local value15 = `n{x + 15}`
    size += #value15
    local value16 = `n{x + 16}`
    size += #value16
    local value17 = `n{x + 17}`
    size += #value17
    local value18 = `n{x + 18}`
    size += #value18
    local value19 = `n{x + 19}`
    size += #value19
    return size
end

print((true and probe1)(3), (true and probe2)(3), (true and probe3)(3), (true and probe4)(3), (true and probe5)(3), (true and probe6)(3), (true and probe7)(3), (true and probe8)(3), (true and probe9)(3), (true and probe10)(3), (true and probe11)(3), (true and probe12)(3), (true and probe13)(3), (true and probe14)(3), (true and probe15)(3), (true and probe16)(3), (true and probe17)(3), (true and probe18)(3), (true and probe19)(3), (true and probe20)(3))
for index2 = 0, 3 do
    mode = index2
    local object = `%* \{ {({ marker = 11 })} }\000\255`
    local callback = `fn{function()
        return 17
    end}`
    local boolean = `b{true}`
    local integer = `number{(0/0)}`
    local missing = `nil{nil}`
    print("scalar", type(object), type(callback), type(boolean), type(integer), type(missing))
end
print(table.concat(list, "\n"))
