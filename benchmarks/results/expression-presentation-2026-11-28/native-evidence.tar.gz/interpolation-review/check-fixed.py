from pathlib import Path
import hashlib,json,subprocess,concurrent.futures
work=Path('/workspace/scratch/1c4124dc88e4/interpolation-review');root=work.parent;refs=Path('/workspace/scratch/eb5e4be57451')
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';dist=work/'fixed-engine-dist'
pins={'9d':refs/'reference-luau-ci','c875':refs/'reference-luau'}
def run_case(entry):
 pin,profile=entry;old=work/(pin+'-'+profile);folder=work/'fixed'/(pin+'-'+profile);folder.mkdir(parents=True)
 compiler=pins[pin]/'build/release/luau-compile';host=root/'expression-native-first'/('run-bytecode-'+pin)
 def run(cmd,label):
  p=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=40)
  (folder/(label+'.stdout')).write_bytes(p.stdout);(folder/(label+'.stderr')).write_bytes(p.stderr)
  return p
 printed=run([node,dist/'cli.js','decompile',old/'original.luauc'],'decompile')
 (folder/'candidate.luau').write_bytes(printed.stdout)
 compiled=run([compiler,'--binary','-O'+profile[1],'-g'+profile[3],folder/'candidate.luau'],'compile')
 (folder/'candidate.luauc').write_bytes(compiled.stdout)
 actual=run([host,folder/'candidate.luauc'],'actual')
 return {'pin':pin,'profile':profile,'match':all(p.returncode==0 for p in [printed,compiled,actual]) and actual.stdout==(old/'original.stdout').read_bytes() and actual.stderr==(old/'original.stderr').read_bytes(),'codes':[p.returncode for p in [printed,compiled,actual]],'originalInputSha256':hashlib.sha256((old/'original.luauc').read_bytes()).hexdigest(),'printedSourceSha256':hashlib.sha256(printed.stdout).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run_case,[(pin,f'O{o}g{g}') for pin in pins for o in range(3) for g in [1,2]]))
summary={'note':'Real fixed engine from immutable JS snapshot, same original input bytes as first independent failures.','passed':sum(x['match'] for x in rows),'total':len(rows),'rows':rows}
(work/'fixed-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
