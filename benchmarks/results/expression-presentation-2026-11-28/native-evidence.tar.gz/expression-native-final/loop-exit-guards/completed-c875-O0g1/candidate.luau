-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:24:25Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(p, p2)
    (table.insert)(list, p)
    return p2, nil, "extra"
end

local i = -1
local list2 = {}
for i2 = 1, 5 do
    if (true and mark)("left" .. i2, i2 > 1) then
        if not (true and mark)("right" .. i2, i2 == 3) then
            continue
        end
        local i3 = i2
        local function_ = function()
            return i3
        end
        list2[#list2 + 1] = function_
        i = i2
        break
    end
end
print("pick", i, list2[1](), list2[1] == list2[1], (table.concat)(list, ","))
list = {}

local function pack(p)
    (table.insert)(list, "pack" .. p)
    return p, nil, p + 1, nil
end

local function selectItem(items)
    for _, value in items do
        if (true and mark)("try" .. value, value > 2) then
            (table.insert)(list, "chosen" .. value)
            return (true and pack)(value)
        end
    end
    return false
end

local function report(...)
    print(select("#", ...), ...)
end

report((true and selectItem)({ 1, 2, 4, 8 }))
report((true and selectItem)({ 1, 2 }))
print((table.concat)(list, ","))
list = {}
local count: number = 0
while count < 5 do
    count += 1
    if (true and mark)("while" .. count, count == 2) then
        (table.insert)(list, "inside")
        break
    end
end
print(count, "outside", (table.concat)(list, ","))
list = {}
count = 0
repeat
    count += 1
    if (true and mark)("repeat" .. count, count == 2) then
        (table.insert)(list, "stopped")
        break
    end
    local value2 = "until" .. count
    local result = count == 4
until (true and mark)(value2, result)
print(count, (table.concat)(list, ","))
list = {}

local function __lt(p, p2)
    (table.insert)(list, "compare" .. p2.n)
    return p2.n == 2
end

local data = { __lt = 0 }
data["__lt"] = __lt
local value3 = setmetatable({}, data)
for i4 = 1, 3 do
    if value3 < setmetatable({ n = i4 }, data) then
        (table.insert)(list, "ordered")
        break
    end
end
local value4 = 0 / 0
for i5 = 1, 2 do
    if value4 < i5 then
        continue
    end;
    (table.insert)(list, "nan")
    break
end
print((table.concat)(list, ","))
list = {}
local result12 = nil
for i6 = 1, 4 do
    if i6 == 3 then
        result12 = function()
            return i6
        end;

        (table.insert)(list, "captured" .. i6)
        break
    end
end
print(result12(), (table.concat)(list, ","))

local function directReturn(items)
    for _, value in items do
        if value == 2 then
            (table.insert)(list, "direct")
            return (true and pack)(value)
        end
    end
    return false
end

report((true and directReturn)({ 1, 2, 3 }))
print((table.concat)(list, ","))
