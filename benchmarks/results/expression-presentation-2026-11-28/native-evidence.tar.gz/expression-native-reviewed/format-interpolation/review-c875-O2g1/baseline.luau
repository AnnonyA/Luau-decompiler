-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:26:48Z
-- Luau bytecode version: 14 | Luau type version: 3

local i: number = 3
local list = {}

local function formatObserve(list2, ...)
    local value = debug.info(2, "n")
    local count = select("#", ...)
    local list3 = { value, tostring(#list2), (tostring(count)) }
    for index = 1, #list2 do
        table.insert(list3, (tostring(string.byte(list2, index))))
    end
    for i2 = 1, count do
        local count2 = select(i2, ...)
        local typeName: string = type(count2)
        if typeName == "function" then
            table.insert(list3, "fn:" .. debug.info(count2, "n"))
            continue
        end
        if typeName == "table" then
            table.insert(list3, "table:" .. tostring(count2.marker))
            continue
        end
        table.insert(list3, typeName .. ":" .. tostring(count2))
    end
    table.insert(list, table.concat(list3, "|"))
    if i == 0 then
        return
    end
    if i == 1 then
        return nil, false, 7
    end
    if i == 2 then
        return false, nil, 7
    end
    return "replaced", nil, 7
end

replace_format(formatObserve)

local function probe1(p)
    local formatted = ("n%*"):format(p + 0)
    return 0 + #formatted
end

local function probe2(p)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    return value + #formatted2
end

local function probe3(p)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    return value2 + #formatted3
end

local function probe4(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    return value3 + #formatted4
end

local function probe5(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    return value4 + #formatted5
end

local function probe6(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    return value5 + #formatted6
end

local function probe7(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    return value6 + #formatted7
end

local function probe8(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    return value7 + #formatted8
end

local function probe9(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    return value8 + #formatted9
end

local function probe10(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    return value9 + #formatted10
end

local function probe11(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    return value10 + #formatted11
end

local function probe12(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    return value11 + #formatted12
end

local function probe13(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    return value12 + #formatted13
end

local function probe14(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    return value13 + #formatted14
end

local function probe15(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    return value14 + #formatted15
end

local function probe16(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    local value15 = value14 + #formatted15
    local formatted16 = ("n%*"):format(p + 15)
    return value15 + #formatted16
end

local function probe17(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    local value15 = value14 + #formatted15
    local formatted16 = ("n%*"):format(p + 15)
    local value16 = value15 + #formatted16
    local formatted17 = ("n%*"):format(p + 16)
    return value16 + #formatted17
end

local function probe18(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    local value15 = value14 + #formatted15
    local formatted16 = ("n%*"):format(p + 15)
    local value16 = value15 + #formatted16
    local formatted17 = ("n%*"):format(p + 16)
    local value17 = value16 + #formatted17
    local formatted18 = ("n%*"):format(p + 17)
    return value17 + #formatted18
end

local function probe19(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    local value15 = value14 + #formatted15
    local formatted16 = ("n%*"):format(p + 15)
    local value16 = value15 + #formatted16
    local formatted17 = ("n%*"):format(p + 16)
    local value17 = value16 + #formatted17
    local formatted18 = ("n%*"):format(p + 17)
    local value18 = value17 + #formatted18
    local formatted19 = ("n%*"):format(p + 18)
    return value18 + #formatted19
end

local function probe20(p: number)
    local formatted = ("n%*"):format(p + 0)
    local value = 0 + #formatted
    local formatted2 = ("n%*"):format(p + 1)
    local value2 = value + #formatted2
    local formatted3 = ("n%*"):format(p + 2)
    local value3 = value2 + #formatted3
    local formatted4 = ("n%*"):format(p + 3)
    local value4 = value3 + #formatted4
    local formatted5 = ("n%*"):format(p + 4)
    local value5 = value4 + #formatted5
    local formatted6 = ("n%*"):format(p + 5)
    local value6 = value5 + #formatted6
    local formatted7 = ("n%*"):format(p + 6)
    local value7 = value6 + #formatted7
    local formatted8 = ("n%*"):format(p + 7)
    local value8 = value7 + #formatted8
    local formatted9 = ("n%*"):format(p + 8)
    local value9 = value8 + #formatted9
    local formatted10 = ("n%*"):format(p + 9)
    local value10 = value9 + #formatted10
    local formatted11 = ("n%*"):format(p + 10)
    local value11 = value10 + #formatted11
    local formatted12 = ("n%*"):format(p + 11)
    local value12 = value11 + #formatted12
    local formatted13 = ("n%*"):format(p + 12)
    local value13 = value12 + #formatted13
    local formatted14 = ("n%*"):format(p + 13)
    local value14 = value13 + #formatted14
    local formatted15 = ("n%*"):format(p + 14)
    local value15 = value14 + #formatted15
    local formatted16 = ("n%*"):format(p + 15)
    local value16 = value15 + #formatted16
    local formatted17 = ("n%*"):format(p + 16)
    local value17 = value16 + #formatted17
    local formatted18 = ("n%*"):format(p + 17)
    local value18 = value17 + #formatted18
    local formatted19 = ("n%*"):format(p + 18)
    local value19 = value18 + #formatted19
    local formatted20 = ("n%*"):format(p + 19)
    return value19 + #formatted20
end

local print2 = print
local formatted = ("n%*"):format(3)
local value = 0 + #formatted
local formatted2 = ("n%*"):format(3)
local value2 = 0 + #formatted2
local formatted3 = ("n%*"):format(4)
local value3 = value2 + #formatted3
local formatted4 = ("n%*"):format(3)
local value4 = 0 + #formatted4
local formatted5 = ("n%*"):format(4)
local value5 = value4 + #formatted5
local formatted6 = ("n%*"):format(5)
print2(value, value3, value5 + #formatted6, (true and probe4)(3), (true and probe5)(3), (true and probe6)(3), (true and probe7)(3), (true and probe8)(3), (true and probe9)(3), (true and probe10)(3), (true and probe11)(3), (true and probe12)(3), (true and probe13)(3), (true and probe14)(3), (true and probe15)(3), (true and probe16)(3), (true and probe17)(3), (true and probe18)(3), (true and probe19)(3), ((true and probe20)(3)))
for i2 = 0, 3 do
    i = i2
    local formatted7 = ("%%* { %* }\000\255"):format({ marker = 11 })
    local formatted8 = ("fn%*"):format(function()
        return 17
    end)
    local formatted9 = ("b%*"):format(true)
    local formatted10 = ("number%*"):format((0/0))
    local formatted11 = ("nil%*"):format(nil)
    print("scalar", type(formatted7), type(formatted8), type(formatted9), type(formatted10), (type(formatted11)))
end
print(table.concat(list, "\n"))
