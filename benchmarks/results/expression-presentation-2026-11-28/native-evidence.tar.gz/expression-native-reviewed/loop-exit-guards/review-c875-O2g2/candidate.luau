-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:26:44Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(mode)
    local total: number = 0
    local function_ = function()
        return total
    end
    local result: number = -1
    local list = {}
    local function mark(name, value)
        table.insert(list, name .. ":" .. value .. ":" .. total)
        return value, nil, "ignored"
    end

    local list2 = {}
    repeat
        total += 1
        local cell = total
        local function_2 = function()
            return cell, total
        end
        if mode == 1 and total == 2 then
            cell += 100
            total += 10
            result = total
            list2[#list2 + 1] = function_2
            local value = total
            table.insert(list, "first" .. ":" .. value .. ":" .. total)
            break
        end
        if mode == 2 and total == 3 then
            cell += 200
            total += 20
            result = total
            list2[#list2 + 1] = function_2
            local value2 = total
            table.insert(list, "second" .. ":" .. value2 .. ":" .. total)
            break
        end
        list2[#list2 + 1] = function_2
        cell += 1
        local value3 = total
        table.insert(list, "until" .. ":" .. value3 .. ":" .. total)
    until value3 == 4
    local snapshot = total
    total += 1000
    return result, total, list2, table.concat(list, ",")
end

for index = 1, 3 do
    local selected, observed, saved, trace = (true and exercise)(index)
    print("repeat", index, selected, observed, trace)
    for key, value in saved do
        print("saved", key, value())
    end
end

local function shared(mode: number)
    local total: number = 0
    local function_3 = function()
        return total
    end
    local result5 = nil
    local list = {}
    for index2 = 1, 6 do
        if mode == 1 and index2 == 2 then
            total = index2 * 10
            result5 = function()
                return total, index2
            end

            table.insert(list, total)
            break
        end
        if mode == 2 and index2 == 4 then
            total = index2 * 10
            result5 = function()
                return total, index2
            end

            table.insert(list, total)
            break
        end
        total += 1
        table.insert(list, total)
    end
    local before = total
    total += 100
    if result5 then
        print("shared", mode, before, total, result5())
    else
        print("shared", mode, before, total, "none")
    end
    print(table.concat(list, ","))
end;

(true and shared)(1);
(true and shared)(2);
(true and shared)(3)
