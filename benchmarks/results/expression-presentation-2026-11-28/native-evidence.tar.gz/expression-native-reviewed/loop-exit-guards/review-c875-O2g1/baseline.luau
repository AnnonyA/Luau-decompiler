-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:26:44Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(p)
    local total: number = 0
    local function_ = function()
        return total
    end
    local result: number = -1
    local list = {}
    local function mark(p, p2)
        table.insert(list, p .. ":" .. p2 .. ":" .. total)
        return p2, nil, "ignored"
    end

    local list2 = {}
    repeat
        total += 1
        local total2 = total
        local function_2 = function()
            return total2, total
        end
        if p == 1 and total == 2 then
            total2 += 100
            total += 10
            result = total
            list2[#list2 + 1] = function_2
            local result2 = total
            table.insert(list, "first" .. ":" .. result2 .. ":" .. total)
            break
        end
        if p == 2 and total == 3 then
            total2 += 200
            total += 20
            result = total
            list2[#list2 + 1] = function_2
            local result3 = total
            table.insert(list, "second" .. ":" .. result3 .. ":" .. total)
            break
        end
        list2[#list2 + 1] = function_2
        total2 += 1
        local result4 = total
        table.insert(list, "until" .. ":" .. result4 .. ":" .. total)
    until result4 == 4
    total += 1000
    return result, total, list2, table.concat(list, ",")
end

for i = 1, 3 do
    local result, value, items, value2 = (true and exercise)(i)
    print("repeat", i, result, value, value2)
    for key, callback in items do
        print("saved", key, callback())
    end
end

local function shared(p: number)
    local total: number = 0
    local function_3 = function()
        return total
    end
    local result10 = nil
    local list = {}
    for i = 1, 6 do
        if p == 1 and i == 2 then
            total = i * 10
            result10 = function()
                return total, i
            end

            table.insert(list, total)
            break
        end
        if p == 2 and i == 4 then
            total = i * 10
            result10 = function()
                return total, i
            end

            table.insert(list, total)
            break
        end
        total += 1
        table.insert(list, total)
    end
    local result = total
    total += 100
    if result10 then
        print("shared", p, result, total, result10())
    else
        print("shared", p, result, total, "none")
    end
    print(table.concat(list, ","))
end;

(true and shared)(1);
(true and shared)(2);
(true and shared)(3)
