-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:19:21Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(p: number): (number, nil, number)
    table.insert(list, p)
    return p, nil, 99
end

local formatted = ("before%% {%*} after `%*"):format((true and mark)(1) + 2, not (true and mark)(2))
local formatted2 = ("zero\000%*\255"):format(-0)
print(formatted, #formatted2, string.byte(formatted2, 5, #formatted2))
print(table.concat(list, ","))

local function report(...)
    print(select("#", ...), ...)
end

local formatted3 = ("%*"):format("literal")
local formatted4 = ("%*"):format("constant")
print(formatted3, formatted4)
print(("%d / %s"):format(3, "four"))
if replace_format then
    local format = string.format
    replace_format(function(p, ...)
        print("format", p, select("#", ...), ...)
        return "first", nil, "third", nil
    end)
    local formatted5 = ("a%*%%"):format(7 + (true and mark)(3))
    print("scalar", formatted5)
    report(("b%*"):format(8))
    local formatted6, value, value2, value3 = ("c%*"):format(9)
    report(formatted6, value, value2, value3);
    ("unused%*"):format(10)
    local formatted7 = ("literal%*"):format("held")
    local formatted8 = ("propagated%*"):format("constant")
    print(formatted7, formatted8)
    local function switch(): number
        replace_format(function(p, p2)
            print("replacement", p, p2)
            return "switched", "extra"
        end)
        return 11
    end

    local formatted9 = ("late%*"):format((true and switch)() + 1)
    print(formatted9)
    replace_format(format)
end
local value4 = setmetatable({}, {
    __unm = function()
    table.insert(list, "unm")
    return "from metamethod"
end,
})
local formatted10 = ("%*"):format(-value4)
print(formatted10, table.concat(list, ","))
