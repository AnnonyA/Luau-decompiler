-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:19:18Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function mark(name, value)
    table.insert(list, name)
    return value, nil, "extra"
end

local result: number = -1
local list2 = {}
for index = 1, 5 do
    local value = "left" .. index
    if (true and mark)(value, index > 1) then
        if not (true and mark)("right" .. index, index == 3) then
            continue
        end
        local function_ = function()
            return index
        end
        list2[#list2 + 1] = function_
        result = index
        break
    end
end
print("pick", result, list2[1](), list2[1] == list2[1], table.concat(list, ","))
list = {}

local function pack(value)
    table.insert(list, "pack" .. value)
    return value, nil, value + 1, nil
end

local function selectItem(items)
    for _, value2 in items do
        if (true and mark)("try" .. value2, value2 > 2) then
            table.insert(list, "chosen" .. value2)
            return (true and pack)(value2)
        end
    end
    return false
end

local function report(...)
    print(select("#", ...), ...)
end

report((true and selectItem)({ 1, 2, 4, 8 }))
report((true and selectItem)({ 1, 2 }))
print(table.concat(list, ","))
list = {}
local count: number = 0
while count < 5 do
    count += 1
    if (true and mark)("while" .. count, count == 2) then
        table.insert(list, "inside")
        break
    end
end
print(count, "outside", table.concat(list, ","))
list = {}
count = 0
repeat
    count += 1
    local value2 = "repeat" .. count
    local result2 = count == 2
    local snapshot = result2
    if (true and mark)(value2, snapshot) then
        table.insert(list, "stopped")
        break
    end
    local value3 = "until" .. count
    result2 = count == 4
until (true and mark)(value2, snapshot)(value2, result2)
print(count, table.concat(list, ","))
list = {}

local function __lt(_, other)
    table.insert(list, "compare" .. other.n)
    return other.n == 2
end

local data = { __lt = 0 }
data.__lt = __lt
local a = setmetatable({}, data)
for i = 1, 3 do
    if a < setmetatable({ n = i }, data) then
        table.insert(list, "ordered")
        break
    end
end
for i2 = 1, 2 do
    if i2 > (0/0) then
        continue
    end
    table.insert(list, "nan")
    break
end
print(table.concat(list, ","))
list = {}
local result11 = nil
for i3 = 1, 4 do
    if i3 ~= 3 then
        continue
    end
    result11 = function()
        return i3
    end

    table.insert(list, "captured" .. i3)
    break
end
print(result11(), table.concat(list, ","))

local function directReturn(items)
    for _, value2 in items do
        if value2 ~= 2 then
            continue
        end
        table.insert(list, "direct")
        return (true and pack)(value2)
    end
    return false
end

report((true and directReturn)({ 1, 2, 3 }))
print(table.concat(list, ","))
