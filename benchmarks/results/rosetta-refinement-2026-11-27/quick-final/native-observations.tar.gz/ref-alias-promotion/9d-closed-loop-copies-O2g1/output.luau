-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:50Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}
for index = 1, 3 do
    local sharedCounter = index
    local snapshot = sharedCounter
    local function_ = function()
        return sharedCounter
    end
    local function bump()
        sharedCounter += 10
        return sharedCounter
    end

    sharedCounter += 10
    local index2 = sharedCounter
    local function_2 = function()
        return sharedCounter
    end
    sharedCounter += 10
    local function_3 = function()
        return snapshot, snapshot, index2, sharedCounter, sharedCounter
    end
    list[#list + 1] = function_3
    local sharedCounter2 = index * 100
    local snapshot2 = sharedCounter2
    local function bump2()
        sharedCounter2 += 1
        return sharedCounter2
    end

    sharedCounter2 += 1
    local function_4 = function()
        local value = sharedCounter2
        sharedCounter2 += 1
        return snapshot2, value, sharedCounter2
    end
    list[#list + 1] = function_4
end
for key, callback in list do
    print("closed", key, callback())
    print("again", key, callback())
end
