-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(p: boolean, p2: boolean)
    local total: number = 4
    local snapshot = total
    local function_ = function()
        return total
    end
    local list = {}
    local function condition(): boolean
        total += 3
        list[#list + 1] = "condition"
        return p2
    end

    if not p then
        if (true and condition)() then
            list[#list + 1] = "body"
            print("selected", snapshot, function_())
        end
    else
        list[#list + 1] = "body"
        print("selected", snapshot, function_())
    end
    print("state", p, p2, snapshot, function_(), table.concat(list, "/"))
end;

(true and exercise)(true, true);
(true and exercise)(false, true);
(true and exercise)(false, false)

local function nested(p: boolean, limit: number)
    local list = {}
    if not p then
        if limit > 0 then
            for i = 1, limit do
                local i2 = i
                local function_2 = function()
                    i2 += 1
                    return i2
                end
                list[#list + 1] = function_2
            end
        end
    else
        for i3 = 1, limit do
            local i4 = i3
            local function_3 = function()
                i4 += 1
                return i4
            end
            list[#list + 1] = function_3
        end
    end
    for _, callback in list do
        print("nested", callback(), callback())
    end
end;

(true and nested)(false, 3);
(true and nested)(true, 2);
(true and nested)(false, 0)
