-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:54Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make(ready)
    return {
        { ready = ready, beta = 8 },
        { abc = ready, beta = 8 },
        { x = ready, beta = 8 },
        { z = ready, beta = 8 },
        { epsilon = ready, beta = 8 },
        { alpha = ready, beta = 8 },
        { gamma = ready, beta = 8 },
        { delta = ready, beta = 8 },
        { one = ready, beta = 8 },
        { other = ready, beta = 8 },
        {
            first = ready,
            marker = 3,
            last = ready,
            tag = "tail",
        },
        { items = { ready }, size = 1 },
    }
end

local make2 = make

local function observe(p, items)
    for key, items2 in items do
        local list = {}
        for key2, value in items2 do
            list[#list + 1] = key2 .. ":" .. type(value)
        end
        print(p, key, table.concat(list, "|"))
    end
end

local list = { make2 };
(true and observe)("number", list[1](5));
(true and observe)("nil", list[1](nil));
(true and observe)("false", list[1](false))
