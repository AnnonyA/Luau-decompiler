-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:54Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make(value)
    local list = { value }
    local data = { ready = value, beta = 8 }
    local data2 = { abc = value, beta = 8 }
    local data3 = { x = value, beta = 8 }
    local data4 = { z = value, beta = 8 }
    local data5 = { epsilon = value, beta = 8 }
    local data6 = { alpha = value, beta = 8 }
    local data7 = { gamma = value, beta = 8 }
    return {
        data,
        data2,
        data3,
        data4,
        data5,
        data6,
        data7,
        { delta = value, beta = 8 },
        { one = value, beta = 8 },
        { other = value, beta = 8 },
        {
            first = value,
            marker = 3,
            last = value,
            tag = "tail",
        },
        { size = 1, items = list },
    }
end

local make2 = make

local function observe(label, values)
    for key, value in values do
        local list = {}
        for key2, value2 in value do
            list[#list + 1] = key2 .. ":" .. type(value2)
        end
        print(label, key, (table.concat)(list, "|"))
    end
end

local list = { make2 };
(true and observe)("number", list[1](5));
(true and observe)("nil", list[1](nil));
(true and observe)("false", list[1](false))
