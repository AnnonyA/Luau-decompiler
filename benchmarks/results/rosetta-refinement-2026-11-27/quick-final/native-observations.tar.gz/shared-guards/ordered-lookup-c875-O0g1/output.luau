-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(p, p2, p3, p4)
    local count: number = 0
    local setmetatable2 = setmetatable
    local list = {}
    local function __index(p, p4)
        count += 1
        list[#list + 1] = "read:" .. p4 .. ":" .. count
        return if count == 1 then p2 else p3
    end

    local data = { __index = 0 }
    data["__index"] = __index
    local value = setmetatable2({}, data)
    local list2 = {}
    local function choose()
        if value.target == nil or p4 < value.target then
            local value2 = #list2 + 1
            local tbl = {}
            tbl["value"] = p4
            tbl["label"] = p
            list2[value2] = tbl
            list[#list + 1] = "selected"
        end
    end

    local success = pcall(choose)
    print(p, success, count, #list2, (table.concat)(list, "/"))
end;

(true and exercise)("short", nil, nil, 2);
(true and exercise)("taken", 1, 9, 2);
(true and exercise)("skip", 1, 0, 2);
(true and exercise)("error", 1, nil, 2);
(true and exercise)("nan-left", 1, 9, 0 / 0);
(true and exercise)("nan-right", 1, 0 / 0, 2)

local function __lt(p, p2)
    print("comparison", p.value, p2.value)
    return p.value < p2.value
end

local data = { __lt = 0 }
data["__lt"] = __lt;
(true and exercise)("metamethod", setmetatable({ value = 1 }, data), setmetatable({ value = 7 }, data), setmetatable({ value = 3 }, data))
