-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function collect(items)
    local calls: number = 0
    local setmetatable2 = setmetatable
    local list = {}
    local function __index(p, p2)
        calls += 1
        list[#list + 1] = "r" .. p2
        return if p2 % 2 == 0 then nil else p2 + 1
    end

    local data = { __index = 0 }
    data["__index"] = __index
    local list2 = setmetatable2({}, data)
    local list3 = {}
    for _, value in items do
        if list2[value] == nil or value < list2[value] then
            list3[#list3 + 1] = { value = value, doubled = value * 2 }
            list[#list + 1] = "w" .. value
        end
    end
    local total: number = 0
    for _2, value2 in list3 do
        total += value2.doubled
    end
    return #list3, calls, (table.concat)(list, "/"), nil, total
end

print("loop", (true and collect)({ 1, 2, 3, 4 }))
print("empty", (true and collect)({}))
print("repeated", (true and collect)({ 2, 2, 1 }))
