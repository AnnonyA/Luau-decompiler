-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:54Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(first: boolean, final: boolean)
    local total: number = 4
    local saved = total
    local function_ = function()
        return total
    end
    local list = {}
    local function condition(): boolean
        total += 3
        list[#list + 1] = "condition"
        return final
    end

    if not first then
        total += 3
        list[#list + 1] = "condition"
        if final then
            list[#list + 1] = "body"
            print("selected", saved, total)
        end
    else
        list[#list + 1] = "body"
        print("selected", saved, total)
    end
    print("state", first, final, saved, total, table.concat(list, "/"))
end;

(true and exercise)(true, true);
(true and exercise)(false, true);
(true and exercise)(false, false)

local function nested(flag: boolean, limit: number)
    local list = {}
    if not flag then
        if limit > 0 then
            for index = 1, limit do
                local cell = index
                local function_2 = function()
                    cell += 1
                    return cell
                end
                list[#list + 1] = function_2
            end
        end
    else
        for index2 = 1, limit do
            local cell2 = index2
            local function_3 = function()
                cell2 += 1
                return cell2
            end
            list[#list + 1] = function_3
        end
    end
    for _, value2 in list do
        print("nested", value2(), value2())
    end
end;

(true and nested)(false, 3);
(true and nested)(true, 2)
for _, value in {} do
    print("nested", value(), value())
end
