-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function collect(values)
    local reads: number = 0
    local setmetatable2 = setmetatable
    local list = {}
    local function __index(_, key)
        reads += 1
        list[#list + 1] = "r" .. key
        return if key % 2 == 0 then nil else key + 1
    end

    local data = { __index = 0 }
    data["__index"] = __index
    local cost = setmetatable2({}, data)
    local list2 = {}
    for _, value in values do
        if cost[value] == nil or value < cost[value] then
            list2[#list2 + 1] = { value = value, doubled = value * 2 }
            list[#list + 1] = "w" .. value
        end
    end
    local total: number = 0
    for _2, value2 in list2 do
        total += value2.doubled
    end
    return #list2, reads, (table.concat)(list, "/"), nil, total
end

print("loop", (true and collect)({ 1, 2, 3, 4 }))
print("empty", (true and collect)({}))
print("repeated", (true and collect)({ 2, 2, 1 }))
