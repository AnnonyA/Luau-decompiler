-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:53Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(label, first, second, candidate)
    local reads: number = 0
    local setmetatable2 = setmetatable
    local list = {}
    local function __index(_, key)
        reads += 1
        list[#list + 1] = "read:" .. key .. ":" .. reads
        return if reads == 1 then first else second
    end

    local data = { __index = 0 }
    data["__index"] = __index
    local cost = setmetatable2({}, data)
    local list2 = {}
    local function choose()
        if cost.target == nil or candidate < cost.target then
            local value = #list2 + 1
            local tbl = {}
            tbl["value"] = candidate
            tbl["label"] = label
            list2[value] = tbl
            list[#list + 1] = "selected"
        end
    end

    local ok = pcall(choose)
    print(label, ok, reads, #list2, (table.concat)(list, "/"))
end;

(true and exercise)("short", nil, nil, 2);
(true and exercise)("taken", 1, 9, 2);
(true and exercise)("skip", 1, 0, 2);
(true and exercise)("error", 1, nil, 2);
(true and exercise)("nan-left", 1, 9, 0 / 0);
(true and exercise)("nan-right", 1, 0 / 0, 2)

local function __lt(a, b)
    print("comparison", a.value, b.value)
    return a.value < b.value
end

local data = { __lt = 0 }
data["__lt"] = __lt;
(true and exercise)("metamethod", setmetatable({ value = 1 }, data), setmetatable({ value = 7 }, data), setmetatable({ value = 3 }, data))
