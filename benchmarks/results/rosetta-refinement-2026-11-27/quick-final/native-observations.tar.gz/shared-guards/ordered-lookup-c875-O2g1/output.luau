-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:00:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(label: string, p, p2, p3)
    local count: number = 0
    local list = {}
    local function __index(p3, p4)
        count += 1
        list[#list + 1] = "read:" .. p4 .. ":" .. count
        return if count == 1 then p else p2
    end

    local data = { __index = 0 }
    data.__index = __index
    local object = setmetatable({}, data)
    local list2 = {}
    local function choose()
        if object.target == nil or p3 < object.target then
            list2[#list2 + 1] = { value = p3, label = label }
            list[#list + 1] = "selected"
        end
    end

    local success = pcall(choose)
    print(label, success, count, #list2, table.concat(list, "/"))
end;

(true and exercise)("short", nil, nil, 2);
(true and exercise)("taken", 1, 9, 2);
(true and exercise)("skip", 1, 0, 2);
(true and exercise)("error", 1, nil, 2);
(true and exercise)("nan-left", 1, 9, (0/0));
(true and exercise)("nan-right", 1, (0/0), 2)
local data = {}
data.__lt = function(p, p2)
    print("comparison", p.value, p2.value)
    return p.value < p2.value
end;

(true and exercise)("metamethod", setmetatable({ value = 1 }, data), setmetatable({ value = 7 }, data), (setmetatable({ value = 3 }, data)))
