from pathlib import Path
import datetime, hashlib, json, subprocess

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
FIXTURES = BASE / 'similarity-v2-locals/tests/fixtures/template-key-captures'
OUT = HERE / 'template-capture-sealed-initial'
OUT.mkdir(exist_ok=False)
ROSETTA = BASE / 'rosetta-research/target/release/rosetta'
NODE = Path('/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node')
PROFILES = ['O0g1', 'O1g1', 'O2g1', 'O0g2', 'O1g2', 'O2g2',
            'O0g1+x1', 'O1g1+x2', 'O2g1+x3', 'O0g2+x2', 'O1g2+x3', 'O2g2+x1']
ENGINES = {'before': HERE / 'template-quick-v3/engine-dist',
           'after': HERE / 'template-key-candidate-v2/engine-dist'}
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
commands = []

def run(args, stem):
    args = list(map(str, args))
    result = subprocess.run(args, capture_output=True, timeout=20)
    for stream in ['stdout', 'stderr']:
        with stem.with_suffix('.' + stream).open('xb') as f:
            f.write(getattr(result, stream))
    commands.append({'command': args, 'exitCode': result.returncode,
                     'stdout': str(stem.with_suffix('.stdout').relative_to(OUT)),
                     'stderr': str(stem.with_suffix('.stderr').relative_to(OUT))})
    with (OUT / 'commands.jsonl').open('a') as f:
        json.dump(commands[-1], f); f.write('\n')
    return result

manifest = {'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'compiler': 'Rosetta pinned Luau 0.747', 'compilerHostSha256': digest(ROSETTA),
            'profiles': PROFILES, 'sources': []}
results = []
for source in sorted(FIXTURES.glob('*.luau')):
    entry = {'name': source.stem, 'sourceSha256': digest(source), 'bytecodes': []}
    for profile in PROFILES:
        identity = source.stem + '-' + profile
        work = OUT / identity
        work.mkdir()
        binary = FIXTURES / (identity + '.luauc')
        assert not binary.exists()
        original_compile = run([ROSETTA, 'compile', source, '--profile', profile, '--output', binary], work / 'original-compile')
        if original_compile.returncode or not binary.exists():
            raise RuntimeError('Original compile failed: ' + identity)
        entry['bytecodes'].append({'profile': profile, 'path': binary.name, 'sha256': digest(binary)})
        original = run([ROSETTA, 'run', binary], work / 'original-run')
        original_returned = original.returncode == 0 and original.stdout.rstrip().endswith(b'-- Returned')
        for label, engine in ENGINES.items():
            decompiled = run([NODE, engine / 'cli.js', 'decompile', binary], work / (label + '-decompile'))
            recovered = work / (label + '.luau')
            with recovered.open('xb') as f: f.write(decompiled.stdout)
            compiled = work / (label + '.luauc')
            recompiled = run([ROSETTA, 'compile', recovered, '--profile', profile.split('+')[0], '--output', compiled], work / (label + '-compile'))
            observed = run([ROSETTA, 'run', compiled], work / (label + '-run')) if compiled.exists() else None
            recovered_returned = observed is not None and observed.returncode == 0 and observed.stdout.rstrip().endswith(b'-- Returned')
            stdout_same = observed is not None and original.stdout == observed.stdout
            stderr_same = observed is not None and original.stderr == observed.stderr
            row = {'source': source.stem, 'profile': profile, 'engine': label,
                   'inputSha256': digest(binary), 'recoveredSha256': digest(recovered),
                   'decompileExitCode': decompiled.returncode, 'compileExitCode': recompiled.returncode,
                   'originalReturned': original_returned, 'recoveredReturned': recovered_returned,
                   'stdoutByteExact': stdout_same, 'stderrByteExact': stderr_same,
                   'match': original_returned and recovered_returned and stdout_same and stderr_same
                            and decompiled.returncode == 0 and recompiled.returncode == 0}
            results.append(row)
            with (OUT / 'results.jsonl').open('a') as f:
                json.dump(row, f); f.write('\n')
    manifest['sources'].append(entry)
with (FIXTURES / 'manifest.json').open('x') as f: json.dump(manifest, f, indent=2); f.write('\n')
with (OUT / 'commands.json').open('x') as f: json.dump(commands, f, indent=2); f.write('\n')
summary = {'executionModel': 'same saved input bytes passed to engine and official VM',
           'profiles': len(results), 'matches': sum(row['match'] for row in results),
           'perEngine': {name: {'profiles': sum(row['engine'] == name for row in results),
                               'matches': sum(row['engine'] == name and row['match'] for row in results)} for name in ENGINES},
           'failures': [row for row in results if not row['match']], 'results': results}
with (OUT / 'summary.json').open('x') as f: json.dump(summary, f, indent=2); f.write('\n')
print(json.dumps({key: summary[key] for key in ['profiles', 'matches', 'perEngine', 'failures']}))
raise SystemExit(0 if summary['matches'] == summary['profiles'] else 1)
