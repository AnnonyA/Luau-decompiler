from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
REPO = BASE / 'similarity-v2-locals'
OUT = REPO / 'benchmarks/results/template-key-identity-2026-11-27'
OUT.mkdir(exist_ok=False)
digest = lambda data: hashlib.sha256(data).hexdigest()
file_digest = lambda path: digest(path.read_bytes())
compression = []


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def copy(name, path):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(path.read_bytes())


def compressed_data(name, raw, source):
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    assert gzip.decompress(packed) == raw
    with (OUT / name).open('xb') as stream:
        stream.write(packed)
    compression.append({'path': name, 'format': 'gzip', 'source': source,
                        'rawBytes': len(raw), 'rawSha256': digest(raw),
                        'compressedBytes': len(packed), 'compressedSha256': digest(packed),
                        'decompressedByteExact': True, 'gzipMtime': 0})


def compressed(name, path):
    compressed_data(name, path.read_bytes(), str(path))


def archive(name, roots):
    files = {}
    for prefix, root in roots:
        for path in sorted(root.rglob('*')) if root.is_dir() else [root]:
            if not path.is_file() or 'engine-dist' in path.parts:
                continue
            member = prefix + '/' + path.relative_to(root).as_posix() if root.is_dir() else prefix
            assert member not in files
            files[member] = path
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name_, path in sorted(files.items()):
            data = path.read_bytes()
            member = tarfile.TarInfo(name_)
            member.size, member.mtime, member.mode = len(data), 0, 0o644
            member.uid = member.gid = 0
            member.uname = member.gname = ''
            tar.addfile(member, io.BytesIO(data))
    packed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
    restored = gzip.decompress(packed)
    assert restored == raw.getvalue()
    with tarfile.open(fileobj=io.BytesIO(restored), mode='r:') as tar:
        assert set(tar.getnames()) == set(files)
        for member in tar:
            assert tar.extractfile(member).read() == files[member.name].read_bytes()
    with (OUT / name).open('xb') as stream:
        stream.write(packed)
    member_manifest = name.removesuffix('.tar.gz') + '.members.json.gz'
    members = [{'path': member, 'source': str(path), 'bytes': path.stat().st_size,
                'sha256': file_digest(path)} for member, path in sorted(files.items())]
    compressed_data(member_manifest, (json.dumps(members, indent=2) + '\n').encode(),
                    'Per-member paths, hashes, and sizes for ' + name)
    compression.append({'path': name, 'format': 'tar+gzip', 'rawBytes': len(restored),
                        'rawSha256': digest(restored), 'compressedBytes': len(packed),
                        'compressedSha256': digest(packed), 'gzipMtime': 0,
                        'decompressedByteExact': True, 'allMembersByteExact': True,
                        'memberCount': len(members), 'membersManifest': member_manifest})


def js_tree(path):
    result = hashlib.sha256()
    for file in sorted(path.rglob('*.js')):
        result.update(file.relative_to(path).as_posix().encode() + b'\0')
        result.update(hashlib.sha256(file.read_bytes()).digest())
    return result.hexdigest()


flat = {
    'authored-alias-first.json': 'template-key-alias-first/report.json',
    'saved-alias-first.json': 'template-key-sealed-initial/summary.json',
    'saved-alias-repaired.json': 'template-key-sealed-repaired-v1/summary.json',
    'saved-captures-first.json': 'template-capture-sealed-initial/summary.json',
    'saved-alias-final.json': 'template-key-sealed-final/summary.json',
    'saved-captures-final.json': 'template-key-capture-sealed-final/summary.json',
    'saved-prior-controls-final.json': 'template-key-old-sealed-final-v2/summary.json',
    'synthetic-ready-final.json': 'template-key-synthetic-final-v2/summary.json',
    'synthetic-special-keys-first-and-final.json': 'template-special-keys-first/summary.json',
    'native-pins-first.json': 'template-key-native-pins-first/summary.json',
    'native-pins-final.json': 'template-key-native-pins-final/summary.json',
    'direct-final-exits.json': 'template-key-direct-final-exits.json',
    'prior-loss-diagnosis.json': 'template-loss-diagnosis/summary.json',
    'quick-intermediate-provenance.json': 'template-key-quick-v1/summary.json',
    'quick-final-provenance.json': 'template-key-quick-final/summary.json',
}
for name, path in flat.items():
    copy(name, HERE / path)
for pattern in ['template-key-unit-v*.log', 'template-key-full-unit-v*.log', 'template-key-build-v*.log']:
    for path in sorted(HERE.glob(pattern)):
        copy('logs/' + path.name, path)
for name in ['template-key-quick-final.log', 'template-key-replay-v1.log', 'template-key-seal-first.log',
             'template-key-captures-first.log', 'template-native-final.log', 'template-special-keys-first.log',
             'recheck-template-old-final-v2.log', 'recheck-template-key-saved-final.log',
             'recheck-template-captures-final.log', 'verify-template-synthetic-final-v2.log']:
    copy('logs/' + name, HERE / name)
for label, name in [('intermediate', 'v1-comparison'), ('final', 'final-comparison'), ('versus-main', 'main-comparison')]:
    compressed('quick-' + label + '.json.gz', HERE / ('template-key-quick-' + name + '.json'))

runtime_roots = ['template-key-alias-first', 'template-key-sealed-initial', 'template-key-sealed-repaired-v1',
                 'template-capture-sealed-initial', 'template-key-old-sealed-final', 'template-key-old-sealed-final-v2',
                 'template-key-sealed-final', 'template-key-capture-sealed-final', 'template-key-synthetic-final',
                 'template-key-synthetic-final-v2', 'template-key-native-pins-first', 'template-key-native-pins-final',
                 'template-special-keys-first']
archive('raw-runtime-observations.tar.gz', [(name, HERE / name) for name in runtime_roots])
for label, name in [('intermediate', 'template-key-quick-v1'), ('final', 'template-key-quick-final')]:
    archive('raw-quick-' + label + '.tar.gz', [(name, HERE / name)])
review = BASE / 'similarity-v2-regions-probes'
archive('raw-layout-review.tar.gz', [(name, review / name)
        for name in ['key-layout-review-first', 'key-layout-review-roundtrip-first']])
for label, path in [('source-first', 'key-layout-review-first/first-observation.json'),
                    ('roundtrip-first', 'key-layout-review-roundtrip-first/first-observation.json'),
                    ('main-baseline', 'key-layout-review-roundtrip-first/baseline-observation.json')]:
    copy('layout-review-' + label + '.json', review / path)

scripts = ['seal-template-key-alias.py', 'seal-template-key-captures.py', 'recheck-template-key-saved.py',
           'recheck-template-key-saved-final.py', 'recheck-template-captures-final.py',
           'recheck-template-old-final.py', 'recheck-template-old-final-v2.py',
           'verify-template-synthetic-final.py', 'verify-template-synthetic-final-v2.py',
           'verify-template-native-pins.py', 'verify-template-native-pins-final.py',
           'verify-template-synthetic-keys.py', 'generate-template-synthetic-keys.mjs',
           'archive-template-key-evidence.py']
archive('reproduction-scripts.tar.gz', [(name, HERE / name) for name in scripts] +
        [('quality-research/' + name, BASE / 'quality-research' / name)
         for name in ['replay.py', 'compare-replay.py', 'summarize.py', 'decompile-jsonl.mjs']])

final = json.loads((HERE / 'template-key-quick-final/summary.json').read_text())
comparison = json.loads((HERE / 'template-key-quick-final-comparison.json').read_text())
main_comparison = json.loads((HERE / 'template-key-quick-main-comparison.json').read_text())
assert final['count'] == 882 and final['decompileFailures'] == 0
assert final['processExitCodes'] == {'node': 0, 'scorer': 0}
assert final['options'] == {} and final['query'] == ''
snapshot_hash = js_tree(HERE / 'template-key-candidate-v3/engine-dist')
assert snapshot_hash == final['jsTreeSha256'] == js_tree(REPO / 'dist')
unit = (HERE / 'template-key-full-unit-v2.log').read_text()
assert re.search(r'Tests\s+1600 passed \(1600\)', unit)
assert re.search(r'Test Files\s+148 passed \(148\)', unit)
runtime_summaries = {key: json.loads((HERE / folder / 'summary.json').read_text()) for key, folder in
                     [('prior', 'template-key-old-sealed-final-v2'), ('alias', 'template-key-sealed-final'),
                      ('captures', 'template-key-capture-sealed-final')]}
assert all(value['matches'] == value['profiles'] and value['originalObservationsUnchanged']
           for value in runtime_summaries.values())
native = json.loads((HERE / 'template-key-native-pins-final/summary.json').read_text())
special = json.loads((HERE / 'template-special-keys-first/summary.json').read_text())
assert all(value['after'] == {'profiles': 36, 'matches': 36} for value in native['perPinEngine'].values())
assert all(value['after'] == {'profiles': 12, 'matches': 12} for value in special['perHostEngine'].values())
save('validation.json', {
    'unit': {'passed': 1600, 'total': 1600, 'passedFiles': 148, 'totalFiles': 148,
             'completeFooterObserved': True, 'log': 'logs/template-key-full-unit-v2.log'},
    'authoredSavedInputs': {'sources': 5, 'profiles': 60, 'matches': 60,
                          'normalAndHardAuthoredProfiles': True, 'originalObservationsUnchanged': True},
    'nativePins': native['perPinEngine'], 'specialKeys': special['perHostEngine'],
    'runtimeContract': 'Compile/decompile/recompile success, normal VM return, and byte-exact stdout/stderr.',
    'firstAliasSourceCheck': {'pass': 4, 'mismatch': 8, 'total': 12},
    'firstAliasDirectBytecode': {'beforeMatches': 4, 'afterMatches': 4, 'totalPerEngine': 12},
    'firstCaptureDirectBytecode': {'beforeMatches': 4, 'afterMatches': 12, 'totalPerEngine': 12},
    'knownPreexistingLayoutFailure': {'solved': False, 'mainAndIntermediateMatchOriginal': False,
                                     'profiles': 6, 'pins': 2,
                                     'evidence': 'layout-review-main-baseline.json'},
    'quickDiagnostic': {'behaviorVerified': False, 'profiles': 882, **comparison['overall'],
                        'changedProfiles': comparison['changedProfiles']},
    'quickVersusMain': main_comparison['overall'],
    'strictQuickGate': 'Parent integration owns strict Quick; this replay is a source-quality diagnostic only.',
    'scope': 'Full and Hard benchmark tiers paused by the user; no new Full/Hard benchmark run in this continuation.',
})
save('source-files.json', {str(path.relative_to(REPO)): file_digest(path)
                          for path in sorted((REPO / 'src').rglob('*.ts'))})
save('fixture-files.json', {str(path.relative_to(REPO)): file_digest(path)
                           for folder in ['template-key-alias', 'template-key-captures']
                           for path in sorted((REPO / 'tests/fixtures' / folder).rglob('*')) if path.is_file()})
save('provenance.json', {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'semanticBaselineCommit': 'ea133e3211f1dd8334ab87805de97971b188fee6',
    'publishedMainBaseline': '36a344eeed74d194723e6f32a0ef7d699fac550f',
    'engineJsTrees': {name: js_tree(HERE / folder / 'engine-dist') for name, folder in
                     [('baseline', 'template-quick-v3'), ('firstKeyOnly', 'template-key-candidate-v1'),
                      ('functionGuards', 'template-key-candidate-v2'), ('final', 'template-key-candidate-v3')]},
    'treeHashAlgorithm': final['treeHashAlgorithm'], 'node': final['node'], 'options': {}, 'query': '',
    'compilerHostSha256': file_digest(BASE / 'rosetta-research/target/release/rosetta'),
    'corpusChanged': False, 'scorerChanged': False, 'runnerChanged': False, 'validatorChanged': False,
    'references': {'Tovek': 'ce2ea3325547fa3896f274b68013386338039040',
                   'LuauPins': [value['revision'] for value in native['pins'].values()],
                   'Rosetta': '80f3c13ce48dc3318d5d49f54958f580937ca8aa', 'RosettaLuau': '0.747'},
    'implementation': 'Independent TypeScript implementation; no competitor source copied.',
    'review': {'agent': 'similarity_structure', 'result': 'No remaining blocker within the one-slot reservation scope.',
               'limitation': 'General NEWTABLE allocation/layout recovery remains a separate preexisting defect.'},
})
save('compressed-files.json', {'format': 'lossless-evidence-manifest-v1', 'files': compression})
print(json.dumps({'directory': str(OUT), 'archiveCount': len(compression),
                  'archiveBytes': sum(item['compressedBytes'] for item in compression),
                  'quickSimilarity': final['quality']['similarity']}, indent=2))
