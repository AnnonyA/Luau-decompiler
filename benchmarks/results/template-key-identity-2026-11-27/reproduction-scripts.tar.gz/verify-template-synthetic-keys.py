from pathlib import Path
import hashlib, json, subprocess

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
FIXTURES = BASE / 'similarity-v2-locals/tests/fixtures/template-key-alias'
OUT = HERE / 'template-special-keys-first'
OUT.mkdir(exist_ok=False)
NODE = Path('/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node')
ROSETTA = BASE / 'rosetta-research/target/release/rosetta'
ENGINES = {'before': HERE / 'template-key-candidate-v2/engine-dist', 'after': HERE / 'template-key-candidate-v3/engine-dist'}
HOSTS = {'rosetta747': (ROSETTA, [ROSETTA, 'run']),
         '9d7748a4': (BASE / 'reference-luau-ci/build/release/luau-compile', [BASE / 'quality-research/v2-call-boundary-probe/run-bytecode-9d']),
         'c87565b8': (BASE / 'reference-luau/build/release/luau-compile', [BASE / 'quality-research/v2-call-boundary-probe/run-bytecode-c875'])}
PROFILES = ['O0g1', 'O1g1', 'O2g1', 'O0g2', 'O1g2', 'O2g2']
manifest = json.loads((FIXTURES / 'synthetic-keys.json').read_text())
commands, results = [], []
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def run(args, stem):
    args = list(map(str, args))
    result = subprocess.run(args, capture_output=True, timeout=20)
    for stream in ['stdout', 'stderr']:
        with stem.with_suffix('.' + stream).open('xb') as f: f.write(getattr(result, stream))
    commands.append({'command': args, 'exitCode': result.returncode,
                     'stdout': str(stem.with_suffix('.stdout').relative_to(OUT)),
                     'stderr': str(stem.with_suffix('.stderr').relative_to(OUT))})
    return result

for label, (compiler, host) in HOSTS.items():
    for entry in manifest['entries']:
        binary = FIXTURES / entry['bytecode']
        assert digest(binary) == entry['sha256']
        work = OUT / label / entry['name']
        work.mkdir(parents=True)
        original = run([*host, binary], work / 'original-run')
        original_normal = original.returncode == 0 and (label != 'rosetta747' or original.stdout.rstrip().endswith(b'-- Returned'))
        for engine_name, engine in ENGINES.items():
            decompiled = run([NODE, engine / 'cli.js', 'decompile', binary], work / (engine_name + '-decompile'))
            source = work / (engine_name + '.luau')
            with source.open('xb') as f: f.write(decompiled.stdout)
            for profile in PROFILES:
                recovered = work / (engine_name + '-' + profile + '.luauc')
                if label == 'rosetta747':
                    compiled = run([compiler, 'compile', source, '--profile', profile, '--output', recovered], work / (engine_name + '-' + profile + '-compile'))
                else:
                    compiled = run([compiler, '--binary', '-O' + profile[1], '-g' + profile[3], source], work / (engine_name + '-' + profile + '-compile'))
                    with recovered.open('xb') as f: f.write(compiled.stdout)
                observed = run([*host, recovered], work / (engine_name + '-' + profile + '-run'))
                normal = observed.returncode == 0 and (label != 'rosetta747' or observed.stdout.rstrip().endswith(b'-- Returned'))
                results.append({'host': label, 'keyKind': entry['name'], 'key': entry['key'], 'engine': engine_name,
                                'recompileProfile': profile, 'inputSha256': entry['sha256'],
                                'originalNormalReturn': original_normal, 'recoveredNormalReturn': normal,
                                'stdoutByteExact': original.stdout == observed.stdout, 'stderrByteExact': original.stderr == observed.stderr,
                                'match': original_normal and normal and decompiled.returncode == 0 and compiled.returncode == 0
                                         and original.stdout == observed.stdout and original.stderr == observed.stderr})
summary = {'inputs': 2, 'recompileProfiles': PROFILES,
           'hosts': {label: {'compilerSha256': digest(pair[0]), 'hostSha256': digest(pair[1][0])} for label, pair in HOSTS.items()},
           'perHostEngine': {label: {engine: {'profiles': sum(r['host'] == label and r['engine'] == engine for r in results),
                                             'matches': sum(r['host'] == label and r['engine'] == engine and r['match'] for r in results)}
                                     for engine in ENGINES} for label in HOSTS},
           'results': results, 'failures': [row for row in results if not row['match']]}
with (OUT / 'summary.json').open('x') as f: json.dump(summary, f, indent=2); f.write('\n')
with (OUT / 'commands.json').open('x') as f: json.dump(commands, f, indent=2); f.write('\n')
print(json.dumps({'perHostEngine': summary['perHostEngine'], 'failures': summary['failures']}))
raise SystemExit(0 if all(row['match'] for row in results if row['engine'] == 'after') else 1)
