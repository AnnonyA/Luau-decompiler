from pathlib import Path
import hashlib, json, subprocess

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
REPO = BASE / 'similarity-v2-locals'
OUT = HERE / 'template-key-native-pins-final'
OUT.mkdir(exist_ok=False)
NODE = Path('/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node')
ENGINES = {'before': HERE / 'template-quick-v3/engine-dist', 'after': HERE / 'template-key-candidate-v3/engine-dist'}
PINS = {'9d7748a4': (BASE / 'reference-luau-ci', BASE / 'quality-research/v2-call-boundary-probe/run-bytecode-9d'),
        'c87565b8': (BASE / 'reference-luau', BASE / 'quality-research/v2-call-boundary-probe/run-bytecode-c875')}
PROFILES = ['O0g1', 'O1g1', 'O2g1', 'O0g2', 'O1g2', 'O2g2']
SOURCES = sorted(path for folder in ['single-template-field', 'template-key-alias', 'template-key-captures']
                 for path in (REPO / 'tests/fixtures' / folder).glob('*.luau'))
assert len(SOURCES) == 5
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
commands, results, pins = [], [], {}

def run(args, stem):
    args = list(map(str, args))
    result = subprocess.run(args, capture_output=True, timeout=20)
    for stream in ['stdout', 'stderr']:
        with stem.with_suffix('.' + stream).open('xb') as f: f.write(getattr(result, stream))
    row = {'command': args, 'exitCode': result.returncode,
           'stdout': str(stem.with_suffix('.stdout').relative_to(OUT)),
           'stderr': str(stem.with_suffix('.stderr').relative_to(OUT))}
    commands.append(row)
    with (OUT / 'commands.jsonl').open('a') as f: json.dump(row, f); f.write('\n')
    return result

for label, (tree, host) in PINS.items():
    compiler = tree / 'build/release/luau-compile'
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
    assert revision.startswith(label)
    pins[label] = {'revision': revision, 'compilerSha256': digest(compiler), 'hostSha256': digest(host),
                   'hostContract': 'run_bytecode.cpp returns 0 only after luau_load succeeds and lua_pcall returns LUA_OK'}
    for source in SOURCES:
        for profile in PROFILES:
            work = OUT / label / source.stem / profile
            work.mkdir(parents=True)
            flags = ['-O' + profile[1], '-g' + profile[3]]
            compiled = run([compiler, '--binary', *flags, source], work / 'original-compile')
            original_file = work / 'original.luauc'
            with original_file.open('xb') as f: f.write(compiled.stdout)
            original = run([host, original_file], work / 'original-run')
            for engine_name, engine in ENGINES.items():
                decompiled = run([NODE, engine / 'cli.js', 'decompile', original_file], work / (engine_name + '-decompile'))
                recovered = work / (engine_name + '.luau')
                with recovered.open('xb') as f: f.write(decompiled.stdout)
                recompiled = run([compiler, '--binary', *flags, recovered], work / (engine_name + '-compile'))
                recovered_file = work / (engine_name + '.luauc')
                with recovered_file.open('xb') as f: f.write(recompiled.stdout)
                observed = run([host, recovered_file], work / (engine_name + '-run'))
                row = {'pin': label, 'source': source.stem, 'profile': profile, 'engine': engine_name,
                       'sourceSha256': digest(source), 'inputSha256': digest(original_file),
                       'originalNormalReturn': original.returncode == 0, 'recoveredNormalReturn': observed.returncode == 0,
                       'stdoutByteExact': original.stdout == observed.stdout, 'stderrByteExact': original.stderr == observed.stderr,
                       'match': compiled.returncode == 0 and original.returncode == 0 and decompiled.returncode == 0
                                and recompiled.returncode == 0 and observed.returncode == 0
                                and original.stdout == observed.stdout and original.stderr == observed.stderr}
                results.append(row)
                with (OUT / 'results.jsonl').open('a') as f: json.dump(row, f); f.write('\n')
    synthetic = REPO / 'tests/fixtures/single-template-field/synthetic-early-read.luauc'
    for profile in PROFILES:
        work = OUT / label / 'synthetic-early-read' / profile
        work.mkdir(parents=True)
        original = run([host, synthetic], work / 'original-run')
        for engine_name, engine in ENGINES.items():
            decompiled = run([NODE, engine / 'cli.js', 'decompile', synthetic], work / (engine_name + '-decompile'))
            recovered = work / (engine_name + '.luau')
            with recovered.open('xb') as f: f.write(decompiled.stdout)
            recompiled = run([compiler, '--binary', '-O' + profile[1], '-g' + profile[3], recovered], work / (engine_name + '-compile'))
            recovered_file = work / (engine_name + '.luauc')
            with recovered_file.open('xb') as f: f.write(recompiled.stdout)
            observed = run([host, recovered_file], work / (engine_name + '-run'))
            row = {'pin': label, 'source': 'synthetic-early-read', 'recompileProfile': profile, 'engine': engine_name,
                   'inputSha256': digest(synthetic), 'originalNormalReturn': original.returncode == 0,
                   'recoveredNormalReturn': observed.returncode == 0,
                   'stdoutByteExact': original.stdout == observed.stdout, 'stderrByteExact': original.stderr == observed.stderr,
                   'match': original.returncode == 0 and decompiled.returncode == 0 and recompiled.returncode == 0
                            and observed.returncode == 0 and original.stdout == observed.stdout and original.stderr == observed.stderr}
            results.append(row)
            with (OUT / 'results.jsonl').open('a') as f: json.dump(row, f); f.write('\n')

summary = {'executionModel': 'each pin compiles each source profile; that exact bytecode is executed and decompiled, then output is compiled and executed by the same pin',
           'pins': pins, 'hostSourceSha256': digest(REPO / 'scripts/closure-identity/run_bytecode.cpp'),
           'sources': len(SOURCES), 'originalSourceProfilesPerPin': len(SOURCES) * len(PROFILES),
           'syntheticInputs': 1, 'syntheticRecompileProfilesPerPin': len(PROFILES),
           'perPinEngine': {pin: {engine: {'profiles': sum(row['pin'] == pin and row['engine'] == engine for row in results),
                                          'matches': sum(row['pin'] == pin and row['engine'] == engine and row['match'] for row in results)}
                                  for engine in ENGINES} for pin in PINS},
           'failures': [row for row in results if not row['match']], 'results': results}
with (OUT / 'summary.json').open('x') as f: json.dump(summary, f, indent=2); f.write('\n')
with (OUT / 'commands.json').open('x') as f: json.dump(commands, f, indent=2); f.write('\n')
print(json.dumps({'perPinEngine': summary['perPinEngine'], 'failures': summary['failures']}))
raise SystemExit(0 if all(row['match'] for row in results if row['engine'] == 'after') else 1)
