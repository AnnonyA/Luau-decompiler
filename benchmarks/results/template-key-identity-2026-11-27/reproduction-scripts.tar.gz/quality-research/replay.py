"""Diagnostic-only persistent-engine replay; behavioral validity still requires official round trips."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

from summarize import summary

HERE=Path(__file__).resolve().parent

def tree_hash(root):
    digest=hashlib.sha256()
    for path in sorted(root.rglob('*.js')):
        digest.update(path.relative_to(root).as_posix().encode()+b'\0')
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return digest.hexdigest()

def core(source):
    if source.startswith('-- [[ annonya.github.io ]]'):
        return '\n'.join(source.split('\n')[3:])
    return source

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--records', type=Path, default=HERE/'baseline/records/quick')
parser.add_argument('--dist', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--query', default='')
parser.add_argument('--options', default='{}')
parser.add_argument('--section', action='append')
parser.add_argument('--name', action='append')
parser.add_argument('--profile', action='append')
parser.add_argument('--node', default='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
parser.add_argument('--diff', action='store_true')
parser.add_argument('--require-count', type=int)
args=parser.parse_args()
options=json.loads(args.options)
assert isinstance(options,dict)
assert not args.out.exists(), 'Choose a new output directory; prior diagnostic evidence is immutable.'
rows=[]
for path in sorted(args.records.glob('*/*/*.json')):
    row=json.loads(path.read_text())
    if args.section and row['section'] not in args.section:continue
    if args.name and row['name'] not in args.name:continue
    if args.profile and row['profile'] not in args.profile:continue
    if row.get('quality') is None:continue
    bytecode=path.with_suffix('.luauc')
    assert bytecode.is_file(), bytecode
    row['baselinePath']=str(path.resolve())
    row['bytecodePath']=str(bytecode.resolve())
    rows.append(row)
assert rows, 'No diagnostic rows selected.'
if args.require_count is not None:assert len(rows)==args.require_count,(len(rows),args.require_count)
args.out.mkdir(parents=True)
before=tree_hash(args.dist)
snapshot=args.out/'engine-dist'
shutil.copytree(args.dist,snapshot)
after=tree_hash(args.dist)
assert before==after==tree_hash(snapshot),'Engine changed during snapshot.'
(snapshot/'package.json').write_text('{"type":"module"}\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
node=subprocess.Popen([args.node,str(HERE/'decompile-jsonl.mjs'),str(snapshot.resolve())],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(args.out/'node-stderr.log').open('w'),text=True)
scorer=subprocess.Popen([str(HERE/'harness/target/release/quality-score')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(args.out/'score-stderr.log').open('w'),text=True)
results=[]
try:
    for index,baseline in enumerate(rows):
        identity=baseline['section']+'/'+baseline['name']+'/'+baseline['profile']
        request={'id':identity,'bytecodePath':baseline['bytecodePath'],'query':args.query,'options':options}
        node.stdin.write(json.dumps(request)+'\n');node.stdin.flush()
        response=json.loads(node.stdout.readline())
        assert response['id']==identity
        record={key:baseline.get(key) for key in ['section','name','profile','about','baselinePath','bytecodePath']}
        record.update({'id':identity,'source':baseline['source'],'baselineQuality':baseline['quality'],'quality':None,'verdict':'unmeasured','behaviorVerified':False,'decompileOk':response['ok']})
        if response['ok']:
            request={'id':identity,'original':baseline['source'],'output':response['output'],'debugNames':'g2' in baseline['profile'],'diff':args.diff}
            scorer.stdin.write(json.dumps(request)+'\n');scorer.stdin.flush()
            measured=json.loads(scorer.stdout.readline())
            assert measured['id']==identity
            record.update({'output':response['output'],'quality':measured['quality'],'coreMatchesBaseline':core(response['output'])==core(baseline['output'])})
            if 'diff' in measured:record['diff']=measured['diff']
        else:
            record['error']=response.get('error')
        target=args.out/'records'/baseline['section']/baseline['name']/(baseline['profile']+'.json')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(record)+'\n')
        results.append(record)
        if (index+1)%100==0:print(json.dumps({'completed':index+1,'total':len(rows)}),flush=True)
finally:
    for process in [node,scorer]:
        process.stdin.close()
        process.wait(timeout=30)
manifest={'format':'rosetta-quality-replay','startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputRecords':str(args.records.resolve()),'sourceDist':str(args.dist.resolve()),'snapshotDist':str(snapshot.resolve()),'jsTreeSha256':before,'treeHashAlgorithm':'SHA256 of sorted(relativeJSPath + NUL + SHA256(fileBytes))','node':subprocess.check_output([args.node,'--version'],text=True).strip(),'query':args.query,'options':options,'count':len(results),'decompileFailures':sum(not row['decompileOk'] for row in results),'coreMatchesBaseline':sum(row.get('coreMatchesBaseline',False) for row in results),'behaviorVerified':False,'baselineQuality':summary(rows),'quality':summary(results),'processExitCodes':{'node':node.returncode,'scorer':scorer.returncode}}
manifest['deltas']={key:manifest['quality'][key]-manifest['baselineQuality'][key] for key in ['similarity','size','locals','nesting','endless','names'] if manifest['quality'].get(key) is not None and manifest['baselineQuality'].get(key) is not None}
(args.out/'summary.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2),flush=True)
raise SystemExit(0 if manifest['decompileFailures']==0 and node.returncode==0 and scorer.returncode==0 else 1)
