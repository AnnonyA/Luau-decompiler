import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path

def summary(rows):
    qs = [r['quality'] for r in rows if r.get('quality') is not None]
    if not qs:
        return {'roundTrips': 0}
    n = len(qs)
    geo = lambda key: math.exp(sum(math.log((q[key][0] + 1) / (q[key][1] + 1)) for q in qs) / n)
    names = [q['names'] for q in qs if q.get('names') is not None]
    total_names = sum(q[1] for q in names)
    return {'roundTrips': n, 'similarity': sum(q['similarity'] for q in qs) / n * 100,
            'size': geo('tokens'), 'locals': geo('locals'),
            'nesting': sum(q['depth'][0] - q['depth'][1] for q in qs) / n,
            'endless': sum(max(0, q['endless'][0] - q['endless'][1]) for q in qs),
            'names': sum(q[0] for q in names) / total_names * 100 if total_names else None}

def grouped(rows, key):
    groups = defaultdict(list)
    for row in rows: groups[key(row)].append(row)
    return {name: summary(items) for name, items in sorted(groups.items())}

def analyze(root):
    rows = []
    for path in sorted(root.glob('*/*/*.json')):
        row = json.loads(path.read_text())
        row['diagnosticPath'] = str(path)
        row['bytecodePath'] = str(path.with_suffix('.luauc'))
        rows.append(row)
    result = {'recordCount': len(rows), 'verdicts': dict(Counter(r.get('verdict', 'unmeasured') for r in rows)), 'overall': summary(rows),
              'profiles': grouped(rows, lambda r:r['profile']), 'sections': grouped(rows, lambda r:r['section']),
              'sectionProfiles': grouped(rows, lambda r:r['section'] + '/' + r['profile']),
              'programs': grouped(rows, lambda r:r['section'] + '/' + r['name'])}
    mutant_rows = [r for r in rows if r['section'] == 'mutants']
    if mutant_rows:
        result['mutantOrigins'] = grouped(mutant_rows, lambda r:(r.get('about') or 'unknown').split(' of ',1)[-1].split(':',1)[0])
    result['lowestPrograms'] = sorted([{'program':key, **value} for key,value in result['programs'].items()], key=lambda r:r.get('similarity', 100))[:30]
    result['largestPrograms'] = sorted([{'program':key, **value} for key,value in result['programs'].items()], key=lambda r:r.get('size', 0), reverse=True)[:30]
    result['perProfile'] = [{key:r.get(key) for key in ['section','name','profile','about','verdict','quality','diagnosticPath','bytecodePath']} for r in rows]
    return rows, result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('records', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--sealed-result', type=Path)
    parser.add_argument('--competitor-dir', type=Path)
    parser.add_argument('--tier', default='quick')
    args=parser.parse_args()
    rows,result=analyze(args.records)
    if args.sealed_result:
        sealed=json.loads(args.sealed_result.read_text())
        result['sealedBaseline']={'path':str(args.sealed_result),'sha256':hashlib.sha256(args.sealed_result.read_bytes()).hexdigest(),'quality':sealed['quality']}
        result['sealedQualityDeltas']={key:result['overall'][key]-sealed['quality'][key] for key in ['similarity','size','locals','nesting','endless','names'] if result['overall'][key] is not None}
        result['exactScoreMatch']=(len(rows)==sum(sealed['totals'].values()) and result['verdicts']==sealed['totals'])
    if args.competitor_dir:
        comparison={}
        for peer in ['luacid','lua-expert']:
            path=args.competitor_dir / f'{peer}-{args.tier}.json'
            report=json.loads(path.read_text())
            passing={(section['id'],test['name'],profile) for section in report['sections'] for test in section['tests'] for profile,verdict in zip(report['profiles'],test['results']) if verdict=='p'}
            common=[r for r in rows if r.get('quality') and (r['section'],r['name'],r['profile']) in passing]
            comparison[peer]={'publishedResult':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'publishedScore':report['score'],'publishedQuality':report['quality'],'sharedPasses':len(common),'ourQualityOnSharedPasses':summary(common),'comparisonComplete':len(common)==report['quality']['round_trips']}
        result['competitorIntersections']=comparison
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['perProfile','programs','lowestPrograms','largestPrograms','sectionProfiles','mutantOrigins']},indent=2))

if __name__=='__main__':main()
