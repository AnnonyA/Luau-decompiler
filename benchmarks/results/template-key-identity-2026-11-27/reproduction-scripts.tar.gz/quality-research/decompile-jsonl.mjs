import { readFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const directory = process.argv[2];
if (!directory) throw new Error('Usage: node decompile-jsonl.mjs /absolute/engine/dist');
const { decompile, parseQueryOptions } = await import(pathToFileURL(resolve(directory, 'decompile.js')));
const { formatDecompiledSource } = await import(pathToFileURL(resolve(directory, 'print/SourcePresentation.js')));
const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
for await (const line of input) {
  if (!line.trim()) continue;
  let request;
  try {
    request = JSON.parse(line);
    const bytes = new Uint8Array(await readFile(request.bytecodePath));
    const options = { ...parseQueryOptions(new URLSearchParams(request.query ?? '')), ...request.options };
    const result = decompile(bytes, options);
    if (!result.ok || result.diagnostics.some(item => item.severity === 'error')) {
      process.stdout.write(JSON.stringify({ id: request.id, ok: false, error: result.error ?? 'error diagnostic', diagnostics: result.diagnostics }) + '\n');
      continue;
    }
    // A fixed metadata timestamp keeps diagnostic files reproducible; comments do not affect Rosetta's lexer.
    const output = formatDecompiledSource(result, new Date(0));
    process.stdout.write(JSON.stringify({ id: request.id, ok: true, output, coreSource: result.source, diagnostics: result.diagnostics }) + '\n');
  } catch (error) {
    process.stdout.write(JSON.stringify({ id: request?.id ?? null, ok: false, error: String(error?.stack ?? error) }) + '\n');
  }
}
