import argparse
import json
import math
from pathlib import Path
from summarize import analyze

parser=argparse.ArgumentParser()
parser.add_argument('--baseline',type=Path,required=True)
parser.add_argument('--candidate',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
before_rows,before=analyze(args.baseline)
after_rows,after=analyze(args.candidate)
identity=lambda r:(r['section'],r['name'],r['profile'])
assert {identity(r)for r in before_rows}=={identity(r)for r in after_rows},'Profile populations differ.'
assert all(r.get('quality') for r in after_rows),'A produced profile is missing quality; inspect decompile failures before aggregate comparison.'
keys=['similarity','size','locals','nesting','endless','names']
def compare(a,b):
 return {'baseline':a,'candidate':b,'deltas':{key:b[key]-a[key]for key in keys if a.get(key)is not None and b.get(key)is not None}}
result={'format':'rosetta-quality-replay-comparison','behaviorVerified':False,'count':len(after_rows),'baselineRecords':str(args.baseline.resolve()),'candidateRecords':str(args.candidate.resolve()),'overall':compare(before['overall'],after['overall'])}
for group in ['profiles','sections','sectionProfiles','programs','mutantOrigins']:
 result[group]={name:compare(before[group][name],value)for name,value in after.get(group,{}).items()}
programs=[{'program':name,**value}for name,value in result['programs'].items()]
result['biggestGains']=sorted(programs,key=lambda p:p['deltas']['similarity'],reverse=True)[:25]
result['biggestLosses']=sorted([p for p in programs if p['deltas']['similarity']<0],key=lambda p:p['deltas']['similarity'])[:25]
result['lowestOriginalSimilarity']=sorted(programs,key=lambda p:p['candidate']['similarity'])[:30]
result['largestOutputs']=sorted(programs,key=lambda p:p['candidate']['size'],reverse=True)[:25]
result['shortestOutputs']=sorted(programs,key=lambda p:p['candidate']['size'])[:25]
result['generatedO2']=sorted([{'program':r['section']+'/'+r['name'],'profile':r['profile'],'similarity':r['quality']['similarity']*100,'size':(r['quality']['tokens'][0]+1)/(r['quality']['tokens'][1]+1),'tokens':r['quality']['tokens'],'diagnosticPath':r['diagnosticPath']} for r in after_rows if r['section']=='generated'and r['profile'].startswith('O2')],key=lambda r:r['similarity'])
base={identity(r):r for r in before_rows}
result['perProfile']=[{'section':r['section'],'name':r['name'],'profile':r['profile'],'similarityDelta':100*(r['quality']['similarity']-base[identity(r)]['quality']['similarity']),'baselineQuality':base[identity(r)]['quality'],'candidateQuality':r['quality'],'diagnosticPath':r['diagnosticPath']}for r in after_rows]
result['changedProfiles']={'better':sum(r['similarityDelta']>0 for r in result['perProfile']),'equal':sum(r['similarityDelta']==0 for r in result['perProfile']),'worse':sum(r['similarityDelta']<0 for r in result['perProfile'])}
args.out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key]for key in ['count','overall','profiles','sections','changedProfiles']},indent=2))
