import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {writeBytecode, abc, ad} from '../../similarity-v2-locals/dist/decode/BytecodeWriter.js';
import {Opcode} from '../../similarity-v2-locals/dist/decode/Opcode.js';
const folder = new URL('../../similarity-v2-locals/tests/fixtures/template-key-alias/', import.meta.url);
const entries = [];
for (const [name, key] of [['empty', ''], ['keyword', 'end']]) {
  const bytes = writeBytecode({maxStackSize: 8, numParams: 0, numUpvalues: 0,
    constants: [{kind: 'string', value: key}, {kind: 'table', keys: [0]}, {kind: 'string', value: 'print'}],
    instructions: [ad(Opcode.DUPTABLE, 0, 1), abc(Opcode.GETTABLEKS, 1, 0, 0), 0,
      abc(Opcode.GETGLOBAL, 2, 0, 0), 2, abc(Opcode.MOVE, 3, 1, 0), abc(Opcode.CALL, 2, 2, 1),
      ad(Opcode.LOADN, 4, 5), abc(Opcode.SETTABLEKS, 4, 0, 0), 0,
      abc(Opcode.GETTABLEKS, 3, 0, 0), 0, abc(Opcode.GETGLOBAL, 2, 0, 0), 2,
      abc(Opcode.CALL, 2, 2, 1), abc(Opcode.RETURN, 0, 1, 0)]}, {version: 6, typesVersion: 1});
  const bytecode = 'synthetic-' + name + '-key.luauc';
  writeFileSync(new URL(bytecode, folder), bytes, {flag: 'wx'});
  entries.push({name, key, bytecode, sha256: createHash('sha256').update(bytes).digest('hex')});
}
writeFileSync(new URL('synthetic-keys.json', folder), JSON.stringify({
  createdAt: new Date().toISOString(), version: 6, typesVersion: 1,
  purpose: 'Observe an empty or keyword-named loader slot before and after its explicit store', entries,
}, null, 2) + '\n', {flag: 'wx'});
