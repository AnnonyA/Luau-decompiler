from pathlib import Path
import hashlib, json, subprocess

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
FIXTURES = BASE / 'similarity-v2-locals/tests/fixtures/single-template-field'
OUT = HERE / 'template-key-synthetic-final'
OUT.mkdir(exist_ok=False)
ROSETTA = BASE / 'rosetta-research/target/release/rosetta'
NODE = Path('/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node')
ENGINES = {'before': HERE / 'template-quick-v3/engine-dist',
           'after': HERE / 'template-key-candidate-v2/engine-dist'}
PROFILES = ['O0g1', 'O1g1', 'O2g1', 'O0g2', 'O1g2', 'O2g2']
manifest = json.loads((FIXTURES / 'synthetic-manifest.json').read_text())
binary = FIXTURES / manifest['bytecode']
assert hashlib.sha256(binary.read_bytes()).hexdigest() == manifest['sha256']
commands = []

def run(args, stem):
    args = list(map(str, args))
    result = subprocess.run(args, capture_output=True, timeout=20)
    for stream in ['stdout', 'stderr']:
        with stem.with_suffix('.' + stream).open('xb') as f: f.write(getattr(result, stream))
    commands.append({'command': args, 'exitCode': result.returncode,
                     'stdout': str(stem.with_suffix('.stdout').relative_to(OUT)),
                     'stderr': str(stem.with_suffix('.stderr').relative_to(OUT))})
    return result

original = run([ROSETTA, 'run', binary], OUT / 'original-run')
original_returned = original.returncode == 0 and original.stdout.rstrip().endswith(b'-- Returned')
results = []
for label, engine in ENGINES.items():
    work = OUT / label
    work.mkdir()
    decompiled = run([NODE, engine / 'cli.js', 'decompile', binary], work / 'decompile')
    source = work / 'recovered.luau'
    with source.open('xb') as f: f.write(decompiled.stdout)
    for profile in PROFILES:
        recovered = work / (profile + '.luauc')
        compiled = run([ROSETTA, 'compile', source, '--profile', profile, '--output', recovered], work / (profile + '-compile'))
        observed = run([ROSETTA, 'run', recovered], work / (profile + '-run')) if recovered.exists() else None
        returned = observed is not None and observed.returncode == 0 and observed.stdout.rstrip().endswith(b'-- Returned')
        stdout_same = observed is not None and observed.stdout == original.stdout
        stderr_same = observed is not None and observed.stderr == original.stderr
        results.append({'engine': label, 'recompileProfile': profile, 'inputSha256': manifest['sha256'],
                        'originalReturned': original_returned, 'recoveredReturned': returned,
                        'stdoutByteExact': stdout_same, 'stderrByteExact': stderr_same,
                        'match': original_returned and returned and stdout_same and stderr_same
                                 and decompiled.returncode == 0 and compiled.returncode == 0})
summary = {'inputKind': 'synthetic official bytecode, version 6; one original input, six recompile profiles per engine',
           'expectedOriginalStdout': '0\n5\n-- Returned\n',
           'originalStdout': original.stdout.decode(), 'originalStderr': original.stderr.decode(),
           'results': results,
           'perEngine': {label: {'profiles': sum(r['engine'] == label for r in results),
                                'matches': sum(r['engine'] == label and r['match'] for r in results)} for label in ENGINES}}
with (OUT / 'summary.json').open('x') as f: json.dump(summary, f, indent=2); f.write('\n')
with (OUT / 'commands.json').open('x') as f: json.dump(commands, f, indent=2); f.write('\n')
print(json.dumps({k: summary[k] for k in ['originalStdout', 'originalStderr', 'perEngine']}))
raise SystemExit(0 if all(r['match'] for r in results if r['engine'] == 'after') else 1)
