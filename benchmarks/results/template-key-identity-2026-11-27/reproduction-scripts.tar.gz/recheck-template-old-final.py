from pathlib import Path
import hashlib, json, subprocess

BASE = Path('/workspace/scratch/eb5e4be57451')
HERE = Path(__file__).resolve().parent
FIXTURES = BASE / 'similarity-v2-locals/tests/fixtures/single-template-field'
OUT = HERE / 'template-key-old-sealed-final'
OUT.mkdir(exist_ok=False)
INITIAL = HERE / 'template-sealed-runtime-initial'
ENGINE = HERE / 'template-key-candidate-v2/engine-dist'
ROSETTA = BASE / 'rosetta-research/target/release/rosetta'
NODE = Path('/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((FIXTURES / 'manifest.json').read_text())
commands = []

def run(args, stem):
    args = list(map(str, args))
    result = subprocess.run(args, capture_output=True, timeout=20)
    for stream in ['stdout', 'stderr']:
        with stem.with_suffix('.' + stream).open('xb') as f:
            f.write(getattr(result, stream))
    commands.append({'command': args, 'exitCode': result.returncode,
                     'stdout': str(stem.with_suffix('.stdout').relative_to(OUT)),
                     'stderr': str(stem.with_suffix('.stderr').relative_to(OUT))})
    with (OUT / 'commands.jsonl').open('a') as f:
        json.dump(commands[-1], f); f.write('\n')
    return result

results = []
for source in manifest['sources']:
    assert digest(FIXTURES / (source['name'] + '.luau')) == source['sourceSha256']
    for entry in source['bytecodes']:
        identity = source['name'] + '-' + entry['profile']
        work = OUT / identity
        work.mkdir()
        binary = FIXTURES / entry['path']
        assert digest(binary) == entry['sha256']
        original = run([ROSETTA, 'run', binary], work / 'original-run')
        original_stable = all(getattr(original, stream) == (INITIAL / identity / ('original-run.' + stream)).read_bytes()
                              for stream in ['stdout', 'stderr'])
        decompiled = run([NODE, ENGINE / 'cli.js', 'decompile', binary], work / 'after-decompile')
        recovered = work / 'after.luau'
        with recovered.open('xb') as f: f.write(decompiled.stdout)
        compiled = work / 'after.luauc'
        recompiled = run([ROSETTA, 'compile', recovered, '--profile', entry['profile'].split('+')[0], '--output', compiled], work / 'after-compile')
        observed = run([ROSETTA, 'run', compiled], work / 'after-run') if compiled.exists() else None
        original_returned = original.returncode == 0 and original.stdout.rstrip().endswith(b'-- Returned')
        recovered_returned = observed is not None and observed.returncode == 0 and observed.stdout.rstrip().endswith(b'-- Returned')
        stdout_same = observed is not None and original.stdout == observed.stdout
        stderr_same = observed is not None and original.stderr == observed.stderr
        row = {'source': source['name'], 'profile': entry['profile'], 'engine': 'after',
               'inputSha256': digest(binary), 'recoveredSha256': digest(recovered), 'originalObservationUnchanged': original_stable,
               'decompileExitCode': decompiled.returncode, 'compileExitCode': recompiled.returncode,
               'originalReturned': original_returned, 'recoveredReturned': recovered_returned,
               'stdoutByteExact': stdout_same, 'stderrByteExact': stderr_same,
               'match': original_returned and recovered_returned and original_stable and stdout_same and stderr_same
                        and decompiled.returncode == 0 and recompiled.returncode == 0}
        results.append(row)
        with (OUT / 'results.jsonl').open('a') as f:
            json.dump(row, f); f.write('\n')
with (OUT / 'commands.json').open('x') as f: json.dump(commands, f, indent=2); f.write('\n')
summary = {'executionModel': 'same unchanged saved input bytes passed to engine and official VM',
           'manifestSha256': digest(FIXTURES / 'manifest.json'),
           'profiles': len(results), 'matches': sum(row['match'] for row in results),
           'originalObservationsUnchanged': all(row['originalObservationUnchanged'] for row in results),
           'failures': [row for row in results if not row['match']], 'results': results}
with (OUT / 'summary.json').open('x') as f: json.dump(summary, f, indent=2); f.write('\n')
print(json.dumps({key: summary[key] for key in ['profiles', 'matches', 'originalObservationsUnchanged', 'failures']}))
raise SystemExit(0 if summary['matches'] == summary['profiles'] else 1)
