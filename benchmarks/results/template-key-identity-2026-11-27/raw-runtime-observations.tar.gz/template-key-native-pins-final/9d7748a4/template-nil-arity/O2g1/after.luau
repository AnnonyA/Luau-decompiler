-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:30Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function many(p)
    table.insert(list, "many:" .. p)
    return p, "extra", nil
end

local function none()
    table.insert(list, "none")
end

local function build(p: boolean)
    local data = { value = 0 }
    local result
    if p then
        table.insert(list, "many:" .. 7)
        result = 7
    else
        table.insert(list, "none")
        result = nil
    end
    data.value = result
    print(data == data, select("#", data.value), data.value)
    return data
end

local value = (true and build)(true)
local value2 = (true and build)(false)
print(table.concat(list, "|"), value.value, value2.value, value == value2)
value2.value = 2
value2.other = 3
local result, value3 = next(value2)
print(result, value3, next(value2, result))

local function vararg(...)
    return { value = ... }
end

local value4 = vararg()
local value5 = vararg(nil, 8, 9)
print(value4.value, value5.value, select("#", value4.value, value5.value), value4 == value5)
