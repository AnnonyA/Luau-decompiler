-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:33Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function observe(label: string, value: boolean | number): (boolean | number, string)
    (table.insert)(list, label)
    return value, "extra"
end

local field = (true and observe)("first", 2)

local function dynamic(key: string)
    return {
        ready = (true and observe)("named", 7),
        [key] = (true and observe)("dynamic", 11),
    }
end

local field2 = (true and observe)("second", 3)
local same, different = (true and dynamic)("ready"), (true and dynamic)("other")
local print2 = print
local value = (table.concat)(list, "|")
local data = { ready = 0, ready = 41 }
print2(value, data.ready, ({ ready = field2 }).ready, same.ready, different.ready, different.other)

local function keys(value)
    local list = {}
    for key in value do
        (table.insert)(list, key)
    end
    return (table.concat)(list, ",")
end

print((true and keys)(data), #data)
data.alpha = 1
data.beta = 2
data.gamma = 3
data.ready = nil
data.delta = 4
data.ready = false
print((true and keys)(data), #data, data.ready)
data.beta = nil
data.epsilon = 5
print((true and keys)(data), data.alpha, data.gamma, data.delta, data.epsilon)

local function ready(): number
    return 1
end

local tbl = {}
tbl["ready"] = ready
tbl["ready"] = function()
    return 2
end

print((debug.info)(tbl.ready, "n"), (true and tbl.ready)())
local data2 = { ready = 0, ready = (true and observe)("single", false) }
local alias = data2
alias.ready = 19
print(data2 == alias, data2.ready, (table.concat)(list, "|"))
