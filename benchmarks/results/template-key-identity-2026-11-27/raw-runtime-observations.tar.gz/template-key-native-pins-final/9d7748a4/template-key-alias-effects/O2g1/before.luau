-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:33Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function observe(p, p2)
    table.insert(list, p)
    return p2, "extra"
end

table.insert(list, "first")
table.insert(list, "second")

local function dynamic(p)
    table.insert(list, "named")
    table.insert(list, "dynamic")
    return { ready = 7, [p] = 11 }
end

table.insert(list, "named")
table.insert(list, "dynamic")
table.insert(list, "named")
table.insert(list, "dynamic")
local print2 = print
local value = table.concat(list, "|")
local data = { ready = 41 }
local ready = data.ready
local ready2 = ({ ready = 3 }).ready
local ready3 = ({ ready = 11 }).ready
local data2 = { ready = 7, other = 11 }
print2(value, ready, ready2, ready3, data2.ready, data2.other)

local function keys(items)
    local list = {}
    for key in items do
        table.insert(list, key)
    end
    return table.concat(list, ",")
end

local print3 = print
local list2 = {}
for key in data do
    table.insert(list2, key)
end
print3(table.concat(list2, ","), #data)
data.alpha = 1
data.beta = 2
data.gamma = 3
data.ready = nil
data.delta = 4
data.ready = false
local print4 = print
local list3 = {}
for key2 in data do
    table.insert(list3, key2)
end
print4(table.concat(list3, ","), #data, data.ready)
data.beta = nil
data.epsilon = 5
local print5 = print
local list4 = {}
for key3 in data do
    table.insert(list4, key3)
end
print5(table.concat(list4, ","), data.alpha, data.gamma, data.delta, data.epsilon)
local print6 = print
local info = debug.info
local data3 = {}
data3.ready = function()
    return 2
end

function data3.ready()
    return 1
end

print6(info(data3.ready, "n"), 2)
table.insert(list, "single")
local print7 = print
local data4 = { ready = 19 }
print7(data4 == data4, data4.ready, table.concat(list, "|"))
