-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:47Z
-- Luau bytecode version: 14 | Luau type version: 3

local function choose(key: string)
    local function ready(): number
        return 1
    end

    return {
        ready = ready,
        [key] = function()
        return 2
    end,
    }
end

local same, different = (true and choose)("ready"), (true and choose)("other")
print((same.ready)(), (different.ready)(), (different.other)())
print((debug.info)(same.ready, "n"), (debug.info)(different.ready, "n"), (debug.info)(different.other, "n"))

local function many(): (nil, number, number)
    return nil, 4, 5
end

local function ready(): number
    return 9
end

local tbl = {}
tbl["ready"] = ready
tbl["ready"] = many()
print(tbl.ready, select("#", tbl.ready))
tbl.alpha = 1
tbl.beta = 2
tbl.gamma = 3
local list = {}
for key in tbl do
    (table.insert)(list, key)
end
print((table.concat)(list, ","), #tbl)
local list2 = {}
for index = 1, 3 do
    local tbl2 = {}
    tbl2["ready"] = function()
        return tbl2, index
    end

    local first = tbl2.ready
    tbl2["ready"] = function()
        return tbl2, index + 10, nil
    end;

    (table.insert)(list2, { tbl2, first, tbl2.ready })
end
for _, list3 in list2 do
    local firstRecord, firstIndex = (list3[2])()
    local secondRecord, secondIndex = (list3[3])()
    print(list3[1] == firstRecord, firstRecord == secondRecord, firstIndex, secondIndex, list3[2] == list3[3], select("#", (list3[3])()), (debug.info)(list3[2], "n"), (debug.info)(list3[3], "n"))
end
print(list2[1][1] == list2[2][1])
