-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:42Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}
local proxy = setmetatable({}, {
    __index = function(_, key)
    table.insert(list, "read:" .. key)
    return 3
end,
})

local function create(value)
    return { ready = proxy.value == value }
end

local data = { ready = 0 }
local ready = proxy.value == 3
data.ready = ready
local data2 = { ready = 0 }
ready = proxy.value == 4
data2.ready = ready
print(table.concat(list, "|"), data.ready, data2.ready, data == data2)

local function keys(record)
    local list = {}
    for key in record do
        table.insert(list, key)
    end
    return table.concat(list, ",")
end

local print2 = print
local list2 = {}
for key2 in data do
    table.insert(list2, key2)
end
local value2 = table.concat(list2, ",")
local list3 = {}
for key3 in data2 do
    table.insert(list3, key3)
end
print2(value2, table.concat(list3, ","), #data, #data2)
data.alpha = 1
data.beta = 2
data.gamma = 3
data.ready = nil
data.delta = 4
data.ready = false
local print3 = print
local list4 = {}
for key4 in data do
    table.insert(list4, key4)
end
print3(table.concat(list4, ","), #data, data.ready, data.alpha)
data.beta = nil
data.epsilon = 5
local print4 = print
local list5 = {}
for key5 in data do
    table.insert(list5, key5)
end
local value3 = table.concat(list5, ",")
print4(value3, data.gamma, data.delta, data.epsilon)
data.ready = 9
local print5 = print
value3 = data == data
print5(value3, data.ready, data2.ready)
