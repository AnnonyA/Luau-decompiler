-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:33:12Z
-- Luau bytecode version: 14 | Luau type version: 3

local function choose(key: string)
    local function_ = function(): number
        return 2
    end
    return {
        ready = function()
        return 1
    end,
        [key] = function_,
    }
end

local same, different = (true and choose)("ready"), (true and choose)("other")
print((same.ready)(), (different.ready)(), (different.other)())
print(debug.info(same.ready, "n"), debug.info(different.ready, "n"), debug.info(different.other, "n"))

local function many(): (nil, number, number)
    return nil, 4, 5
end

local field = many()
local print2 = print
local data = {
    ready = function()
    return 9
end,
    ready = field,
}
print2(data.ready, select("#", data.ready))
data.alpha = 1
data.beta = 2
data.gamma = 3
local list = {}
for key in data do
    table.insert(list, key)
end
print(table.concat(list, ","), #data)
local list2 = {}
for index = 1, 3 do
    local tbl = {}
    tbl["ready"] = function()
        return tbl, index
    end

    local first = tbl.ready
    tbl["ready"] = function()
        return tbl, index + 10, nil
    end

    table.insert(list2, { tbl, first, tbl.ready })
end
for _, list3 in list2 do
    local firstRecord, firstIndex = (list3[2])()
    local secondRecord, secondIndex = (list3[3])()
    print(list3[1] == firstRecord, firstRecord == secondRecord, firstIndex, secondIndex, list3[2] == list3[3], select("#", (list3[3])()), debug.info(list3[2], "n"), debug.info(list3[3], "n"))
end
print(list2[1][1] == list2[2][1])
