-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:33:13Z
-- Luau bytecode version: 14 | Luau type version: 3

local function choose(p: string)
    local data = {
        [p] = function()
        return 2
    end,
    }
    function data.ready()
        return 1
    end

    return data
end

local value = (true and choose)("ready")
local value2 = (true and choose)("other")
print((value.ready)(), (value2.ready)(), (value2.other)())
print(debug.info(value.ready, "n"), (debug.info)(value2.ready, "n"), debug.info(value2.other, "n"))

local function many(): (nil, number, number)
    return nil, 4, 5
end

local print2 = print
local data = { ready = nil }

function data.ready()
    return 9
end

print2(data.ready, select("#", data.ready))
data.alpha = 1
data.beta = 2
data.gamma = 3
local list = {}
for key in data do
    table.insert(list, key)
end
print((table.concat)(list, ","), #data)
local list2 = {}
for index = 1, 3 do
    local tbl = {}
    tbl.ready = function()
        return tbl, index
    end

    local ready = tbl.ready
    tbl.ready = function()
        return tbl, index + 10, nil
    end

    table.insert(list2, { tbl, ready, tbl.ready })
end
for _, list3 in list2 do
    local result, value3 = (list3[2])()
    local result2, value4 = (list3[3])()
    print(list3[1] == result, result == result2, value3, value4, list3[2] == list3[3], select("#", (list3[3])()), (debug.info)(list3[2], "n"), debug.info(list3[3], "n"))
end
print(list2[1][1] == list2[2][1])
