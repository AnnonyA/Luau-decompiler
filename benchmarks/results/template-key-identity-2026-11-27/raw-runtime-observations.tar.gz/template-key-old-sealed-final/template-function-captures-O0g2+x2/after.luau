-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:19Z
-- Luau bytecode version: 14 | Luau type version: 3

local function create(p: boolean)
    local data = { callback = 0 }
    data["callback"] = if p then function(p)
        return p, nil
    end else function(p)
        return -p
    end
    return data
end

local value = (true and create)(true)
local value2 = (true and create)(false)
print((debug.info)(value.callback, "n"), (debug.info)(value2.callback, "n"), (value.callback)(7), (value2.callback)(7))
print(select("#", (value.callback)(7)), select("#", (value2.callback)(7)))
local sharedCounter: number = 0
local list = {}
local list2 = {}
for index = 1, 3 do
    local tbl = {}
    tbl["callback"] = function()
        return tbl, index, sharedCounter
    end;

    (table.insert)(list2, tbl.callback);
    (table.insert)(list, tbl)
    sharedCounter += index
end
sharedCounter = 20
for key, callback in list2 do
    local result, value3, value4 = callback()
    print(result == list[key], value3, value4, (debug.info)(callback, "n"))
end
print(list2[1] == list2[2], list[1] == list[2])
