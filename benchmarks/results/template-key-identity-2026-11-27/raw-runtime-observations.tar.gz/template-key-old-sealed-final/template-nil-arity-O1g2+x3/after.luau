-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:22Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function many(p: number): (number, string, nil)
    table.insert(list, "many:" .. p)
    return p, "extra", nil
end

local function none()
    table.insert(list, "none")
end

local function build(p: boolean)
    local data = { value = if p then (true and many)(7) else (true and none)() }
    print(data == data, select("#", data.value), data.value)
    return data
end

local value = (true and build)(true)
local value2 = (true and build)(false)
print(table.concat(list, "|"), value.value, value2.value, value == value2)
value2.value = 2
value2.other = 3
local result, value3 = next(value2)
print(result, value3, next(value2, result))

local function vararg(...)
    return { value = ... }
end

local value4 = vararg()
local value5 = vararg(nil, 8, 9)
print(value4.value, value5.value, select("#", value4.value, value5.value), value4 == value5)
