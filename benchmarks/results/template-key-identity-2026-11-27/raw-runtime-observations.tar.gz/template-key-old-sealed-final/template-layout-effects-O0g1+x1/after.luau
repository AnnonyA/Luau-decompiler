-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:20Z
-- Luau bytecode version: 14 | Luau type version: 3

local setmetatable2 = setmetatable
local list = {}

local function __index(p, p2): number
    (table.insert)(list, "read:" .. p2)
    return 3
end

local data = { __index = 0 }
data["__index"] = __index
local value = setmetatable2({}, data)

local function create(p: number)
    return { ready = value.value == p }
end

local value2 = (true and create)(3)
local value3 = (true and create)(4)
print((table.concat)(list, "|"), value2.ready, value3.ready, value2 == value3)

local function keys(items)
    local list = {}
    for key in items do
        (table.insert)(list, key)
    end
    return (table.concat)(list, ",")
end

print((true and keys)(value2), (true and keys)(value3), #value2, #value3)
value2.alpha = 1
value2.beta = 2
value2.gamma = 3
value2.ready = nil
value2.delta = 4
value2.ready = false
print((true and keys)(value2), #value2, value2.ready, value2.alpha)
value2.beta = nil
value2.epsilon = 5
local print2 = print
local value4 = (true and keys)(value2)
local gamma = value2.gamma
print2(value4, gamma, value2.delta, value2.epsilon)
value2.ready = 9
local print3 = print
gamma = value2 == value2
print3(gamma, value2.ready, value3.ready)
