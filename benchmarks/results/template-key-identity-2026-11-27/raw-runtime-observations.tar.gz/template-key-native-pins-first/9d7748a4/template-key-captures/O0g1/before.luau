-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:22Z
-- Luau bytecode version: 14 | Luau type version: 3

local function choose(p: string)
    local function ready(): number
        return 1
    end

    return {
        ready = ready,
        [p] = function()
        return 2
    end,
    }
end

local value = (true and choose)("ready")
local value2 = (true and choose)("other")
print((value.ready)(), (value2.ready)(), (value2.other)())
print((debug.info)(value.ready, "n"), (debug.info)(value2.ready, "n"), (debug.info)(value2.other, "n"))

local function many(): (nil, number, number)
    return nil, 4, 5
end

local function ready(): number
    return 9
end

local tbl = {}
tbl["ready"] = ready
tbl["ready"] = many()
print(tbl.ready, select("#", tbl.ready))
tbl.alpha = 1
tbl.beta = 2
tbl.gamma = 3
local list = {}
for key in tbl do
    (table.insert)(list, key)
end
print((table.concat)(list, ","), #tbl)
local list2 = {}
for index = 1, 3 do
    local tbl2 = {}
    tbl2.ready = function()
        return tbl2, index
    end

    local ready2 = tbl2.ready
    tbl2["ready"] = function()
        return tbl2, index + 10, nil
    end;

    (table.insert)(list2, { tbl2, ready2, tbl2.ready })
end
for _, list3 in list2 do
    local result, value3 = (list3[2])()
    local result2, value4 = (list3[3])()
    print(list3[1] == result, result == result2, value3, value4, list3[2] == list3[3], select("#", (list3[3])()), (debug.info)(list3[2], "n"), (debug.info)(list3[3], "n"))
end
print(list2[1][1] == list2[2][1])
