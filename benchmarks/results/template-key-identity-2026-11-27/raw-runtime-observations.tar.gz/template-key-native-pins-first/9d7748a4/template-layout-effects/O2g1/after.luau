-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:18Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}
local value = setmetatable({}, {
    __index = function(p, p2)
    table.insert(list, "read:" .. p2)
    return 3
end,
})

local function create(p)
    return { ready = value.value == p }
end

local data = { ready = 0 }
local ready = value.value == 3
data.ready = ready
local data2 = { ready = 0 }
ready = value.value == 4
data2.ready = ready
print(table.concat(list, "|"), data.ready, data2.ready, data == data2)

local function keys(items)
    local list = {}
    for key in items do
        table.insert(list, key)
    end
    return table.concat(list, ",")
end

local print2 = print
local list2 = {}
for key in data do
    table.insert(list2, key)
end
local value2 = table.concat(list2, ",")
local list3 = {}
for key2 in data2 do
    table.insert(list3, key2)
end
print2(value2, table.concat(list3, ","), #data, #data2)
data.alpha = 1
data.beta = 2
data.gamma = 3
data.ready = nil
data.delta = 4
data.ready = false
local print3 = print
local list4 = {}
for key3 in data do
    table.insert(list4, key3)
end
print3(table.concat(list4, ","), #data, data.ready, data.alpha)
data.beta = nil
data.epsilon = 5
local print4 = print
local list5 = {}
for key4 in data do
    table.insert(list5, key4)
end
local value3 = table.concat(list5, ",")
print4(value3, data.gamma, data.delta, data.epsilon)
data.ready = 9
local print5 = print
value3 = data == data
print5(value3, data.ready, data2.ready)
