-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:26Z
-- Luau bytecode version: 14 | Luau type version: 3

local function create(flag: boolean)
    local data = { callback = 0 }
    data["callback"] = if flag then function(value)
        return value, nil
    end else function(value)
        return -value
    end
    return data
end

local a, b = (true and create)(true), (true and create)(false)
print((debug.info)(a.callback, "n"), (debug.info)(b.callback, "n"), (a.callback)(7), (b.callback)(7))
print(select("#", (a.callback)(7)), select("#", (b.callback)(7)))
local sharedCounter: number = 0
local list = {}
local list2 = {}
for index = 1, 3 do
    local tbl = {}
    tbl["callback"] = function()
        return tbl, index, sharedCounter
    end;

    (table.insert)(list2, tbl.callback);
    (table.insert)(list, tbl)
    sharedCounter += index
end
sharedCounter = 20
for key, value2 in list2 do
    local record, originalIndex, changed = value2()
    print(record == list[key], originalIndex, changed, (debug.info)(value2, "n"))
end
local print2 = print
local value3 = list2[1]
local result = value3 == list2[2]
value3 = list[1] == list[2]
print2(result, value3)
