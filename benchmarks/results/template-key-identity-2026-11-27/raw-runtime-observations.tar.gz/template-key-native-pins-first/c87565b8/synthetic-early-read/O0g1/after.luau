-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:33Z
-- Luau bytecode version: 6 | Luau type version: 1

local data = { ready = 0 }
local ready = data.ready
print(ready)
data.ready = 5
print(data.ready)
