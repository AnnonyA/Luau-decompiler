-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:34:29Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function many(value: number): (number, string, nil)
    (table.insert)(list, "many:" .. value)
    return value, "extra", nil
end

local function none()
    (table.insert)(list, "none")
end

local function build(value: boolean)
    local data = { value = if value then (true and many)(7) else (true and none)() }
    local alias = data
    print(data == alias, select("#", data.value), data.value)
    return data
end

local first, second = (true and build)(true), (true and build)(false)
print((table.concat)(list, "|"), first.value, second.value, first == second)
second.value = 2
second.other = 3
local key, value2 = next(second)
print(key, value2, next(second, key))

local function vararg(...)
    local first = ...
    return { value = first }
end

local a, b = vararg(), vararg(nil, 8, 9)
print(a.value, b.value, select("#", a.value, b.value), a == b)
