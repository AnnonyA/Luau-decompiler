-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:33Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function observe(label: string, value: boolean | number): (boolean | number, string)
    table.insert(list, label)
    return value, "extra"
end

local field = (true and observe)("first", 2)

local function dynamic(key: string)
    return {
        ready = (true and observe)("named", 7),
        [key] = (true and observe)("dynamic", 11),
    }
end

local field2 = (true and observe)("second", 3)
local same, different = (true and dynamic)("ready"), (true and dynamic)("other")
local print2 = print
local value = table.concat(list, "|")
local data = { ready = 41 }
print2(value, data.ready, ({ ready = field2 }).ready, same.ready, different.ready, different.other)

local function keys(value)
    local list = {}
    for key in value do
        table.insert(list, key)
    end
    return table.concat(list, ",")
end

print((true and keys)(data), #data)
data.alpha = 1
data.beta = 2
data.gamma = 3
data.ready = nil
data.delta = 4
data.ready = false
print((true and keys)(data), #data, data.ready)
data.beta = nil
data.epsilon = 5
print((true and keys)(data), data.alpha, data.gamma, data.delta, data.epsilon)
local print3 = print
local info = debug.info
local data2 = {
    ready = function()
    return 1
end,
    ["ready"] = function()
    return 2
end,
}
print3(info(data2.ready, "n"), (true and data2.ready)())
local field3 = (true and observe)("single", false)
local print4 = print
local data3 = { ready = field3, ready = 19 }
print4(data3 == data3, data3.ready, table.concat(list, "|"))
