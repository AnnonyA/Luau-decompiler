-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:39:18Z
-- Luau bytecode version: 6 | Luau type version: 1

local data = { ["end"] = 0 }
local value = data["end"]
print(value)
data["end"] = 5
print(data["end"])
