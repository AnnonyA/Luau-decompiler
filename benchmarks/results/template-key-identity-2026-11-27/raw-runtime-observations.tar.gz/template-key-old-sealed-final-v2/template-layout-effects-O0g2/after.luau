-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:40:28Z
-- Luau bytecode version: 14 | Luau type version: 3

local setmetatable2 = setmetatable
local list = {}

local function __index(_, key): number
    (table.insert)(list, "read:" .. key)
    return 3
end

local data = { __index = 0 }
data["__index"] = __index
local proxy = setmetatable2({}, data)

local function create(value: number)
    return { ready = proxy.value == value }
end

local first, second = (true and create)(3), (true and create)(4)
print((table.concat)(list, "|"), first.ready, second.ready, first == second)

local function keys(record)
    local list = {}
    for key in record do
        (table.insert)(list, key)
    end
    return (table.concat)(list, ",")
end

print((true and keys)(first), (true and keys)(second), #first, #second)
first.alpha = 1
first.beta = 2
first.gamma = 3
first.ready = nil
first.delta = 4
first.ready = false
print((true and keys)(first), #first, first.ready, first.alpha)
first.beta = nil
first.epsilon = 5
local print2 = print
local value2 = (true and keys)(first)
local gamma = first.gamma
print2(value2, gamma, first.delta, first.epsilon)
local alias = first
alias.ready = 9
local print3 = print
gamma = first == alias
print3(gamma, first.ready, second.ready)
