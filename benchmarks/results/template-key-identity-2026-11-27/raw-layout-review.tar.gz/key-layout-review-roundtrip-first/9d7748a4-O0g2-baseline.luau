local function keys(value)
    local list = {}
    for key in value do
        (table.insert)(list, key)
    end
    return (table.concat)(list, ",")
end

local print2 = print
local data = { other = 8, ready = 5 }
local value2 = (true and keys)(data)
local data2 = { other = 8, ready = 5 }
print2("other", value2, (true and keys)(data2), (true and keys)(data) == (true and keys)(data2))
local print3 = print
local data3 = { alpha = 8, ready = 5 }
local value3 = (true and keys)(data3)
local data4 = { alpha = 8, ready = 5 }
print3("alpha", value3, (true and keys)(data4), (true and keys)(data3) == (true and keys)(data4))
local print4 = print
local data5 = { beta = 8, ready = 5 }
local value4 = (true and keys)(data5)
local data6 = { beta = 8, ready = 5 }
print4("beta", value4, (true and keys)(data6), (true and keys)(data5) == (true and keys)(data6))
local print5 = print
local data7 = { gamma = 8, ready = 5 }
local value5 = (true and keys)(data7)
local data8 = { gamma = 8, ready = 5 }
print5("gamma", value5, (true and keys)(data8), (true and keys)(data7) == (true and keys)(data8))
local print6 = print
local data9 = { delta = 8, ready = 5 }
local value6 = (true and keys)(data9)
local data10 = { delta = 8, ready = 5 }
print6("delta", value6, (true and keys)(data10), (true and keys)(data9) == (true and keys)(data10))
local print7 = print
local data11 = { epsilon = 8, ready = 5 }
local value7 = (true and keys)(data11)
local data12 = { epsilon = 8, ready = 5 }
print7("epsilon", value7, (true and keys)(data12), (true and keys)(data11) == (true and keys)(data12))
local print8 = print
local data13 = { abc = 8, ready = 5 }
local value8 = (true and keys)(data13)
local data14 = { abc = 8, ready = 5 }
print8("abc", value8, (true and keys)(data14), (true and keys)(data13) == (true and keys)(data14))
local print9 = print
local data15 = { x = 8, ready = 5 }
local value9 = (true and keys)(data15)
local data16 = { x = 8, ready = 5 }
print9("x", value9, (true and keys)(data16), (true and keys)(data15) == (true and keys)(data16))
local print10 = print
local data17 = { z = 8, ready = 5 }
local value10 = (true and keys)(data17)
local data18 = { z = 8, ready = 5 }
print10("z", value10, (true and keys)(data18), (true and keys)(data17) == (true and keys)(data18))
local print11 = print
local data19 = { one = 8, ready = 5 }
local value11 = (true and keys)(data19)
local data20 = { one = 8, ready = 5 }
print11("one", value11, (true and keys)(data20), (true and keys)(data19) == (true and keys)(data20))
