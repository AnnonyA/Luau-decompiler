local function keys(value)
    local list = {}
    for key in value do
        table.insert(list, key)
    end
    return table.concat(list, ",")
end

local print2 = print
local items = { other = 8, ready = 5 }
local list = {}
local items2 = { other = 8, ready = 5 }
for key2 in items do
    table.insert(list, key2)
end
local value2 = table.concat(list, ",")
local list2 = {}
for key3 in items2 do
    table.insert(list2, key3)
end
local value3 = table.concat(list2, ",")
local list3 = {}
for key4 in items do
    table.insert(list3, key4)
end
local value4 = table.concat(list3, ",")
local list4 = {}
for key5 in items2 do
    table.insert(list4, key5)
end
list2 = value4 == table.concat(list4, ",")
print2("other", value2, value3, list2)
local print3 = print
local items3 = { alpha = 8, ready = 5 }
local list5 = {}
local items4 = { alpha = 8, ready = 5 }
for key6 in items3 do
    table.insert(list5, key6)
end
local value5 = table.concat(list5, ",")
local list6 = {}
for key7 in items4 do
    table.insert(list6, key7)
end
local value6 = table.concat(list6, ",")
local list7 = {}
for key8 in items3 do
    table.insert(list7, key8)
end
local value7 = table.concat(list7, ",")
local list8 = {}
for key9 in items4 do
    table.insert(list8, key9)
end
list6 = value7 == table.concat(list8, ",")
print3("alpha", value5, value6, list6)
local print4 = print
local items5 = { beta = 8, ready = 5 }
local list9 = {}
local items6 = { beta = 8, ready = 5 }
for key10 in items5 do
    table.insert(list9, key10)
end
local value8 = table.concat(list9, ",")
local list10 = {}
for key11 in items6 do
    table.insert(list10, key11)
end
local value9 = table.concat(list10, ",")
local list11 = {}
for key12 in items5 do
    table.insert(list11, key12)
end
local value10 = table.concat(list11, ",")
local list12 = {}
for key13 in items6 do
    table.insert(list12, key13)
end
list10 = value10 == table.concat(list12, ",")
print4("beta", value8, value9, list10)
local print5 = print
local items7 = { gamma = 8, ready = 5 }
local list13 = {}
local items8 = { gamma = 8, ready = 5 }
for key14 in items7 do
    table.insert(list13, key14)
end
local value11 = table.concat(list13, ",")
local list14 = {}
for key15 in items8 do
    table.insert(list14, key15)
end
local value12 = table.concat(list14, ",")
local list15 = {}
for key16 in items7 do
    table.insert(list15, key16)
end
local value13 = table.concat(list15, ",")
local list16 = {}
for key17 in items8 do
    table.insert(list16, key17)
end
list14 = value13 == table.concat(list16, ",")
print5("gamma", value11, value12, list14)
local print6 = print
local items9 = { delta = 8, ready = 5 }
local list17 = {}
local items10 = { delta = 8, ready = 5 }
for key18 in items9 do
    table.insert(list17, key18)
end
local value14 = table.concat(list17, ",")
local list18 = {}
for key19 in items10 do
    table.insert(list18, key19)
end
local value15 = table.concat(list18, ",")
local list19 = {}
for key20 in items9 do
    table.insert(list19, key20)
end
local value16 = table.concat(list19, ",")
local list20 = {}
for key21 in items10 do
    table.insert(list20, key21)
end
list18 = value16 == table.concat(list20, ",")
print6("delta", value14, value15, list18)
local print7 = print
local items11 = { epsilon = 8, ready = 5 }
local list21 = {}
local items12 = { epsilon = 8, ready = 5 }
for key22 in items11 do
    table.insert(list21, key22)
end
local value17 = table.concat(list21, ",")
local list22 = {}
for key23 in items12 do
    table.insert(list22, key23)
end
local value18 = table.concat(list22, ",")
local list23 = {}
for key24 in items11 do
    table.insert(list23, key24)
end
local value19 = table.concat(list23, ",")
local list24 = {}
for key25 in items12 do
    table.insert(list24, key25)
end
list22 = value19 == table.concat(list24, ",")
print7("epsilon", value17, value18, list22)
local print8 = print
local items13 = { abc = 8, ready = 5 }
local list25 = {}
local items14 = { abc = 8, ready = 5 }
for key26 in items13 do
    table.insert(list25, key26)
end
local value20 = table.concat(list25, ",")
local list26 = {}
for key27 in items14 do
    table.insert(list26, key27)
end
local value21 = table.concat(list26, ",")
local list27 = {}
for key28 in items13 do
    table.insert(list27, key28)
end
local value22 = table.concat(list27, ",")
local list28 = {}
for key29 in items14 do
    table.insert(list28, key29)
end
list26 = value22 == table.concat(list28, ",")
print8("abc", value20, value21, list26)
local print9 = print
local items15 = { x = 8, ready = 5 }
local list29 = {}
local items16 = { x = 8, ready = 5 }
for key30 in items15 do
    table.insert(list29, key30)
end
local value23 = table.concat(list29, ",")
local list30 = {}
for key31 in items16 do
    table.insert(list30, key31)
end
local value24 = table.concat(list30, ",")
local list31 = {}
for key32 in items15 do
    table.insert(list31, key32)
end
local value25 = table.concat(list31, ",")
local list32 = {}
for key33 in items16 do
    table.insert(list32, key33)
end
list30 = value25 == table.concat(list32, ",")
print9("x", value23, value24, list30)
local print10 = print
local items17 = { z = 8, ready = 5 }
local list33 = {}
local items18 = { z = 8, ready = 5 }
for key34 in items17 do
    table.insert(list33, key34)
end
local value26 = table.concat(list33, ",")
local list34 = {}
for key35 in items18 do
    table.insert(list34, key35)
end
local value27 = table.concat(list34, ",")
local list35 = {}
for key36 in items17 do
    table.insert(list35, key36)
end
local value28 = table.concat(list35, ",")
local list36 = {}
for key37 in items18 do
    table.insert(list36, key37)
end
list34 = value28 == table.concat(list36, ",")
print10("z", value26, value27, list34)
local print11 = print
local items19 = { one = 8, ready = 5 }
local list37 = {}
local items20 = { one = 8, ready = 5 }
for key38 in items19 do
    table.insert(list37, key38)
end
local value29 = table.concat(list37, ",")
local list38 = {}
for key39 in items20 do
    table.insert(list38, key39)
end
local value30 = table.concat(list38, ",")
local list39 = {}
for key40 in items19 do
    table.insert(list39, key40)
end
local value31 = table.concat(list39, ",")
local list40 = {}
for key41 in items20 do
    table.insert(list40, key41)
end
list38 = value31 == table.concat(list40, ",")
print11("one", value29, value30, list38)
