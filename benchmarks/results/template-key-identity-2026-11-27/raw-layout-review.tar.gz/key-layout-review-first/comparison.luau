local function keys(value)
    local out = {}
    for key in value do table.insert(out, key) end
    return table.concat(out, ",")
end
do
 local before = {ready = 1, other = 8, ["ready"] = 5}
 local after = {other = 8, ["ready"] = 5}
 print("other", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, alpha = 8, ["ready"] = 5}
 local after = {alpha = 8, ["ready"] = 5}
 print("alpha", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, beta = 8, ["ready"] = 5}
 local after = {beta = 8, ["ready"] = 5}
 print("beta", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, gamma = 8, ["ready"] = 5}
 local after = {gamma = 8, ["ready"] = 5}
 print("gamma", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, delta = 8, ["ready"] = 5}
 local after = {delta = 8, ["ready"] = 5}
 print("delta", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, epsilon = 8, ["ready"] = 5}
 local after = {epsilon = 8, ["ready"] = 5}
 print("epsilon", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, abc = 8, ["ready"] = 5}
 local after = {abc = 8, ["ready"] = 5}
 print("abc", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, x = 8, ["ready"] = 5}
 local after = {x = 8, ["ready"] = 5}
 print("x", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, z = 8, ["ready"] = 5}
 local after = {z = 8, ["ready"] = 5}
 print("z", keys(before), keys(after), keys(before) == keys(after))
end
do
 local before = {ready = 1, one = 8, ["ready"] = 5}
 local after = {one = 8, ["ready"] = 5}
 print("one", keys(before), keys(after), keys(before) == keys(after))
end
