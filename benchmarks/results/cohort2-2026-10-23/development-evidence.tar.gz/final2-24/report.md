# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1, debug level 1.
12 programs; 24 profiles; 72 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| ledger | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| ledger | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| dispatch | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| dispatch | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| recursive-parser | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| recursive-parser | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| pack-pipeline | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| pack-pipeline | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| matrix-scope | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| matrix-scope | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| rollback | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| rollback | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| codec | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| codec | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| graph-walk | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| graph-walk | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| iterator-state | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| iterator-state | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| branch-phis | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| branch-phis | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| shadowed-constants | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| shadowed-constants | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| effect-schedule | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| effect-schedule | 1 | MATCH | NO MEDIDO | NO MEDIDO |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| ledger/O0 | annony | 3/3 | 0.779 | 21.9 |
| ledger/O0 | lunaux | — | — | — |
| ledger/O0 | luaexpert | — | — | — |
| ledger/O1 | annony | 3/3 | 0.804 | 4.9 |
| ledger/O1 | lunaux | — | — | — |
| ledger/O1 | luaexpert | — | — | — |
| dispatch/O0 | annony | 3/3 | 0.665 | 4.5 |
| dispatch/O0 | lunaux | — | — | — |
| dispatch/O0 | luaexpert | — | — | — |
| dispatch/O1 | annony | 3/3 | 0.773 | 2.6 |
| dispatch/O1 | lunaux | — | — | — |
| dispatch/O1 | luaexpert | — | — | — |
| recursive-parser/O0 | annony | 3/3 | 0.669 | 2.7 |
| recursive-parser/O0 | lunaux | — | — | — |
| recursive-parser/O0 | luaexpert | — | — | — |
| recursive-parser/O1 | annony | 3/3 | 0.747 | 2.1 |
| recursive-parser/O1 | lunaux | — | — | — |
| recursive-parser/O1 | luaexpert | — | — | — |
| pack-pipeline/O0 | annony | 3/3 | 0.724 | 3.2 |
| pack-pipeline/O0 | lunaux | — | — | — |
| pack-pipeline/O0 | luaexpert | — | — | — |
| pack-pipeline/O1 | annony | 3/3 | 0.728 | 2.6 |
| pack-pipeline/O1 | lunaux | — | — | — |
| pack-pipeline/O1 | luaexpert | — | — | — |
| matrix-scope/O0 | annony | 3/3 | 0.736 | 2.9 |
| matrix-scope/O0 | lunaux | — | — | — |
| matrix-scope/O0 | luaexpert | — | — | — |
| matrix-scope/O1 | annony | 3/3 | 0.766 | 2.1 |
| matrix-scope/O1 | lunaux | — | — | — |
| matrix-scope/O1 | luaexpert | — | — | — |
| rollback/O0 | annony | 3/3 | 0.696 | 2.4 |
| rollback/O0 | lunaux | — | — | — |
| rollback/O0 | luaexpert | — | — | — |
| rollback/O1 | annony | 3/3 | 0.753 | 2.7 |
| rollback/O1 | lunaux | — | — | — |
| rollback/O1 | luaexpert | — | — | — |
| codec/O0 | annony | 3/3 | 0.753 | 3.4 |
| codec/O0 | lunaux | — | — | — |
| codec/O0 | luaexpert | — | — | — |
| codec/O1 | annony | 3/3 | 0.680 | 2.0 |
| codec/O1 | lunaux | — | — | — |
| codec/O1 | luaexpert | — | — | — |
| graph-walk/O0 | annony | 3/3 | 0.663 | 3.2 |
| graph-walk/O0 | lunaux | — | — | — |
| graph-walk/O0 | luaexpert | — | — | — |
| graph-walk/O1 | annony | 3/3 | 0.692 | 2.5 |
| graph-walk/O1 | lunaux | — | — | — |
| graph-walk/O1 | luaexpert | — | — | — |
| iterator-state/O0 | annony | 3/3 | 0.646 | 1.6 |
| iterator-state/O0 | lunaux | — | — | — |
| iterator-state/O0 | luaexpert | — | — | — |
| iterator-state/O1 | annony | 3/3 | 0.798 | 1.5 |
| iterator-state/O1 | lunaux | — | — | — |
| iterator-state/O1 | luaexpert | — | — | — |
| branch-phis/O0 | annony | 3/3 | 0.509 | 3.0 |
| branch-phis/O0 | lunaux | — | — | — |
| branch-phis/O0 | luaexpert | — | — | — |
| branch-phis/O1 | annony | 3/3 | 0.538 | 2.3 |
| branch-phis/O1 | lunaux | — | — | — |
| branch-phis/O1 | luaexpert | — | — | — |
| shadowed-constants/O0 | annony | 3/3 | 0.775 | 1.5 |
| shadowed-constants/O0 | lunaux | — | — | — |
| shadowed-constants/O0 | luaexpert | — | — | — |
| shadowed-constants/O1 | annony | 3/3 | 0.853 | 1.1 |
| shadowed-constants/O1 | lunaux | — | — | — |
| shadowed-constants/O1 | luaexpert | — | — | — |
| effect-schedule/O0 | annony | 3/3 | 0.659 | 1.7 |
| effect-schedule/O0 | lunaux | — | — | — |
| effect-schedule/O0 | luaexpert | — | — | — |
| effect-schedule/O1 | annony | 3/3 | 0.743 | 1.7 |
| effect-schedule/O1 | lunaux | — | — | — |
| effect-schedule/O1 | luaexpert | — | — | — |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- ledger/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- ledger/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- ledger/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- ledger/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- dispatch/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- dispatch/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- dispatch/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- dispatch/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- recursive-parser/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- recursive-parser/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- recursive-parser/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- recursive-parser/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- pack-pipeline/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- pack-pipeline/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- pack-pipeline/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- pack-pipeline/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- matrix-scope/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- matrix-scope/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- matrix-scope/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- matrix-scope/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- rollback/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- rollback/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- rollback/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- rollback/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- codec/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- codec/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- codec/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- codec/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- graph-walk/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- graph-walk/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- graph-walk/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- graph-walk/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- iterator-state/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- iterator-state/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- iterator-state/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- iterator-state/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- branch-phis/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- branch-phis/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- branch-phis/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- branch-phis/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- shadowed-constants/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- shadowed-constants/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- shadowed-constants/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- shadowed-constants/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- effect-schedule/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- effect-schedule/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- effect-schedule/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- effect-schedule/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
