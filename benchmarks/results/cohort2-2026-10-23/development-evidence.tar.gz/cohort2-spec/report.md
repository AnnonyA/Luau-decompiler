# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
3 programs; 9 profiles; 108 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| archive-filesystem | 0 | MATCH | MATCH | MATCH |
| archive-filesystem | 1 | MATCH | MATCH | MATCH |
| archive-filesystem | 2 | MATCH | MISMATCH | MATCH |
| document-layout | 0 | MATCH | MATCH | MATCH |
| document-layout | 1 | MATCH | MATCH | MATCH |
| document-layout | 2 | MATCH | MATCH | MATCH |
| symbolic-algebra | 0 | MATCH | MISMATCH | MATCH |
| symbolic-algebra | 1 | MATCH | MISMATCH | MATCH |
| symbolic-algebra | 2 | MATCH | MISMATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| archive-filesystem/O0 | annony | 12/12 | 0.678 | 326.8 |
| archive-filesystem/O0 | lunaux | 12/12 | 0.845 | 476.5 |
| archive-filesystem/O0 | luaexpert | 12/12 | 0.838 | 8415.5 |
| archive-filesystem/O1 | annony | 12/12 | 0.689 | 296.5 |
| archive-filesystem/O1 | lunaux | 12/12 | 0.840 | 559.8 |
| archive-filesystem/O1 | luaexpert | 12/12 | 0.830 | 1852.6 |
| archive-filesystem/O2 | annony | 12/12 | 0.652 | 307.2 |
| archive-filesystem/O2 | lunaux | 0/12 | 0.750 | 555.8 |
| archive-filesystem/O2 | luaexpert | 12/12 | 0.737 | 1738.7 |
| document-layout/O0 | annony | 12/12 | 0.655 | 329.6 |
| document-layout/O0 | lunaux | 12/12 | 0.865 | 681.9 |
| document-layout/O0 | luaexpert | 12/12 | 0.871 | 1496.4 |
| document-layout/O1 | annony | 12/12 | 0.735 | 358.4 |
| document-layout/O1 | lunaux | 12/12 | 0.824 | 392.6 |
| document-layout/O1 | luaexpert | 12/12 | 0.842 | 1229.5 |
| document-layout/O2 | annony | 12/12 | 0.680 | 357.3 |
| document-layout/O2 | lunaux | 12/12 | 0.781 | 336.9 |
| document-layout/O2 | luaexpert | 12/12 | 0.784 | 2565.5 |
| symbolic-algebra/O0 | annony | 12/12 | 0.828 | 317.3 |
| symbolic-algebra/O0 | lunaux | 0/12 | 0.889 | 366.9 |
| symbolic-algebra/O0 | luaexpert | 12/12 | 0.927 | 2440.5 |
| symbolic-algebra/O1 | annony | 12/12 | 0.794 | 332.6 |
| symbolic-algebra/O1 | lunaux | 0/12 | 0.888 | 575.2 |
| symbolic-algebra/O1 | luaexpert | 12/12 | 0.913 | 2951.9 |
| symbolic-algebra/O2 | annony | 12/12 | 0.530 | 883.0 |
| symbolic-algebra/O2 | lunaux | 0/12 | 0.632 | 341.9 |
| symbolic-algebra/O2 | luaexpert | 12/12 | 0.664 | 2935.6 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- archive-filesystem/O2 lunaux: MISMATCH — execution error or different observable trace
- symbolic-algebra/O0 lunaux: MISMATCH — execution error or different observable trace
- symbolic-algebra/O1 lunaux: MISMATCH — execution error or different observable trace
- symbolic-algebra/O2 lunaux: MISMATCH — execution error or different observable trace
