# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
2 programs; 6 profiles; 72 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| constraint-search | 0 | MISMATCH | MATCH | MATCH |
| constraint-search | 1 | INVALID | MATCH | MATCH |
| constraint-search | 2 | INVALID | MISMATCH | MATCH |
| geometry-pipeline | 0 | MISMATCH | MATCH | MATCH |
| geometry-pipeline | 1 | MISMATCH | MATCH | MATCH |
| geometry-pipeline | 2 | MISMATCH | MATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| constraint-search/O0 | annony | 0/12 | 0.746 | 206.1 |
| constraint-search/O0 | lunaux | 12/12 | 0.919 | 421.2 |
| constraint-search/O0 | luaexpert | 12/12 | 0.947 | 1835.2 |
| constraint-search/O1 | annony | 0/12 | 0.751 | 179.2 |
| constraint-search/O1 | lunaux | 12/12 | 0.914 | 503.8 |
| constraint-search/O1 | luaexpert | 12/12 | 0.946 | 1806.0 |
| constraint-search/O2 | annony | 0/12 | 0.582 | 261.7 |
| constraint-search/O2 | lunaux | 0/12 | 0.701 | 278.7 |
| constraint-search/O2 | luaexpert | 12/12 | 0.720 | 2285.3 |
| geometry-pipeline/O0 | annony | 0/12 | 0.518 | 384.8 |
| geometry-pipeline/O0 | lunaux | 12/12 | 0.945 | 322.7 |
| geometry-pipeline/O0 | luaexpert | 12/12 | 0.946 | 2269.7 |
| geometry-pipeline/O1 | annony | 0/12 | 0.522 | 385.7 |
| geometry-pipeline/O1 | lunaux | 12/12 | 0.937 | 529.1 |
| geometry-pipeline/O1 | luaexpert | 12/12 | 0.943 | 2275.1 |
| geometry-pipeline/O2 | annony | 0/12 | 0.370 | 589.4 |
| geometry-pipeline/O2 | lunaux | 12/12 | 0.736 | 290.9 |
| geometry-pipeline/O2 | luaexpert | 12/12 | 0.738 | 4174.5 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- constraint-search/O0 annony: MISMATCH — execution error or different observable trace
- constraint-search/O1 annony: INVALID — official parser rejected reconstructed source
- constraint-search/O2 annony: INVALID — official parser rejected reconstructed source
- constraint-search/O2 lunaux: MISMATCH — execution error or different observable trace
- geometry-pipeline/O0 annony: MISMATCH — execution error or different observable trace
- geometry-pipeline/O1 annony: MISMATCH — execution error or different observable trace
- geometry-pipeline/O2 annony: MISMATCH — execution error or different observable trace
