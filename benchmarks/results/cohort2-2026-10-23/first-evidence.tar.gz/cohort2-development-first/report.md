# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
3 programs; 9 profiles; 108 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| archive-filesystem | 0 | MISMATCH | MATCH | MATCH |
| archive-filesystem | 1 | MISMATCH | MATCH | MATCH |
| archive-filesystem | 2 | MISMATCH | MISMATCH | MATCH |
| document-layout | 0 | MISMATCH | MATCH | MATCH |
| document-layout | 1 | MISMATCH | MATCH | MATCH |
| document-layout | 2 | MISMATCH | MATCH | MATCH |
| symbolic-algebra | 0 | MISMATCH | MISMATCH | MATCH |
| symbolic-algebra | 1 | MISMATCH | MISMATCH | MATCH |
| symbolic-algebra | 2 | MISMATCH | MISMATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| archive-filesystem/O0 | annony | 0/12 | 0.688 | 329.1 |
| archive-filesystem/O0 | lunaux | 12/12 | 0.845 | 476.5 |
| archive-filesystem/O0 | luaexpert | 12/12 | 0.838 | 8415.5 |
| archive-filesystem/O1 | annony | 0/12 | 0.703 | 362.4 |
| archive-filesystem/O1 | lunaux | 12/12 | 0.840 | 559.8 |
| archive-filesystem/O1 | luaexpert | 12/12 | 0.830 | 1852.6 |
| archive-filesystem/O2 | annony | 0/12 | 0.665 | 305.3 |
| archive-filesystem/O2 | lunaux | 0/12 | 0.750 | 555.8 |
| archive-filesystem/O2 | luaexpert | 12/12 | 0.737 | 1738.7 |
| document-layout/O0 | annony | 0/12 | 0.635 | 392.3 |
| document-layout/O0 | lunaux | 12/12 | 0.865 | 681.9 |
| document-layout/O0 | luaexpert | 12/12 | 0.871 | 1496.4 |
| document-layout/O1 | annony | 0/12 | 0.713 | 322.0 |
| document-layout/O1 | lunaux | 12/12 | 0.824 | 392.6 |
| document-layout/O1 | luaexpert | 12/12 | 0.842 | 1229.5 |
| document-layout/O2 | annony | 0/12 | 0.665 | 364.4 |
| document-layout/O2 | lunaux | 12/12 | 0.781 | 336.9 |
| document-layout/O2 | luaexpert | 12/12 | 0.784 | 2565.5 |
| symbolic-algebra/O0 | annony | 0/12 | 0.846 | 317.5 |
| symbolic-algebra/O0 | lunaux | 0/12 | 0.889 | 366.9 |
| symbolic-algebra/O0 | luaexpert | 12/12 | 0.927 | 2440.5 |
| symbolic-algebra/O1 | annony | 0/12 | 0.811 | 296.9 |
| symbolic-algebra/O1 | lunaux | 0/12 | 0.888 | 575.2 |
| symbolic-algebra/O1 | luaexpert | 12/12 | 0.913 | 2951.9 |
| symbolic-algebra/O2 | annony | 0/12 | 0.560 | 615.2 |
| symbolic-algebra/O2 | lunaux | 0/12 | 0.632 | 341.9 |
| symbolic-algebra/O2 | luaexpert | 12/12 | 0.664 | 2935.6 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- archive-filesystem/O0 annony: MISMATCH — execution error or different observable trace
- archive-filesystem/O1 annony: MISMATCH — execution error or different observable trace
- archive-filesystem/O2 annony: MISMATCH — execution error or different observable trace
- archive-filesystem/O2 lunaux: MISMATCH — execution error or different observable trace
- document-layout/O0 annony: MISMATCH — execution error or different observable trace
- document-layout/O1 annony: MISMATCH — execution error or different observable trace
- document-layout/O2 annony: MISMATCH — execution error or different observable trace
- symbolic-algebra/O0 annony: MISMATCH — execution error or different observable trace
- symbolic-algebra/O0 lunaux: MISMATCH — execution error or different observable trace
- symbolic-algebra/O1 annony: MISMATCH — execution error or different observable trace
- symbolic-algebra/O1 lunaux: MISMATCH — execution error or different observable trace
- symbolic-algebra/O2 annony: MISMATCH — execution error or different observable trace
- symbolic-algebra/O2 lunaux: MISMATCH — execution error or different observable trace
