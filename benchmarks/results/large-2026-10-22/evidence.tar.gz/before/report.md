# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
3 programs; 9 profiles; 108 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| protocol-router | 0 | MISMATCH | MATCH | MATCH |
| protocol-router | 1 | MISMATCH | MATCH | MATCH |
| protocol-router | 2 | MISMATCH | MATCH | MATCH |
| transaction-store | 0 | MISMATCH | MISMATCH | MATCH |
| transaction-store | 1 | MISMATCH | MISMATCH | MATCH |
| transaction-store | 2 | MISMATCH | MISMATCH | MATCH |
| workflow-scheduler | 0 | MISMATCH | MATCH | MATCH |
| workflow-scheduler | 1 | MISMATCH | MATCH | MATCH |
| workflow-scheduler | 2 | MISMATCH | MATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| protocol-router/O0 | annony | 0/12 | 0.867 | 165.0 |
| protocol-router/O0 | lunaux | 12/12 | 0.948 | 657.5 |
| protocol-router/O0 | luaexpert | 12/12 | 0.967 | 1502.6 |
| protocol-router/O1 | annony | 0/12 | 0.851 | 179.3 |
| protocol-router/O1 | lunaux | 12/12 | 0.938 | 600.6 |
| protocol-router/O1 | luaexpert | 12/12 | 0.963 | 1874.2 |
| protocol-router/O2 | annony | 0/12 | 0.752 | 222.0 |
| protocol-router/O2 | lunaux | 12/12 | 0.856 | 455.5 |
| protocol-router/O2 | luaexpert | 12/12 | 0.859 | 1426.9 |
| transaction-store/O0 | annony | 0/12 | 0.834 | 180.1 |
| transaction-store/O0 | lunaux | 0/12 | 0.920 | 706.2 |
| transaction-store/O0 | luaexpert | 12/12 | 0.910 | 2005.4 |
| transaction-store/O1 | annony | 0/12 | 0.794 | 195.0 |
| transaction-store/O1 | lunaux | 0/12 | 0.865 | 438.9 |
| transaction-store/O1 | luaexpert | 12/12 | 0.866 | 2292.5 |
| transaction-store/O2 | annony | 0/12 | 0.767 | 193.7 |
| transaction-store/O2 | lunaux | 0/12 | 0.839 | 395.0 |
| transaction-store/O2 | luaexpert | 12/12 | 0.838 | 1592.8 |
| workflow-scheduler/O0 | annony | 0/12 | 0.769 | 233.5 |
| workflow-scheduler/O0 | lunaux | 12/12 | 0.915 | 616.3 |
| workflow-scheduler/O0 | luaexpert | 12/12 | 0.925 | 2116.1 |
| workflow-scheduler/O1 | annony | 0/12 | 0.782 | 215.4 |
| workflow-scheduler/O1 | lunaux | 12/12 | 0.911 | 395.5 |
| workflow-scheduler/O1 | luaexpert | 12/12 | 0.923 | 1363.9 |
| workflow-scheduler/O2 | annony | 0/12 | 0.736 | 234.2 |
| workflow-scheduler/O2 | lunaux | 12/12 | 0.861 | 466.9 |
| workflow-scheduler/O2 | luaexpert | 12/12 | 0.873 | 2660.7 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- protocol-router/O0 annony: MISMATCH — execution error or different observable trace
- protocol-router/O1 annony: MISMATCH — execution error or different observable trace
- protocol-router/O2 annony: MISMATCH — execution error or different observable trace
- transaction-store/O0 annony: MISMATCH — execution error or different observable trace
- transaction-store/O0 lunaux: MISMATCH — execution error or different observable trace
- transaction-store/O1 annony: MISMATCH — execution error or different observable trace
- transaction-store/O1 lunaux: MISMATCH — execution error or different observable trace
- transaction-store/O2 annony: MISMATCH — execution error or different observable trace
- transaction-store/O2 lunaux: MISMATCH — execution error or different observable trace
- workflow-scheduler/O0 annony: MISMATCH — execution error or different observable trace
- workflow-scheduler/O1 annony: MISMATCH — execution error or different observable trace
- workflow-scheduler/O2 annony: MISMATCH — execution error or different observable trace
