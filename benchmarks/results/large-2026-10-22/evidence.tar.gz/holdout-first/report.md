# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
2 programs; 6 profiles; 72 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| query-planner | 0 | MISMATCH | MATCH | MATCH |
| query-planner | 1 | MISMATCH | MATCH | MATCH |
| query-planner | 2 | MISMATCH | MATCH | MATCH |
| reactive-simulation | 0 | MISMATCH | MISMATCH | MATCH |
| reactive-simulation | 1 | MISMATCH | MISMATCH | MATCH |
| reactive-simulation | 2 | MISMATCH | MISMATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| query-planner/O0 | annony | 0/12 | 0.808 | 201.8 |
| query-planner/O0 | lunaux | 12/12 | 0.931 | 488.1 |
| query-planner/O0 | luaexpert | 12/12 | 0.939 | 3739.4 |
| query-planner/O1 | annony | 0/12 | 0.835 | 200.4 |
| query-planner/O1 | lunaux | 12/12 | 0.911 | 465.1 |
| query-planner/O1 | luaexpert | 12/12 | 0.929 | 3578.2 |
| query-planner/O2 | annony | 0/12 | 0.669 | 293.8 |
| query-planner/O2 | lunaux | 12/12 | 0.748 | 603.9 |
| query-planner/O2 | luaexpert | 12/12 | 0.730 | 4764.3 |
| reactive-simulation/O0 | annony | 0/12 | 0.848 | 191.5 |
| reactive-simulation/O0 | lunaux | 0/12 | 0.970 | 402.8 |
| reactive-simulation/O0 | luaexpert | 12/12 | 0.977 | 2876.7 |
| reactive-simulation/O1 | annony | 0/12 | 0.851 | 183.4 |
| reactive-simulation/O1 | lunaux | 0/12 | 0.962 | 550.1 |
| reactive-simulation/O1 | luaexpert | 12/12 | 0.969 | 3075.2 |
| reactive-simulation/O2 | annony | 0/12 | 0.718 | 204.9 |
| reactive-simulation/O2 | lunaux | 0/12 | 0.849 | 525.5 |
| reactive-simulation/O2 | luaexpert | 12/12 | 0.860 | 3893.0 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- query-planner/O0 annony: MISMATCH — execution error or different observable trace
- query-planner/O1 annony: MISMATCH — execution error or different observable trace
- query-planner/O2 annony: MISMATCH — execution error or different observable trace
- reactive-simulation/O0 annony: MISMATCH — execution error or different observable trace
- reactive-simulation/O0 lunaux: MISMATCH — execution error or different observable trace
- reactive-simulation/O1 annony: MISMATCH — execution error or different observable trace
- reactive-simulation/O1 lunaux: MISMATCH — execution error or different observable trace
- reactive-simulation/O2 annony: MISMATCH — execution error or different observable trace
- reactive-simulation/O2 lunaux: MISMATCH — execution error or different observable trace
