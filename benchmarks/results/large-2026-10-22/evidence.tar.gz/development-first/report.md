# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
3 programs; 9 profiles; 108 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| protocol-router | 0 | MATCH | MATCH | MATCH |
| protocol-router | 1 | MATCH | MATCH | MATCH |
| protocol-router | 2 | MATCH | MATCH | MATCH |
| transaction-store | 0 | MATCH | MISMATCH | MATCH |
| transaction-store | 1 | MATCH | MISMATCH | MATCH |
| transaction-store | 2 | MATCH | MISMATCH | MATCH |
| workflow-scheduler | 0 | MATCH | MATCH | MATCH |
| workflow-scheduler | 1 | MATCH | MATCH | MATCH |
| workflow-scheduler | 2 | MATCH | MATCH | MATCH |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| protocol-router/O0 | annony | 12/12 | 0.872 | 215.0 |
| protocol-router/O0 | lunaux | 12/12 | 0.948 | 657.5 |
| protocol-router/O0 | luaexpert | 12/12 | 0.967 | 1502.6 |
| protocol-router/O1 | annony | 12/12 | 0.857 | 188.5 |
| protocol-router/O1 | lunaux | 12/12 | 0.938 | 600.6 |
| protocol-router/O1 | luaexpert | 12/12 | 0.963 | 1874.2 |
| protocol-router/O2 | annony | 12/12 | 0.756 | 245.7 |
| protocol-router/O2 | lunaux | 12/12 | 0.856 | 455.5 |
| protocol-router/O2 | luaexpert | 12/12 | 0.859 | 1426.9 |
| transaction-store/O0 | annony | 12/12 | 0.850 | 215.9 |
| transaction-store/O0 | lunaux | 0/12 | 0.920 | 706.2 |
| transaction-store/O0 | luaexpert | 12/12 | 0.910 | 2005.4 |
| transaction-store/O1 | annony | 12/12 | 0.809 | 191.9 |
| transaction-store/O1 | lunaux | 0/12 | 0.865 | 438.9 |
| transaction-store/O1 | luaexpert | 12/12 | 0.866 | 2292.5 |
| transaction-store/O2 | annony | 12/12 | 0.783 | 192.2 |
| transaction-store/O2 | lunaux | 0/12 | 0.839 | 395.0 |
| transaction-store/O2 | luaexpert | 12/12 | 0.838 | 1592.8 |
| workflow-scheduler/O0 | annony | 12/12 | 0.779 | 233.6 |
| workflow-scheduler/O0 | lunaux | 12/12 | 0.915 | 616.3 |
| workflow-scheduler/O0 | luaexpert | 12/12 | 0.925 | 2116.1 |
| workflow-scheduler/O1 | annony | 12/12 | 0.811 | 258.5 |
| workflow-scheduler/O1 | lunaux | 12/12 | 0.911 | 395.5 |
| workflow-scheduler/O1 | luaexpert | 12/12 | 0.923 | 1363.9 |
| workflow-scheduler/O2 | annony | 12/12 | 0.762 | 280.4 |
| workflow-scheduler/O2 | lunaux | 12/12 | 0.861 | 466.9 |
| workflow-scheduler/O2 | luaexpert | 12/12 | 0.873 | 2660.7 |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- transaction-store/O0 lunaux: MISMATCH — execution error or different observable trace
- transaction-store/O1 lunaux: MISMATCH — execution error or different observable trace
- transaction-store/O2 lunaux: MISMATCH — execution error or different observable trace
