local exercise = function(first, final)
    local cell = 4
    local saved = cell
    local function_
    function_ = function()
        return cell
    end

    local config = {}
    local condition
    function condition()
        cell = cell + 3
        config[#config + 1] = "condition"
        return final
    end

    if not first then
        if condition() then
            config[#config + 1] = "body"
            local print2 = print
            print2("selected", saved, function_())
        end
    else
        config[#config + 1] = "body"
        local print3 = print
        print3("selected", saved, function_())
    end
    local print4 = print
    local value = function_()
    print4("state", first, final, saved, value, table.concat(config, "/"))
end;
(true and exercise)(true, true);
(true and exercise)(false, true);
(true and exercise)(false, false)
local nested = function(flag, value)
    local config2 = {}
    if not flag then
        if 0 < value then
            for index = 1, value do
                local cell = index
                local function_2
                function_2 = function()
                    cell = cell + 1
                    return cell
                end

                config2[#config2 + 1] = function_2
                continue
            end
        end
    else
        for index2 = 1, value do
            local cell2 = index2
            local function_3
            function_3 = function()
                cell2 = cell2 + 1
                return cell2
            end

            config2[#config2 + 1] = function_3
            continue
        end
    end
    for _, value2 in config2 do
        local print5 = print
        local value3 = value2()
        print5("nested", value3, value2())
        continue
    end
end;
(true and nested)(false, 3);
(true and nested)(true, 2);
(true and nested)(false, 0)
