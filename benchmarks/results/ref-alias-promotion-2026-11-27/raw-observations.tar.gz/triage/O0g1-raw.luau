local exercise = function(value, index)
    local value2 = 4
    local function_
    function_ = function()
        return value2
    end

    local config = {}
    local condition
    function condition()
        value2 = value2 + 3
        config[#config + 1] = "condition"
        return index
    end

    if not value then
        if condition() then
            config[#config + 1] = "body"
            local print2 = print
            print2("selected", value2, function_())
        end
    else
        config[#config + 1] = "body"
        local print3 = print
        print3("selected", value2, function_())
    end
    local print4 = print
    local value3 = function_()
    print4("state", value, index, value2, value3, (table.concat)(config, "/"))
end;
(true and exercise)(true, true);
(true and exercise)(false, true);
(true and exercise)(false, false)
local nested = function(value4, index2)
    local config2 = {}
    if not value4 then
        if 0 < index2 then
            for index3 = 1, index2 do
                local index32 = index3
                local function_2
                function_2 = function()
                    index32 = index32 + 1
                    return index32
                end

                config2[#config2 + 1] = function_2
                continue
            end
        end
    else
        for index4 = 1, index2 do
            local index42 = index4
            local function_3
            function_3 = function()
                index42 = index42 + 1
                return index42
            end

            config2[#config2 + 1] = function_3
            continue
        end
    end
    for _, value5 in config2 do
        local print5 = print
        local value6 = value5()
        print5("nested", value6, value5())
        continue
    end
end;
(true and nested)(false, 3);
(true and nested)(true, 2);
(true and nested)(false, 0)
