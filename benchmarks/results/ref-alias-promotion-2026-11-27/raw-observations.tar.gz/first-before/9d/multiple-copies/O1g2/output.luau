-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:49:44Z
-- Luau bytecode version: 14 | Luau type version: 3

local function copies(initial, replacement)
    local cell = initial
    local first = cell
    local third = cell
    local function_ = function()
        return cell
    end
    local function replace()
        cell = replacement
        return cell
    end;

    (true and replace)()
    print("copies", first == initial, third == initial, third == initial, function_() == replacement, first == third, third == third)
    return first, nil, third, third, function_()
end

local function observe(...)
    local count = select("#", ...)
    local first, value, value2, value3, value4 = ...
    print("pack", count, value == nil, first == value2, value2 == value3, first == value4)
end

observe((true and copies)(4, 7))
observe((true and copies)(nil, false))
local data = { value = 8 }
local data2 = { value = 11 }
observe((true and copies)(data, data2))
print("tables", data.value, data2.value)
local firstFunction = function(): number
    return 13
end
local secondFunction = function(): number
    return 17
end
observe((true and copies)(firstFunction, secondFunction))
print("functions", firstFunction(), secondFunction())
