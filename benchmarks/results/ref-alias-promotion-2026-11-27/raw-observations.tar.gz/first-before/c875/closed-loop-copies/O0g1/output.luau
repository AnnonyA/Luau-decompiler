-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:49:45Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}
for index = 1, 3 do
    local sharedCounter = index
    local function_ = function()
        return sharedCounter
    end
    local function bump()
        sharedCounter += 10
        return sharedCounter
    end;

    (true and bump)()
    local index2 = sharedCounter
    local function_2 = function()
        return sharedCounter
    end;
    (true and bump)()
    local function_3 = function()
        local value = (true and function_)()
        return sharedCounter, sharedCounter, index2, value, (true and function_2)()
    end
    list[#list + 1] = function_3
    local sharedCounter2 = index * 100
    local function bump2()
        sharedCounter2 += 1
        return sharedCounter2
    end;

    (true and bump2)()
    local function_4 = function()
        return sharedCounter2, sharedCounter2, (true and bump2)()
    end
    list[#list + 1] = function_4
end
for key, callback in list do
    print("closed", key, callback())
    print("again", key, callback())
end
