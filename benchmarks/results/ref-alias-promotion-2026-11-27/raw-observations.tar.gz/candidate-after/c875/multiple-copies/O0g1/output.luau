-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:50:22Z
-- Luau bytecode version: 14 | Luau type version: 3

local function copies(p, p2)
    local value = p
    local snapshot = value
    local function_ = function()
        return value
    end
    local function replace()
        value = p2
        return value
    end;

    (true and replace)()
    print("copies", snapshot == p, snapshot == p, snapshot == p, function_() == p2, snapshot == snapshot, snapshot == snapshot)
    return snapshot, nil, snapshot, snapshot, function_()
end

local function observe(...)
    local count = select("#", ...)
    local first, value, value2, value3, value4 = ...
    print("pack", count, value == nil, first == value2, value2 == value3, first == value4)
end

observe((true and copies)(4, 7))
observe((true and copies)(nil, false))
local data = { value = 8 }
local data2 = { value = 11 }
observe((true and copies)(data, data2))
print("tables", data.value, data2.value)
local function_2 = function(): number
    return 13
end
local callback = function(): number
    return 17
end
observe((true and copies)(function_2, callback))
print("functions", function_2(), callback())
