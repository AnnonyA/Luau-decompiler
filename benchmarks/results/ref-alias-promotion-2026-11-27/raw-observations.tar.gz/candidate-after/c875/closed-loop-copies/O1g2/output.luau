-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-27T23:50:22Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}
for index = 1, 3 do
    local cell = index
    local second = cell
    local function_ = function()
        return cell
    end
    local function bump()
        cell += 10
        return cell
    end;

    (true and bump)()
    local afterFirstCapture = cell
    local function_2 = function()
        return cell
    end;
    (true and bump)()
    local function_3 = function()
        return second, second, afterFirstCapture, (true and function_)(), (true and function_2)()
    end
    list[#list + 1] = function_3
    local cell2 = index * 100
    local saved = cell2
    local function bump2()
        cell2 += 1
        return cell2
    end;

    (true and bump2)()
    local function_4 = function()
        return saved, cell2, (true and bump2)()
    end
    list[#list + 1] = function_4
end
for key, callback in list do
    print("closed", key, callback())
    print("again", key, callback())
end
