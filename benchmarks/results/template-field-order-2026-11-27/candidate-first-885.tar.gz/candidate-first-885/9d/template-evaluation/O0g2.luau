local list = {}

local function first(): (string, nil, string)
    list[#list + 1] = "first:" .. (debug.info)(2, "n")
    return "first-value", nil, "not-a-field"
end

local function second(): (boolean, nil, string)
    list[#list + 1] = "second:" .. (debug.info)(2, "n")
    return false, nil, "not-a-field"
end

local function assemble(left, right)
    return { early = left(), marker = 7, late = right(), tag = "done" }
end

local function withClosure(value)
    local function __callback()
        return value
    end

    local tbl = {}
    tbl["__callback"] = __callback
    tbl["count"] = 1
    local function __other()
        return value + 1
    end

    tbl["__other"] = __other
    tbl["tag"] = "closure"
    return tbl
end

local list2 = { assemble, withClosure }
local result = list2[1](first, second)
local print2 = print
local value2 = (table.concat)(list, "|")
local early = result.early
local late = result.late
local marker = result.marker
local tag = result.tag
local result2 = result[1] == nil
print2("calls", value2, early, late, marker, tag, result2)
local closure = list2[2](4)
local print3 = print
local value3 = (debug.info)(closure.__callback, "n")
local value4 = (debug.info)(closure.__other, "n")
local value5 = closure.__callback()
local value6 = closure.__other()
result2 = closure.__callback == closure.__other
print3("closures", value3, value4, value5, value6, result2)

local function extended(value)
    return { first = value, count = 1, extra = value, count = 2 }
end

local list3 = { extended }
local tbl = {}
local extra = list3[1](tbl)
local print4 = print
result2 = extra.first == tbl
print4("extra", result2, extra.extra == tbl, extra.count)
