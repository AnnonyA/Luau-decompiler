local list = {}

local function first(): (string, nil, string)
    list[#list + 1] = "first:" .. (debug.info)(2, "n")
    return "first-value", nil, "not-a-field"
end

local function second(): (boolean, nil, string)
    list[#list + 1] = "second:" .. (debug.info)(2, "n")
    return false, nil, "not-a-field"
end

local function assemble(callback, callback2)
    return { early = callback(), marker = 7, late = callback2(), tag = "done" }
end

local function withClosure(p)
    local function __callback()
        return p
    end

    local tbl = {}
    tbl["__callback"] = __callback
    tbl["count"] = 1
    local function __other()
        return p + 1
    end

    tbl["__other"] = __other
    tbl["tag"] = "closure"
    return tbl
end

local list2 = { assemble, withClosure }
local value = list2[1](first, second)
local print2 = print
local value2 = (table.concat)(list, "|")
local early = value.early
local late = value.late
local marker = value.marker
local tag = value.tag
local result = value[1] == nil
print2("calls", value2, early, late, marker, tag, result)
local value3 = list2[2](4)
local print3 = print
local value4 = (debug.info)(value3.__callback, "n")
local value5 = (debug.info)(value3.__other, "n")
local callback = value3.__callback()
local other = value3.__other()
result = value3.__callback == value3.__other
print3("closures", value4, value5, callback, other, result)

local function extended(extra)
    return { first = extra, count = 1, extra = extra, count = 2 }
end

local list3 = { extended }
local tbl = {}
local value6 = list3[1](tbl)
local print4 = print
result = value6.first == tbl
print4("extra", result, value6.extra == tbl, value6.count)
