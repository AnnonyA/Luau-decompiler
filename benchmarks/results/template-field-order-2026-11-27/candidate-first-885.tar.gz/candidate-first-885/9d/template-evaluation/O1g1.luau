local list = {}

local function first(): (string, nil, string)
    list[#list + 1] = "first:" .. debug.info(2, "n")
    return "first-value", nil, "not-a-field"
end

local function second(): (boolean, nil, string)
    list[#list + 1] = "second:" .. debug.info(2, "n")
    return false, nil, "not-a-field"
end

local function assemble(callback, callback2)
    return { early = callback(), marker = 7, late = callback2(), tag = "done" }
end

local function withClosure(p)
    return {
        __callback = function()
        return p
    end,
        count = 1,
        __other = function()
        return p + 1
    end,
        tag = "closure",
    }
end

local list2 = { assemble, withClosure }
local value = list2[1](first, second)
local print2 = print
local value2 = table.concat(list, "|")
local early = value.early
local late = value.late
local marker = value.marker
local tag = value.tag
print2("calls", value2, early, late, marker, tag, value[1] == nil)
local value3 = list2[2](4)
local print3 = print
local value4 = debug.info(value3.__callback, "n")
local value5 = debug.info(value3.__other, "n")
local callback = value3.__callback()
local other = value3.__other()
tag = value3.__callback == value3.__other
print3("closures", value4, value5, callback, other, tag)

local function extended(first2)
    return { first = first2, extra = first2, count = 2 }
end

local list3 = { extended }
local tbl = {}
local value6 = list3[1](tbl)
local print4 = print
value4 = value6.first == tbl
print4("extra", value4, value6.extra == tbl, value6.count)
