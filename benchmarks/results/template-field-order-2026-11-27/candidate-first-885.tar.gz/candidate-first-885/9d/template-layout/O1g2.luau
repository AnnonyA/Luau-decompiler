local function make(value)
    return {
        { ready = value, beta = 8 },
        { abc = value, beta = 8 },
        { x = value, beta = 8 },
        { z = value, beta = 8 },
        { epsilon = value, beta = 8 },
        { alpha = value, beta = 8 },
        { gamma = value, beta = 8 },
        { delta = value, beta = 8 },
        { one = value, beta = 8 },
        { other = value, beta = 8 },
        {
            first = value,
            marker = 3,
            last = value,
            tag = "tail",
        },
        { items = { value }, size = 1 },
    }
end

local make2 = make

local function observe(label, values)
    for key, value in values do
        local list = {}
        for key2, value2 in value do
            list[#list + 1] = key2 .. ":" .. type(value2)
        end
        print(label, key, table.concat(list, "|"))
    end
end

local list = { make2 };
(true and observe)("number", list[1](5));
(true and observe)("nil", list[1](nil));
(true and observe)("false", list[1](false))
