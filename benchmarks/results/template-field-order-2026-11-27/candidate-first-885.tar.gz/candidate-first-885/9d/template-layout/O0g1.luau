local function make(p)
    local list = { p }
    local data = { ready = p, beta = 8 }
    local data2 = { abc = p, beta = 8 }
    local data3 = { x = p, beta = 8 }
    local data4 = { z = p, beta = 8 }
    local data5 = { epsilon = p, beta = 8 }
    local data6 = { alpha = p, beta = 8 }
    local data7 = { gamma = p, beta = 8 }
    return {
        data,
        data2,
        data3,
        data4,
        data5,
        data6,
        data7,
        { delta = p, beta = 8 },
        { one = p, beta = 8 },
        { other = p, beta = 8 },
        {
            first = p,
            marker = 3,
            last = p,
            tag = "tail",
        },
        { size = 1, items = list },
    }
end

local make2 = make

local function observe(p, items)
    for key, items2 in items do
        local list = {}
        for key2, value in items2 do
            list[#list + 1] = key2 .. ":" .. type(value)
        end
        print(p, key, (table.concat)(list, "|"))
    end
end

local list = { make2 };
(true and observe)("number", list[1](5));
(true and observe)("nil", list[1](nil));
(true and observe)("false", list[1](false))
