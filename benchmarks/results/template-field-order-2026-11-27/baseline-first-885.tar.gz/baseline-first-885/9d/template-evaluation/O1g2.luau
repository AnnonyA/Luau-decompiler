local list = {}

local function first(): (string, nil, string)
    list[#list + 1] = "first:" .. debug.info(2, "n")
    return "first-value", nil, "not-a-field"
end

local function second(): (boolean, nil, string)
    list[#list + 1] = "second:" .. debug.info(2, "n")
    return false, nil, "not-a-field"
end

local function assemble(left, right)
    return { marker = 7, tag = "done", early = left(), late = right() }
end

local function withClosure(value)
    return {
        count = 1,
        tag = "closure",
        __callback = function()
        return value
    end,
        __other = function()
        return value + 1
    end,
    }
end

local list2 = { assemble, withClosure }
local result = list2[1](first, second)
local print2 = print
local value2 = table.concat(list, "|")
local early = result.early
local late = result.late
local marker = result.marker
local tag = result.tag
print2("calls", value2, early, late, marker, tag, result[1] == nil)
local closure = list2[2](4)
local print3 = print
local value3 = debug.info(closure.__callback, "n")
local value4 = debug.info(closure.__other, "n")
local value5 = closure.__callback()
local value6 = closure.__other()
tag = closure.__callback == closure.__other
print3("closures", value3, value4, value5, value6, tag)

local function extended(value)
    return { first = value, extra = value, count = 2 }
end

local list3 = { extended }
local tbl = {}
local extra = list3[1](tbl)
local print4 = print
value3 = extra.first == tbl
print4("extra", value3, extra.extra == tbl, extra.count)
