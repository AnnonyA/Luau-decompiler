-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:22:36Z
-- Luau bytecode version: 14 | Luau type version: 3

tag = "global-tag"

local function original(value)
    return value + 4, nil, value + 5
end

local print2 = print
local info = debug.info
local data = { renamed = original }
print2("alias", info(data.renamed, "n"), (true and data.renamed)(7))

local function compact()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local function sharedFunctionFactory(...)
    return ({
        tag = function()
        return tag
    end,
    }).tag
end

local data2 = { tag = sharedFunctionFactory() }
local data3 = { tag = sharedFunctionFactory() }
print("factory", debug.info(data2.tag, "n"), data2.tag == data3.tag, (true and data2.tag)(), (true and data3.tag)())

local function separated()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local tbl
local tag2
local closureStage: number = 1
while true do
    local loadedClosure = ({
        tag = function()
        return tag
    end,
    }).tag
    if closureStage ~= 1 then
        tag2 = loadedClosure
        break
    end
    tbl = { tag = 0 }
    tbl.tag = loadedClosure
    print("between", tbl.tag())
    closureStage = 2
end
local data4 = { tag = tag2 }
local tag3 = tbl.tag
local print3 = print
local value2 = debug.info(data4.tag, "n")
local tag4 = tbl.tag
local data5 = { [tag3] = "shared" }
print3("dispatcher", value2, tag4 == data4.tag, data5[data4.tag], (true and data4.tag)())
local print4 = print
local info2 = debug.info
local data6 = {}
data6.renamed = function()
    return "anonymous"
end

print4("anonymous", info2(data6.renamed, "n"), "anonymous")
