-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:29:00Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(p: number)
    local total = p
    local function read(p)
        local value = total
        total += p
        return value, total, nil
    end

    return { read = read }
end

local value = (true and packet)(4)
local value2 = (true and packet)(4)
print(debug.info(value.read, "n"), value.read == value2.read)
print(value.read(3))
print(value.read(2))
print(value2.read(1))

local function stable()
    local tbl = {}
    function tbl.tag()
        return 91
    end

    return tbl
end

local value3 = (true and stable)()
local value4 = (true and stable)()
local tag = value3.tag
local print2 = print
local value5 = debug.info(value3.tag, "n")
local tag2 = value3.tag
local data = { [tag] = "saved" }
print2(value5, tag2 == value4.tag, data[value4.tag], value3.tag())
local list = {}
for index = 1, 3 do
    local tbl = {}
    function tbl.take()
        return index
    end

    list[index] = tbl
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
