-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:28:58Z
-- Luau bytecode version: 14 | Luau type version: 3

tag = "global-tag"

local function original(value)
    return value + 4, nil, value + 5
end

local print2 = print
local info = debug.info
local data = { renamed = original }
print2("alias", (info)(data.renamed, "n"), (true and data.renamed)(7))

local function compact()
    local function tag2()
        return tag
    end

    return { tag = tag2 }
end

local first, second = (true and compact)(), (true and compact)()
print("factory", (debug.info)(first.tag, "n"), first.tag == second.tag, first.tag(), second.tag())

local function separated()
    local function tag2()
        return tag
    end

    return { tag = tag2 }
end

local before = (true and separated)()
print("between", before.tag())
local after = (true and separated)()
local tag3 = before.tag
local print3 = print
local value2 = (debug.info)(after.tag, "n")
local tag4 = before.tag
local data2 = { [tag3] = "shared" }
print3("dispatcher", value2, tag4 == after.tag, data2[after.tag], after.tag())
local named = function(): string
    return "anonymous"
end
local print4 = print
local info2 = debug.info
local data3 = { renamed = named }
print4("anonymous", (info2)(data3.renamed, "n"), (true and data3.renamed)())
