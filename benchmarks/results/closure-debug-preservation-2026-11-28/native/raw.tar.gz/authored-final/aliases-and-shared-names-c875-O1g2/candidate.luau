-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:28:59Z
-- Luau bytecode version: 14 | Luau type version: 3

tag = "global-tag"

local function original(value)
    return value + 4, nil, value + 5
end

local print2 = print
local info = debug.info
local data = { renamed = original }
print2("alias", info(data.renamed, "n"), (true and data.renamed)(7))

local function compact()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local value2 = (true and compact)()
local second = (true and compact)()
print("factory", debug.info(value2.tag, "n"), value2.tag == second.tag, value2.tag(), second.tag())

local function separated()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local before = (true and separated)()
print("between", before.tag())
local after = (true and separated)()
local tag2 = before.tag
local print3 = print
local value3 = debug.info(after.tag, "n")
local tag3 = before.tag
local data2 = { [tag2] = "shared" }
print3("dispatcher", value3, tag3 == after.tag, data2[after.tag], after.tag())
local print4 = print
local info2 = debug.info
local data3 = {}
data3.renamed = function()
    return "anonymous"
end

print4("anonymous", info2(data3.renamed, "n"), (true and data3.renamed)())
