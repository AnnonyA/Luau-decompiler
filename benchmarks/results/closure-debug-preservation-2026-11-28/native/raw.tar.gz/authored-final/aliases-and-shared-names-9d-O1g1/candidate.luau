-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:28:58Z
-- Luau bytecode version: 14 | Luau type version: 3

tag = "global-tag"

local function original(p)
    return p + 4, nil, p + 5
end

local print2 = print
local info = debug.info
local data = { renamed = original }
print2("alias", info(data.renamed, "n"), (true and data.renamed)(7))

local function compact()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local value = (true and compact)()
local value2 = (true and compact)()
print("factory", debug.info(value.tag, "n"), value.tag == value2.tag, value.tag(), value2.tag())

local function separated()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local value3 = (true and separated)()
print("between", value3.tag())
local value4 = (true and separated)()
local tag2 = value3.tag
local print3 = print
local value5 = debug.info(value4.tag, "n")
local tag3 = value3.tag
local data2 = { [tag2] = "shared" }
print3("dispatcher", value5, tag3 == value4.tag, data2[value4.tag], value4.tag())
local print4 = print
local info2 = debug.info
local data3 = {}
data3.renamed = function()
    return "anonymous"
end

print4("anonymous", info2(data3.renamed, "n"), (true and data3.renamed)())
