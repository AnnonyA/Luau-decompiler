-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:28:58Z
-- Luau bytecode version: 14 | Luau type version: 3

tag = "global-tag"

local function original(p)
    return p + 4, nil, p + 5
end

local print2 = print
local info = debug.info
local data = { renamed = original }
print2("alias", info(data.renamed, "n"), (true and data.renamed)(7))

local function compact()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local function sharedFunctionFactory(...)
    return function()
        return tag
    end
end

local data2 = { tag = sharedFunctionFactory() }
local data3 = { tag = sharedFunctionFactory() }
print("factory", debug.info(data2.tag, "n"), data2.tag == data3.tag, (true and data2.tag)(), (true and data3.tag)())

local function separated()
    local tbl = {}
    function tbl.tag()
        return tag
    end

    return tbl
end

local print3 = print
local tbl = {}

function tbl.tag()
    return tag
end

print3("between", (true and tbl.tag)())
local tag2 = tbl.tag
local print4 = print
local info2 = debug.info
local tbl2 = {}

function tbl2.tag()
    return tag
end

local value = info2(tbl2.tag, "n")
local tag3 = tbl.tag
local data4 = { [tag2] = "shared" }
print4("dispatcher", value, tag3 == tbl2.tag, data4[tbl2.tag], (true and tbl2.tag)())
local print5 = print
local info3 = debug.info
local data5 = {}
data5.renamed = function()
    return "anonymous"
end

print5("anonymous", info3(data5.renamed, "n"), "anonymous")
