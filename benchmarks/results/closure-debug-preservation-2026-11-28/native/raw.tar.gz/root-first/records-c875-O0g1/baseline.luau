-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:17:38Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(p: number)
    local total = p
    local function read(p)
        local value = total
        total += p
        return value, total, nil
    end

    return { read = read }
end

local value = (true and packet)(4)
local value2 = (true and packet)(4)
print((debug.info)(value.read, "n"), value.read == value2.read)
print(value.read(3))
print(value.read(2))
print(value2.read(1))

local function stable()
    local function tag(): number
        return 91
    end

    return { tag = tag }
end

local value3 = (true and stable)()
local value4 = (true and stable)()
local tag2 = value3.tag
local print2 = print
local value5 = (debug.info)(value3.tag, "n")
local tag3 = value3.tag
local data = { [tag2] = "saved" }
print2(value5, tag3 == value4.tag, data[value4.tag], value3.tag())
local list = {}
for index = 1, 3 do
    local function take()
        return index
    end

    list[index] = { take = take }
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
