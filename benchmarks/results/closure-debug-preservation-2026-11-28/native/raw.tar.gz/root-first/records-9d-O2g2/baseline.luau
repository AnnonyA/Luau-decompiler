-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:17:38Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(seed)
    local state = seed
    local read
    function read(delta)
        local previous = state
        state += delta
        return previous, state, nil
    end

    return { read = read }
end

local state: number = 4
local read
function read(delta)
    local previous = state
    state += delta
    return previous, state, nil
end

local data = { read = read }
local state2: number = 4

local function read2(delta)
    local previous = state2
    state2 += delta
    return previous, state2, nil
end

local data2 = { read = read2 }
print(debug.info(data.read, "n"), data.read == data2.read)
print((true and data.read)(3))
print((true and data.read)(2))
print((true and data2.read)(1))

local function stable()
    local tbl = {}
    function tbl.tag()
        return 91
    end

    return tbl
end

local function sharedFunctionFactory(...)
    return function()
        return 91
    end
end

local sharedFunction = sharedFunctionFactory()
local tag = sharedFunction
local closureValue = sharedFunctionFactory()
local tag2 = closureValue
local data3 = { tag = tag }
local tag3 = data3.tag
local print2 = print
local value = debug.info(data3.tag, "n")
local tag4 = data3.tag
local data4 = { tag = tag2 }
local data5 = { [tag3] = "saved" }
print2(value, tag4 == data4.tag, data5[data4.tag], (true and data3.tag)())
local list = {}
for index = 1, 3 do
    local tbl = {}
    function tbl.take()
        return index
    end

    list[index] = tbl
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
