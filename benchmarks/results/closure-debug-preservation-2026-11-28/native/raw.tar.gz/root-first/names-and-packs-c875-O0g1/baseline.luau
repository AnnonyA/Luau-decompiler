-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:17:37Z
-- Luau bytecode version: 14 | Luau type version: 3

local function read(): string
    return "outer"
end

local print2 = print
local data = { read = read }
print2((true and data.read)(), (debug.info)(data.read, "n"))

local function packet()
    local function values(...)
        return select("#", ...), ...
    end

    return { values = values }
end

local value = (true and packet)()
print((debug.info)(value.values, "n"), value.values(1, nil, 3))
print(value.values())

local function sum(p)
    return if p == 0 then 0 else p + sum(p - 1)
end

local print3 = print
local data2 = { sum = sum }
print3((true and data2.sum)(4), (debug.info)(data2.sum, "n"))

local function original(): number
    return 17
end

local print4 = print
local data3 = { alias = original }
print4((true and data3.alias)(), (debug.info)(data3.alias, "n"))
