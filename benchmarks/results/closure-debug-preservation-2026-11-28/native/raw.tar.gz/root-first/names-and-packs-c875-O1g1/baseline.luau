-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:17:37Z
-- Luau bytecode version: 14 | Luau type version: 3

local print2 = print
local tbl = {}

function tbl.read()
    return "outer"
end

print2((true and tbl.read)(), debug.info(tbl.read, "n"))

local function packet()
    local tbl = {}
    function tbl.values(...)
        return select("#", ...), ...
    end

    return tbl
end

local value = (true and packet)()
print(debug.info(value.values, "n"), value.values(1, nil, 3))
print(value.values())

local function sum(p)
    return if p == 0 then 0 else p + sum(p - 1)
end

local print3 = print
local data = { sum = sum }
print3((true and data.sum)(4), debug.info(data.sum, "n"))
local print4 = print
local data2 = {}
data2.alias = function()
    return 17
end

print4((true and data2.alias)(), debug.info(data2.alias, "n"))
