-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:24:11Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make()
    local function tag(): string
        return "value"
    end

    return tag
end

local value = gcinfo()
local result
for index = 1, 200 do
    local value2 = (true and make)()
    local _ = gcinfo()
    local assert2 = assert
    result = value2 == (true and make)()
    assert2(result)
end
local value3 = gcinfo()
print("allocation", value3 - value)
