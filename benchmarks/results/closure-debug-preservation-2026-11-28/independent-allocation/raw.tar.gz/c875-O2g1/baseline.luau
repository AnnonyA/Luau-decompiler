-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:24:11Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make()
    local function tag(): string
        return "value"
    end

    return tag
end

local value = gcinfo()
local result
for index = 1, 200 do
    local loadedClosure2
    local loadedClosure3
    local closureStage: number = 1
    while true do
        local function loadedClosure(): string
            return "value"
        end

        if closureStage ~= 1 then
            loadedClosure3 = loadedClosure
            break
        end
        loadedClosure2 = loadedClosure
        local _ = gcinfo()
        closureStage = 2
    end
    result = loadedClosure2 == loadedClosure3
    assert(result)
end
local value2 = gcinfo()
print("allocation", value2 - value)
