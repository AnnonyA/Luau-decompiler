from pathlib import Path
import argparse,concurrent.futures,hashlib,json,shutil,subprocess
parser=argparse.ArgumentParser()
parser.add_argument('--dist',required=True,type=Path)
parser.add_argument('--out',required=True,type=Path)
parser.add_argument('--seal',action='store_true')
args=parser.parse_args()
root=Path('/workspace/scratch/1c4124dc88e4');refs=Path('/workspace/scratch/eb5e4be57451')
fixtures=root/'engine-return-regions/tests/fixtures/scalar-return-regions';out=args.out
out.mkdir(parents=True,exist_ok=False)
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
pins={'9d':(refs/'reference-luau-ci/build/release/luau-compile',refs/'quality-research/v2-call-boundary-probe/run-bytecode-9d'), 'c875':(refs/'reference-luau/build/release/luau-compile',refs/'quality-research/v2-call-boundary-probe/run-bytecode-c875')}
dist=out/'engine-dist';shutil.copytree(args.dist,dist)
(out/'engine-snapshot.json').write_text(json.dumps({str(p.relative_to(dist)):sha(p) for p in sorted(dist.rglob('*')) if p.is_file()},indent=2)+'\n')
if args.seal:
 assert not (fixtures/'manifest.json').exists()
 manifest={'sources':[{'path':p.name,'sha256':sha(p)} for p in sorted(fixtures.glob('*.luau'))],'inputs':[],'pins':{key:{'compilerSha256':sha(compiler),'hostSha256':sha(host)} for key,(compiler,host) in pins.items()}}
 for source in manifest['sources']:
  for pin,(compiler,host) in pins.items():
   for opt in range(3):
    for debug in [1,2]:
     profile=f'O{opt}g{debug}';path=fixtures/(Path(source['path']).stem+'-'+pin+'-'+profile+'.luauc');assert not path.exists()
     command=list(map(str,[compiler,'--binary','-O'+str(opt),'-g'+str(debug),fixtures/source['path']]))
     compiled=subprocess.run(command,capture_output=True,timeout=30);assert compiled.returncode==0,compiled.stderr
     path.write_bytes(compiled.stdout)
     manifest['inputs'].append({'path':path.name,'source':source['path'],'pin':pin,'profile':profile,'sha256':sha(path),'command':command})
 (fixtures/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
else:manifest=json.loads((fixtures/'manifest.json').read_text())
for source in manifest['sources']:assert sha(fixtures/source['path'])==source['sha256']
for row in manifest['inputs']:assert sha(fixtures/row['path'])==row['sha256']
shutil.copy2(fixtures/'manifest.json',out/'input-manifest.json')
def check(row):
 folder=out/'cases'/Path(row['path']).stem;folder.mkdir(parents=True)
 compiler,host=pins[row['pin']];commands=[]
 def run(command,name):
  command=list(map(str,command));p=subprocess.run(command,capture_output=True,timeout=30)
  (folder/(name+'.stdout')).write_bytes(p.stdout);(folder/(name+'.stderr')).write_bytes(p.stderr)
  commands.append({'command':command,'exitCode':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'});return p
 original=run([host,fixtures/row['path']],'original')
 decompiled=run([node,dist/'cli.js','decompile',fixtures/row['path']],'decompile')
 source=folder/'candidate.luau';source.write_bytes(decompiled.stdout)
 compiled=run([compiler,'--binary','-O'+row['profile'][1],'-g'+row['profile'][3],source],'compile')
 bytecode=folder/'candidate.luauc';bytecode.write_bytes(compiled.stdout)
 actual=run([host,bytecode],'actual')
 (folder/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return {**row,'originalValid':original.returncode==0,'match':original.returncode==decompiled.returncode==compiled.returncode==actual.returncode==0 and original.stdout==actual.stdout and original.stderr==actual.stderr,'codes':[original.returncode,decompiled.returncode,compiled.returncode,actual.returncode],'originalStdout':original.stdout.decode(),'stdout':actual.stdout.decode(),'stderr':actual.stderr.decode(),'sourceSha256':sha(source),'bytecodeSha256':sha(bytecode)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(check,manifest['inputs']))
summary={'total':len(rows),'originalValid':sum(row['originalValid'] for row in rows),'passed':sum(row['match'] for row in rows),'failures':[row['path'] for row in rows if not row['match']],'rows':rows}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
