-- Unknown iteration, effectful inputs and non-scalar returns must decline.
local trace = {}
local function find(values, needle)
    for index, value in values do
        if value == needle then return index end
    end
    return 0
end
local function input()
    table.insert(trace, "input")
    return {1, 2, 3}
end
local function needle()
    table.insert(trace, "needle")
    return 2, 99
end
local selected = find(input(), needle())
print("effects", selected, table.concat(trace, ","))

local iterator = setmetatable({}, {__iter = function()
    table.insert(trace, debug.info(2, "n"))
    return next, {5, 6, 7}, nil
end})
local observed = find(iterator, 6)
print("iterator", observed, table.concat(trace, ","))

local function packFind(values, needle)
    for index, value in values do
        if value == needle then return index, nil, value end
    end
    return nil
end
local function report(...)
    print("pack", select("#", ...), ...)
end
report(packFind({1, 2, 3}, 2))
report(packFind({1, 2, 3}, 9))
