-- Return and break from nested loops have different targets.
local function nested(rows, needle)
    for rowIndex, row in rows do
        for column, value in row do
            if value == needle then return rowIndex * 10 + column end
        end
    end
    return 0
end
local a = nested({{1, 2}, {3, 4}}, 3)
local b = nested({{1, 2}, {3, 4}}, 9)
print("nested", a, b)

local function find(values, needle)
    for index, value in values do
        if value == needle then return index end
    end
    return 0
end
local value = find({11, 22, 33}, 22)
local read = function() return value end
value += 10
print("cell", value, read())

local original = find
find = function() return -1 end
print("alias", original({11, 22, 33}, 33), find({11, 22, 33}, 33))
