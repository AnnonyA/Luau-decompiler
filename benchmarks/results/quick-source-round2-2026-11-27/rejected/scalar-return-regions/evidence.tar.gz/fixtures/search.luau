-- Project-authored scalar search regions with early returns.
local function find(values, needle)
    for index, value in values do
        if value == needle then
            return index
        end
    end
    return 0
end
local first = find({2, 4, 6}, 4)
local absent = find({2, 4, 6}, 9)
local hole = find({2, nil, 6}, 6)
print("find", first, absent, hole)

local function contains(values, needle)
    for _, value in values do
        if value == needle then return true end
    end
    return false
end
local yes = contains({"red", "green", "blue"}, "green")
local no = contains({"red", "green", "blue"}, "black")
print("contains", yes, no)

local function choose(values, needle)
    for _, value in values do
        if value == needle then return value end
    end
    return nil
end
local found = choose({false, 0, "x"}, false)
local missing = choose({false, 0, "x"}, "missing")
print("choose", found, missing)
