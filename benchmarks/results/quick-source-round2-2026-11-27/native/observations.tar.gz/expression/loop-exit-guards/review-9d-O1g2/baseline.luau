-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:17Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(mode)
    local total: number = 0
    local function_ = function()
        return total
    end
    local result: number = -1
    local list = {}
    local function mark(name: string, value)
        table.insert(list, name .. ":" .. value .. ":" .. (true and function_)())
        return value, nil, "ignored"
    end

    local list2 = {}
    repeat
        total += 1
        local cell = total
        local function_2 = function()
            return cell, total
        end
        if mode == 1 and total == 2 then
            cell += 100
            total += 10
            result = total
            list2[#list2 + 1] = function_2;
            (true and mark)("first", total)
            break
        end
        if mode == 2 and total == 3 then
            cell += 200
            total += 20
            result = total
            list2[#list2 + 1] = function_2;
            (true and mark)("second", total)
            break
        end
        list2[#list2 + 1] = function_2
        cell += 1
        local snapshot = total
    until (true and mark)("until", snapshot) == 4
    total += 1000
    return result, function_(), list2, table.concat(list, ",")
end

for index = 1, 3 do
    local selected, observed, saved, trace = (true and exercise)(index)
    print("repeat", index, selected, observed, trace)
    for key, value2 in saved do
        print("saved", key, value2())
    end
end

local function shared(mode: number)
    local total: number = 0
    local function_3 = function()
        return total
    end
    local result4 = nil
    local list = {}
    for index2 = 1, 6 do
        if mode == 1 and index2 == 2 then
            total = index2 * 10
            result4 = function()
                return total, index2
            end

            table.insert(list, function_3())
            break
        end
        if mode == 2 and index2 == 4 then
            total = index2 * 10
            result4 = function()
                return total, index2
            end

            table.insert(list, function_3())
            break
        end
        total += 1
        table.insert(list, function_3())
    end
    local before = function_3()
    total += 100
    if result4 then
        print("shared", mode, before, function_3(), result4())
    else
        print("shared", mode, before, function_3(), "none")
    end
    print(table.concat(list, ","))
end;

(true and shared)(1);
(true and shared)(2);
(true and shared)(3)
