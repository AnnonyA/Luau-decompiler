-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:17Z
-- Luau bytecode version: 14 | Luau type version: 3

local function exercise(p)
    local total: number = 0
    local function_ = function()
        return total
    end
    local result: number = -1
    local list = {}
    local function mark(p: string, p2)
        table.insert(list, p .. ":" .. p2 .. ":" .. (true and function_)())
        return p2, nil, "ignored"
    end

    local list2 = {}
    repeat
        total += 1
        local total2 = total
        local function_2 = function()
            return total2, total
        end
        if p == 1 and total == 2 then
            total2 += 100
            total += 10
            result = total
            list2[#list2 + 1] = function_2;
            (true and mark)("first", total)
            break
        end
        if p == 2 and total == 3 then
            total2 += 200
            total += 20
            result = total
            list2[#list2 + 1] = function_2;
            (true and mark)("second", total)
            break
        end
        list2[#list2 + 1] = function_2
        total2 += 1
    until (true and mark)("until", total) == 4
    total += 1000
    return result, function_(), list2, table.concat(list, ",")
end

for i = 1, 3 do
    local result, value, items, value2 = (true and exercise)(i)
    print("repeat", i, result, value, value2)
    for key, callback in items do
        print("saved", key, callback())
    end
end

local function shared(p: number)
    local total: number = 0
    local function_3 = function()
        return total
    end
    local result6 = nil
    local list = {}
    for i = 1, 6 do
        if p == 1 and i == 2 then
            total = i * 10
            result6 = function()
                return total, i
            end

            table.insert(list, function_3())
            break
        end
        if p == 2 and i == 4 then
            total = i * 10
            result6 = function()
                return total, i
            end

            table.insert(list, function_3())
            break
        end
        total += 1
        table.insert(list, function_3())
    end
    local value = function_3()
    total += 100
    if result6 then
        print("shared", p, value, function_3(), result6())
    else
        print("shared", p, value, function_3(), "none")
    end
    print(table.concat(list, ","))
end;

(true and shared)(1);
(true and shared)(2);
(true and shared)(3)
