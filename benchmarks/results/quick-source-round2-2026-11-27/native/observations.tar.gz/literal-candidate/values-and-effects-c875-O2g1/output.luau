-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:15Z
-- Luau bytecode version: 14 | Luau type version: 3

local function callback(): string
    return "callback"
end

local data = { tag = "object" }

local function describe(p)
    return if p == data then "object" elseif p == callback then "callback" else tostring(p)
end

local list = {}

local function produce(p)
    table.insert(list, "produce:" .. p)
    if p == 0 then
        return
    end
    if p == 1 then
        return nil, "extra", false
    elseif p == 2 then
        return false, true
    elseif p == 3 then
        return data, "extra"
    else
        return callback, data, nil
    end
end

local function choose(p, p2)
    local flag: boolean = false
    if p then
        table.insert(list, "produce:" .. p2)
        if p2 == 0 or p2 == 1 then
            return nil
        elseif p2 == 2 then
            return false
        elseif p2 == 3 then
            return data
        end
        flag = callback
        return flag
    end
    return flag
end

local function chooseNil(p, p2)
    local result = nil
    if p then
        table.insert(list, "produce:" .. p2)
        if p2 == 0 or p2 == 1 then
            return nil
        elseif p2 == 2 then
            return false
        elseif p2 == 3 then
            return data
        end
        result = callback
        return result
    end
    return result
end

local function chooseTrue(a, b, c)
    local flag: boolean = true
    if a < b then
        table.insert(list, "produce:" .. c)
        if c == 0 or c == 1 then
            return nil
        elseif c == 2 then
            return false
        elseif c == 3 then
            return data
        end
        flag = callback
        return flag
    end
    return flag
end

local function emit(p, ...)
    local first = ...
    print(p, select("#", ...), if first == data then "object" else if first == callback then "callback" else tostring(first))
end

local items = { false, true, 0, "", data, callback }
for _, value in items do
    local result
    for i = 0, 4 do
        local flag: boolean = false
        if value then
            table.insert(list, "produce:" .. i)
            flag = if i == 0 then nil elseif i == 1 then nil elseif i == 2 then false elseif i == 3 then data else callback
        end
        emit("false-default", flag)
        result = nil
        if value then
            table.insert(list, "produce:" .. i)
            result = if i == 0 then nil elseif i == 1 then nil elseif i == 2 then false elseif i == 3 then data else callback
        end
        emit("nil-default", result)
    end
end
local result2
for i2 = 0, 4 do
    emit("nil-test", false)
    emit("nil-test-default", nil)
    emit("nan", true)
    table.insert(list, "produce:" .. i2)
    result2 = if i2 == 0 then nil else if i2 == 1 then nil elseif i2 == 2 then false elseif i2 == 3 then data else callback
    emit("ordered", result2)
    emit("reversed", true)
end
local data2 = {}
data2.__lt = function(p, p2)
    table.insert(list, "compare:" .. p.value .. ":" .. p2.value)
    return p.value < p2.value
end

local value2 = setmetatable({ value = 1 }, data2)
local value3 = setmetatable({ value = 2 }, data2)
local flag2: boolean = true
if value2 < value3 then
    table.insert(list, "produce:" .. 3)
    flag2 = data
end
emit("meta-yes", flag2)
local flag3: boolean = true
if value3 < value2 then
    table.insert(list, "produce:" .. 3)
    flag3 = data
end
emit("meta-no", flag3)
local sharedCounter: number = 0

local function inspect(p)
    return p ~= nil and p.ready ~= nil
end

local function __index(p, p2): boolean
    sharedCounter += 1
    table.insert(list, "read:" .. p2)
    return false
end

local value4 = setmetatable({}, { __index = __index })
emit("read-present", value4 ~= nil and value4.ready ~= nil)
emit("read-absent", false)
print("reads", sharedCounter)
print(table.concat(list, ","))
