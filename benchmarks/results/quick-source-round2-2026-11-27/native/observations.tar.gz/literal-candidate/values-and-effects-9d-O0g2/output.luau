-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:13Z
-- Luau bytecode version: 14 | Luau type version: 3

local function callback(): string
    return "callback"
end

local data = { tag = "object" }

local function describe(first2)
    if first2 == data then
        return "object"
    end
    if first2 == callback then
        return "callback"
    end
    return tostring(first2)
end

local list = {}

local function produce(mode)
    (table.insert)(list, "produce:" .. mode)
    if mode == 0 then
        return
    end
    if mode == 1 then
        return nil, "extra", false
    elseif mode == 2 then
        return false, true
    elseif mode == 3 then
        return data, "extra"
    else
        return callback, data, nil
    end
end

local function choose(test, mode)
    local result = if test then (true and produce)(mode) else false
    return result
end

local function chooseNil(test, mode)
    return if test then (true and produce)(mode) else nil
end

local function chooseTrue(left, right, mode)
    return not (left < right) or (true and produce)(mode)
end

local function emit(value, ...)
    local first = ...
    print(value, select("#", ...), (true and describe)(first))
end

local items = { false, true, 0, "", data, callback }
for _, value2 in items do
    for index = 0, 4 do
        emit("false-default", (true and choose)(value2, index))
        emit("nil-default", (true and chooseNil)(value2, index))
    end
end
for i = 0, 4 do
    emit("nil-test", (true and choose)(nil, i))
    emit("nil-test-default", (true and chooseNil)(nil, i))
    emit("nan", (true and chooseTrue)(0 / 0, 1, i))
    emit("ordered", (true and chooseTrue)(-1, 1, i))
    emit("reversed", (true and chooseTrue)(2, 1, i))
end

local function __lt(left, right)
    (table.insert)(list, "compare:" .. left.value .. ":" .. right.value)
    return left.value < right.value
end

local data2 = { __lt = 0 }
data2["__lt"] = __lt
local first = setmetatable({ value = 1 }, data2)
local second = setmetatable({ value = 2 }, data2)
emit("meta-yes", (true and chooseTrue)(first, second, 3))
emit("meta-no", (true and chooseTrue)(second, first, 3))
local reads: number = 0

local function inspect(entry)
    return entry ~= nil and entry.ready ~= nil
end

local setmetatable2 = setmetatable

local function __index(_, key): boolean
    reads += 1;
    (table.insert)(list, "read:" .. key)
    return false
end

local data3 = { __index = 0 }
data3["__index"] = __index
local entry = setmetatable2({}, data3)
emit("read-present", (true and inspect)(entry))
emit("read-absent", (true and inspect)(nil))
print("reads", reads)
print((table.concat)(list, ","))
