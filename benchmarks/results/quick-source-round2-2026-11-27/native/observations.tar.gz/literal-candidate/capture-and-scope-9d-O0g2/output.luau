-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:11Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function make(flag: boolean)
    local result: boolean = false
    if flag then
        result = 7
    end
    local function read()
        return result
    end;

    (table.insert)(list, read)
    return read
end

local first = (true and make)(true)
local second = (true and make)(true)
local third = (true and make)(false)
local print2 = print
local list2 = {}
print2("identity", first == second, second == third, first(), second(), third())
local data = { [first] = "first", [second] = "second", [third] = "third" }
print("keys", data[first], data[second], data[third])

local function observed(flag: boolean)
    local result2: boolean = false
    local function watch(): boolean
        (table.insert)(list2, "watch:" .. tostring(result2))
        result2 = "mutated"
        return flag
    end

    if (true and watch)() then
        result2 = nil
    end
    return result2
end

print("observed", (true and observed)(false), (true and observed)(true))

local function shadow(flag: boolean): string
    local value: string = "outer"
    local result2 = if flag then "inner" else false;
    (table.insert)(list2, "inner:" .. tostring(result2))
    return value
end

print("scope", (true and shadow)(false), (true and shadow)(true))

local function initialize()
    (table.insert)(list2, "initialize")
    return { tag = "initial" }
end

local function decide(flag: boolean): boolean
    (table.insert)(list2, "test:" .. tostring(flag))
    return flag
end

local function choose(flag: boolean)
    local result2 = (true and initialize)()
    if (true and decide)(flag) then
        result2 = "replacement"
    end
    return type(result2)
end

print("default-effects", (true and choose)(false), (true and choose)(true))

local function closures(flag: boolean)
    local result7 = nil
    if flag then
        result7 = function()
            return "named"
        end

    end
    return result7
end

local closure = (true and closures)(true)
print("creation", (debug.info)(closure, "n"), closure(), (true and closures)(false))
print("saved", list[1](), list[2](), list[3]())
print((table.concat)(list2, ","))
