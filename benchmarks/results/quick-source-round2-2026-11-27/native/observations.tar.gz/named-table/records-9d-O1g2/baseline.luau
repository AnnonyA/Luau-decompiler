-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:57Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(seed: number)
    local state = seed
    local function read(delta)
        local previous = state
        state += delta
        return previous, state, nil
    end

    return { read = read }
end

local value = (true and packet)(4)
local second = (true and packet)(4)
print(debug.info(value.read, "n"), value.read == second.read)
print(value.read(3))
print(value.read(2))
print(second.read(1))

local function stable()
    local tbl = {}
    function tbl.tag()
        return 91
    end

    return tbl
end

local value2 = (true and stable)()
local b = (true and stable)()
local tag = value2.tag
local print2 = print
local value3 = debug.info(value2.tag, "n")
local tag2 = value2.tag
local data = { [tag] = "saved" }
print2(value3, tag2 == b.tag, data[b.tag], value2.tag())
local list = {}
for index = 1, 3 do
    local tbl = {}
    function tbl.take()
        return index
    end

    list[index] = tbl
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
