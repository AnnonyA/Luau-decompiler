-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:55Z
-- Luau bytecode version: 14 | Luau type version: 3

local print2 = print
local info = debug.info
local tbl = {}

function tbl.read()
    return "outer"
end

print2("outer", info(tbl.read, "n"))

local function packet()
    local tbl = {}
    function tbl.values(...)
        return select("#", ...), ...
    end

    return tbl
end

local print3 = print
local info2 = debug.info
local tbl2 = {}

function tbl2.values(...)
    return select("#", ...), ...
end

print3(info2(tbl2.values, "n"), (true and tbl2.values)(1, nil, 3))
print((true and tbl2.values)())

local function sum(n)
    return if n == 0 then 0 else n + sum(n - 1)
end

local print4 = print
local value = 4 + (true and sum)(3)
local info3 = debug.info
local data = { sum = sum }
print4(value, info3(data.sum, "n"))
local print5 = print
local info4 = debug.info
local data2 = {}
data2.alias = function()
    return 17
end

print5(17, info4(data2.alias, "n"))
