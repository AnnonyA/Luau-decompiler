-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:57Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(p)
    local total = p
    local read
    function read(p)
        local value = total
        total += p
        return value, total, nil
    end

    return { read = read }
end

local sharedCounter: number = 4
local read
function read(p)
    local value = sharedCounter
    sharedCounter += p
    return value, sharedCounter, nil
end

local data = { read = read }
local sharedCounter2: number = 4

local function read2(p)
    local value = sharedCounter2
    sharedCounter2 += p
    return value, sharedCounter2, nil
end

local data2 = { read = read2 }
print(debug.info(data.read, "n"), data.read == data2.read)
print((true and data.read)(3))
print((true and data.read)(2))
print((true and data2.read)(1))

local function stable()
    local tbl = {}
    function tbl.tag()
        return 91
    end

    return tbl
end

local function sharedFunctionFactory(...)
    return function()
        return 91
    end
end

local sharedFunction = sharedFunctionFactory()
local closureValue = sharedFunctionFactory()
local data3 = { tag = sharedFunction }
local tag = data3.tag
local print2 = print
local value = debug.info(data3.tag, "n")
local tag2 = data3.tag
local data4 = { tag = closureValue }
local data5 = { [tag] = "saved" }
print2(value, tag2 == data4.tag, data5[data4.tag], (true and data3.tag)())
local list = {}
for index = 1, 3 do
    local tbl = {}
    function tbl.take()
        return index
    end

    list[index] = tbl
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
