-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:54Z
-- Luau bytecode version: 14 | Luau type version: 3

local function environment()
    local object = setmetatable({ marker = "changed" }, { __index = getfenv(1) })
    local function read()
        return marker
    end

    local function alter(): string
        setfenv(2, object)
        return "effect"
    end

    local data = { before = (true and alter)(), read = read }
    return (true and data.read)(), data.before, debug.info(data.read, "n")
end

print((true and environment)())
local sharedCounter: number = 3
local list = {}

local function observe()
    list[#list + 1] = sharedCounter
    sharedCounter += 10
    return sharedCounter
end

local function __index()
    list[#list + 1] = sharedCounter
    sharedCounter += 100
    return sharedCounter
end

local data = { __index = 0 }
data.__index = __index
local value = setmetatable({}, data)

local function take()
    return sharedCounter
end

local field = (true and observe)()
local value2 = value.value
local print2 = print
local data2 = { first = field, middle = value2, take = take }
print2(data2.first, data2.middle, (true and data2.take)(), debug.info(data2.take, "n"), table.concat(list, ","))
