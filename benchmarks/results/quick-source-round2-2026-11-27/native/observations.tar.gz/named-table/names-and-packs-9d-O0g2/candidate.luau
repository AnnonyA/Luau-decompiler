-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:55Z
-- Luau bytecode version: 14 | Luau type version: 3

local record: string = "outer"

local function read(): string
    return record
end

local print2 = print
local data = { read = read }
print2((true and data.read)(), (debug.info)(data.read, "n"))

local function packet()
    return {
        values = function(...)
        return select("#", ...), ...
    end,
    }
end

local p = (true and packet)()
print((debug.info)(p.values, "n"), p.values(1, nil, 3))
print(p.values())

local function sum(n)
    return if n == 0 then 0 else n + sum(n - 1)
end

local print3 = print
local data2 = { sum = sum }
print3((true and data2.sum)(4), (debug.info)(data2.sum, "n"))

local function original(): number
    return 17
end

local print4 = print
local data3 = { alias = original }
print4((true and data3.alias)(), (debug.info)(data3.alias, "n"))
