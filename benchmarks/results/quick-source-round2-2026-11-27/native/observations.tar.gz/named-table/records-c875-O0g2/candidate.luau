-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:58Z
-- Luau bytecode version: 14 | Luau type version: 3

local function packet(seed: number)
    local state = seed
    return {
        read = function(delta)
        local previous = state
        state += delta
        return previous, state, nil
    end,
    }
end

local first, second = (true and packet)(4), (true and packet)(4)
print((debug.info)(first.read, "n"), first.read == second.read)
print(first.read(3))
print(first.read(2))
print(second.read(1))

local function stable()
    return {
        tag = function()
        return 91
    end,
    }
end

local a, b = (true and stable)(), (true and stable)()
local tag2 = a.tag
local print2 = print
local value = (debug.info)(a.tag, "n")
local tag3 = a.tag
local data = { [tag2] = "saved" }
print2(value, tag3 == b.tag, data[b.tag], a.tag())
local list = {}
for index = 1, 3 do
    list[index] = {
        take = function()
        return index
    end,
    }
end
print(list[1].take(), list[2].take(), list[3].take(), list[1].take == list[2].take)
