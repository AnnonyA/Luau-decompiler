-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:30:52Z
-- Luau bytecode version: 14 | Luau type version: 3

local function environment()
    local previous = getfenv(1)
    local changed = setmetatable({ marker = "changed" }, { __index = previous })
    local function read()
        return marker
    end

    local function alter(): string
        setfenv(2, changed)
        return "effect"
    end

    local data = { before = (true and alter)(), read = read }
    return (true and data.read)(), data.before, (debug.info)(data.read, "n")
end

print((true and environment)())
local state: number = 3
local list = {}

local function observe()
    list[#list + 1] = state
    state += 10
    return state
end

local setmetatable2 = setmetatable

local function __index()
    list[#list + 1] = state
    state += 100
    return state
end

local data = { __index = 0 }
data["__index"] = __index
local proxy = setmetatable2({}, data)

local function take()
    return state
end

local field = (true and observe)()
local value = proxy.value
local print2 = print
local data2 = { first = field, middle = value, take = take }
print2(data2.first, data2.middle, (true and data2.take)(), (debug.info)(data2.take, "n"), (table.concat)(list, ","))
