from pathlib import Path
import collections,concurrent.futures,hashlib,json,shutil,subprocess,os
ROOT=Path('/workspace/scratch/1c4124dc88e4');REFS=Path('/workspace/scratch/eb5e4be57451');REPO=ROOT/'Luau-decompiler'
PREV=ROOT/'measurements/integrated-native-expressions-eba3c997';OUT=ROOT/'measurements/integrated-closure-names-eba3c997';OUT.mkdir(exist_ok=False)
DIST=PREV/'engine/dist';BASE=PREV/'baseline-dist';NODE='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(p):return {str(q.relative_to(p)):sha(q) for q in sorted(p.rglob('*')) if q.is_file()}
proof=json.loads((PREV/'snapshot.json').read_text());assert inventory(DIST)==proof['engineDist'];assert inventory(BASE)==proof['baselineDist'];assert inventory(REPO/'dist')==proof['engineDist']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==proof['commit']
FIX=OUT/'authored-inputs';shutil.copytree(REPO/'tests/fixtures/closure-debug-preservation',FIX)
m=json.loads((FIX/'manifest.json').read_text())
for s in m['sources']:assert sha(FIX/s['path'])==s['sha256']
for r in m['inputs']:assert sha(FIX/r['path'])==r['sha256']
REVIEW=ROOT/'closure-name-review';first=json.loads((REVIEW/'summary.json').read_text());shutil.copy2(REVIEW/'summary.json',OUT/'first-allocation-summary.json')
for name in ['allocation.luau','run-bytecode.cpp']:shutil.copy2(REVIEW/name,OUT/name)
pins={'9d':REFS/'reference-luau-ci','c875':REFS/'reference-luau'}
receipts={}
for pin,path in pins.items():
 receipts[pin]={'revision':subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip(),'compilerSha256':sha(path/'build/release/luau-compile'),'nativeHostSha256':sha(REFS/f'quality-research/v2-call-boundary-probe/run-bytecode-{pin}'),'gcHostSha256':sha(REVIEW/f'run-bytecode-{pin}')}
 assert receipts[pin]['compilerSha256']==first['pins'][pin]['compilerSha256'];assert receipts[pin]['gcHostSha256']==first['pins'][pin]['hostSha256']
invalid=[];gcrows=[]
for r in first['rows']:
 pin,profile=r['pin'],r['profile'];old=REVIEW/f'{pin}-{profile}';bc=old/'original.luauc';assert sha(bc)==r['originalBytecodeSha256']
 if profile.startswith('O0'):
  target=OUT/'invalid-originals'/f'{pin}-{profile}';target.mkdir(parents=True)
  for name in ['original.luauc','original.stdout','original.stderr','commands.json']:shutil.copy2(old/name,target/name)
  cmds=json.loads((old/'commands.json').read_text());orig=next(c for c in cmds if c['stdout']=='original.stdout');assert orig['exitCode']!=0
  invalid.append({'pin':pin,'profile':profile,'originalValid':False,'firstOriginalExitCode':orig['exitCode'],'originalBytecodeSha256':sha(bc),'candidateExecuted':False,'countedInPassTotal':False})
 else:
  target=OUT/'allocation-inputs'/f'{pin}-{profile}.luauc';target.parent.mkdir(exist_ok=True);shutil.copy2(bc,target)
  gcrows.append({'pin':pin,'profile':profile,'path':target.name,'sha256':sha(target),'source':'allocation.luau'})
inputs_before={'authored':inventory(FIX),'allocation':inventory(OUT/'allocation-inputs')}
for folder in [FIX,OUT/'allocation-inputs',OUT/'invalid-originals']:
 for p in folder.rglob('*'):os.chmod(p,0o555 if p.is_dir() else 0o444)
 os.chmod(folder,0o555)
def run(row,group):
 pin,profile=row['pin'],row['profile'];source=FIX/row['path'] if group=='homonymous' else OUT/'allocation-inputs'/row['path'];folder=OUT/group/Path(row['path']).stem;folder.mkdir(parents=True)
 host=REFS/f'quality-research/v2-call-boundary-probe/run-bytecode-{pin}' if group=='homonymous' else REVIEW/f'run-bytecode-{pin}'
 commands=[]
 def exe(command,label):
  command=list(map(str,command));p=subprocess.run(command,capture_output=True,timeout=30)
  (folder/(label+'.stdout')).write_bytes(p.stdout);(folder/(label+'.stderr')).write_bytes(p.stderr);commands.append({'command':command,'exitCode':p.returncode,'stdout':label+'.stdout','stderr':label+'.stderr'});return p
 original=exe([host,source],'original');assert original.returncode==0
 results={}
 for variant,dist in [('baseline',BASE),('candidate',DIST)]:
  dec=exe([NODE,dist/'cli.js','decompile',source],variant+'-decompile');src=folder/(variant+'.luau');src.write_bytes(dec.stdout)
  comp=exe([pins[pin]/'build/release/luau-compile','--binary','-O'+profile[1],'-g'+profile[3],src],variant+'-compile');bc=folder/(variant+'.luauc');bc.write_bytes(comp.stdout);actual=exe([host,bc],variant+'-actual')
  results[variant]={'match':original.returncode==dec.returncode==comp.returncode==actual.returncode==0 and original.stdout==actual.stdout and original.stderr==actual.stderr,'exitCodes':[original.returncode,dec.returncode,comp.returncode,actual.returncode],'stdout':actual.stdout.decode(),'stderr':actual.stderr.decode(),'sourceSha256':sha(src),'bytecodeSha256':sha(bc)}
 (folder/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return {'group':group,'input':row['path'],'pin':pin,'profile':profile,'originalBytecodeSha256':sha(source),'original':{'exitCode':original.returncode,'stdout':original.stdout.decode(),'stderr':original.stderr.decode()},'variants':results}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 rows=list(pool.map(lambda item:run(*item),[(r,'homonymous') for r in m['inputs']]+[(r,'allocation') for r in gcrows]))
checks={'candidateSnapshotUnchanged':inventory(DIST)==proof['engineDist'],'baselineSnapshotUnchanged':inventory(BASE)==proof['baselineDist'],'rootDistUnchanged':inventory(REPO/'dist')==proof['engineDist'],'authoredInputsUnchanged':inventory(FIX)==inputs_before['authored'],'allocationInputsUnchanged':inventory(OUT/'allocation-inputs')==inputs_before['allocation']};assert all(checks.values())
counts={}
for group in ['homonymous','allocation']:
 subset=[r for r in rows if r['group']==group];counts[group]={'total':len(subset),'originalValid':len(subset),'baselinePass':sum(r['variants']['baseline']['match'] for r in subset),'candidatePass':sum(r['variants']['candidate']['match'] for r in subset)}
summary={'commit':proof['commit'],'node':subprocess.check_output([NODE,'--version'],text=True).strip(),'engineSnapshot':str(DIST),'engineJsTreeSha256':proof['engineJsTreeSha256'],'baselineSnapshot':str(BASE),'baselineJsTreeSha256':proof['baselineJsTreeSha256'],'treeHashAlgorithm':proof['treeHashAlgorithm'],'pins':receipts,'sourceHashes':{s['path']:s['sha256'] for s in m['sources']}|{'allocation.luau':sha(OUT/'allocation.luau'),'gcHostSource':sha(OUT/'run-bytecode.cpp')},'counts':counts,'invalidOriginals':invalid,'immutabilityChecks':checks,'results':rows}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(Path(__file__),OUT/'reproduce.py')
(OUT/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(OUT))+'\n' for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({k:v for k,v in summary.items() if k not in ['results','pins','invalidOriginals']},indent=2));print('Invalid original O0 profiles preserved and excluded:',len(invalid))
