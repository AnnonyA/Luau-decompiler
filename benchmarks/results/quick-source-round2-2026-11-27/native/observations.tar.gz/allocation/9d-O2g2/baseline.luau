-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:32:32Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make()
    local function tag(): string
        return "value"
    end

    return tag
end

local before = gcinfo()
local result
for index = 1, 200 do
    local first
    local tag2
    local closureStage: number = 1
    while true do
        local function loadedClosure(): string
            return "value"
        end

        if closureStage ~= 1 then
            tag2 = loadedClosure
            break
        end
        local tag = loadedClosure
        first = tag
        local _ = gcinfo()
        closureStage = 2
    end
    local second = tag2
    result = first == second
    assert(result)
end
local after = gcinfo()
print("allocation", after - before)
