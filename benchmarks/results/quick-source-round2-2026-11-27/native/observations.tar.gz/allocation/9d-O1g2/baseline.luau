-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:32:32Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make()
    local function tag(): string
        return "value"
    end

    return tag
end

local before = gcinfo()
local result
for index = 1, 200 do
    local first = (true and make)()
    local _ = gcinfo()
    local second = (true and make)()
    result = first == second
    assert(result)
end
local after = gcinfo()
print("allocation", after - before)
