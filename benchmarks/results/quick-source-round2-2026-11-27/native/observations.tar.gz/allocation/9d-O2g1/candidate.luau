-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:32:32Z
-- Luau bytecode version: 14 | Luau type version: 3

local function make()
    local function tag(): string
        return "value"
    end

    return tag
end

local value = gcinfo()
local result
for index = 1, 200 do
    local tag
    local tag2
    local closureStage: number = 1
    while true do
        local loadedClosure
        do
            local function tag3(): string
                return "value"
            end

            loadedClosure = tag3
        end
        if closureStage ~= 1 then
            tag2 = loadedClosure
            break
        end
        tag = loadedClosure
        local _ = gcinfo()
        closureStage = 2
    end
    result = tag == tag2
    assert(result)
end
local value2 = gcinfo()
print("allocation", value2 - value)
