-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:12Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function make(flag)
    local result: boolean = false
    if flag then
        result = 7
    end
    local read
    function read()
        return result
    end

    table.insert(list, read)
    return read
end

local value: boolean = false
local value2
value2 = 7
local read
function read()
    return value2
end

table.insert(list, read)
local value3: boolean = false
local value4
value4 = 7

local function read2()
    return value4
end

table.insert(list, read2)
local value5
value5 = false

local function read3()
    return value5
end

table.insert(list, read3)
local print2 = print
local list2 = {}
print2("identity", read == read2, read2 == read3, read(), read2(), read3())
local data = { [read] = "first", [read2] = "second", [read3] = "third" }
print("keys", data[read], data[read2], data[read3])

local function observed(flag)
    local value: boolean = false
    local watch
    function watch()
        table.insert(list2, "watch:" .. tostring(value))
        value = "mutated"
        return flag
    end

    table.insert(list2, "watch:" .. tostring(value))
    value = "mutated"
    if flag then
        value = nil
    end
    return value
end

local print3 = print
local value6: boolean = false
local watch
function watch()
    table.insert(list2, "watch:" .. tostring(value6))
    value6 = "mutated"
    return false
end

table.insert(list2, "watch:" .. tostring(value6))
value6 = "mutated"
local value7 = value6
local value8: boolean = false

local function watch2(): boolean
    table.insert(list2, "watch:" .. tostring(value8))
    value8 = "mutated"
    return true
end

table.insert(list2, "watch:" .. tostring(value8))
value8 = "mutated"
value8 = nil
print3("observed", value7, value8)

local function shadow(flag): string
    local result2: boolean = false
    if flag then
        result2 = result2 or "inner"
    end
    table.insert(list2, "inner:" .. tostring(result2))
    return "outer"
end

local print4 = print
table.insert(list2, "inner:" .. tostring(false))
local value10: boolean = false
local value11 = value10 or "inner"
table.insert(list2, "inner:" .. tostring(value11))
print4("scope", "outer", "outer")

local function initialize()
    table.insert(list2, "initialize")
    return { tag = "initial" }
end

local function decide(flag)
    table.insert(list2, "test:" .. tostring(flag))
    return flag
end

local function choose(flag)
    table.insert(list2, "initialize")
    table.insert(list2, "test:" .. tostring(flag))
    local result2 = { tag = "initial" }
    if flag then
        result2 = "replacement"
    end
    return (type(result2))
end

local print5 = print
table.insert(list2, "initialize")
table.insert(list2, "test:" .. tostring(false))
local value12: string = type({ tag = "initial" })
table.insert(list2, "initialize")
table.insert(list2, "test:" .. tostring(true))
local data2 = { tag = "initial" }
print5("default-effects", value12, (type("replacement")))

local function closures(flag)
    local result6 = nil
    if flag then
        result6 = function()
            return "named"
        end

    end
    return result6
end

local closure = function(): string
    return "named"
end
print("creation", debug.info(closure, "n"), closure(), nil)
print("saved", list[1](), list[2](), list[3]())
print(table.concat(list2, ","))
