-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:14Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function make(p)
    local flag: boolean = false
    if p then
        flag = 7
    end
    local read
    function read()
        return flag
    end

    table.insert(list, read)
    return read
end

local value
value = 7
local read
function read()
    return value
end

table.insert(list, read)
local value2
value2 = 7

local function read2()
    return value2
end

table.insert(list, read2)
local value3
value3 = false

local function read3()
    return value3
end

table.insert(list, read3)
local print2 = print
local list2 = {}
print2("identity", read == read2, read2 == read3, read(), read2(), read3())
local data = { [read] = "first", [read2] = "second", [read3] = "third" }
print("keys", data[read], data[read2], data[read3])

local function observed(p)
    local flag: boolean = false
    local watch
    function watch()
        table.insert(list2, "watch:" .. tostring(flag))
        flag = "mutated"
        return p
    end

    table.insert(list2, "watch:" .. tostring(flag))
    flag = "mutated"
    if p then
        flag = nil
    end
    return flag
end

local print3 = print
local flag: boolean = false
local watch
function watch()
    table.insert(list2, "watch:" .. tostring(flag))
    flag = "mutated"
    return false
end

table.insert(list2, "watch:" .. tostring(flag))
flag = "mutated"
local value4 = flag
local flag2: boolean = false

local function watch2(): boolean
    table.insert(list2, "watch:" .. tostring(flag2))
    flag2 = "mutated"
    return true
end

table.insert(list2, "watch:" .. tostring(flag2))
flag2 = "mutated"
flag2 = nil
print3("observed", value4, flag2)

local function shadow(p): string
    local flag: boolean = false
    if p then
        flag = flag or "inner"
    end
    table.insert(list2, "inner:" .. tostring(flag))
    return "outer"
end

local print4 = print
table.insert(list2, "inner:" .. tostring(false))
local value5 = false or "inner"
table.insert(list2, "inner:" .. tostring(value5))
print4("scope", "outer", "outer")

local function initialize()
    table.insert(list2, "initialize")
    return { tag = "initial" }
end

local function decide(p)
    table.insert(list2, "test:" .. tostring(p))
    return p
end

local function choose(p)
    table.insert(list2, "initialize")
    table.insert(list2, "test:" .. tostring(p))
    local result = { tag = "initial" }
    if p then
        result = "replacement"
    end
    return (type(result))
end

local print5 = print
table.insert(list2, "initialize")
table.insert(list2, "test:" .. tostring(false))
local typeName: string = type({ tag = "initial" })
table.insert(list2, "initialize")
table.insert(list2, "test:" .. tostring(true))
local data2 = { tag = "initial" }
print5("default-effects", typeName, (type("replacement")))

local function closures(p)
    local result7 = nil
    if p then
        result7 = function()
            return "named"
        end

    end
    return result7
end

local function_ = function(): string
    return "named"
end
print("creation", debug.info(function_, "n"), function_(), nil)
print("saved", list[1](), list[2](), list[3]())
print(table.concat(list2, ","))
