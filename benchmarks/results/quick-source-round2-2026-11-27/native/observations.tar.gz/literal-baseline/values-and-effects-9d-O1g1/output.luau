-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:13Z
-- Luau bytecode version: 14 | Luau type version: 3

local function callback(): string
    return "callback"
end

local data = { tag = "object" }

local function describe(p)
    if p == data then
        return "object"
    end
    if p == callback then
        return "callback"
    end
    return tostring(p)
end

local list = {}

local function produce(p)
    table.insert(list, "produce:" .. p)
    if p == 0 then
        return
    end
    if p == 1 then
        return nil, "extra", false
    elseif p == 2 then
        return false, true
    elseif p == 3 then
        return data, "extra"
    else
        return callback, data, nil
    end
end

local function choose(p, p2)
    local flag: boolean = false
    if p then
        flag = (true and produce)(p2)
    end
    return flag
end

local function chooseNil(p, p2)
    local result = nil
    if p then
        result = (true and produce)(p2)
    end
    return result
end

local function chooseTrue(a, b, c)
    local flag: boolean = true
    if a < b then
        flag = (true and produce)(c)
    end
    return flag
end

local function emit(p, ...)
    local first = ...
    print(p, select("#", ...), (true and describe)(first))
end

local items = { false, true, 0, "", data, callback }
for _, value in items do
    for i = 0, 4 do
        emit("false-default", (true and choose)(value, i))
        emit("nil-default", (true and chooseNil)(value, i))
    end
end
for i2 = 0, 4 do
    emit("nil-test", (true and choose)(nil, i2))
    emit("nil-test-default", (true and chooseNil)(nil, i2))
    emit("nan", (true and chooseTrue)((0/0), 1, i2))
    emit("ordered", (true and chooseTrue)(-1, 1, i2))
    emit("reversed", (true and chooseTrue)(2, 1, i2))
end
local data2 = {}
data2.__lt = function(p, p2)
    table.insert(list, "compare:" .. p.value .. ":" .. p2.value)
    return p.value < p2.value
end

local value2 = setmetatable({ value = 1 }, data2)
local value3 = setmetatable({ value = 2 }, data2)
emit("meta-yes", (true and chooseTrue)(value2, value3, 3))
emit("meta-no", (true and chooseTrue)(value3, value2, 3))
local sharedCounter: number = 0

local function inspect(p)
    local flag: boolean = false
    if p ~= nil then
        flag = p.ready ~= nil
    end
    return flag
end

local function __index(p, p2): boolean
    sharedCounter += 1
    table.insert(list, "read:" .. p2)
    return false
end

local data3 = { __index = 0 }
data3.__index = __index
local value4 = setmetatable({}, data3)
emit("read-present", (true and inspect)(value4))
emit("read-absent", (true and inspect)(nil))
print("reads", sharedCounter)
print(table.concat(list, ","))
