-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:14Z
-- Luau bytecode version: 14 | Luau type version: 3

local list = {}

local function make(p: boolean)
    local flag: boolean = false
    if p then
        flag = 7
    end
    local function read()
        return flag
    end

    table.insert(list, read)
    return read
end

local callback = (true and make)(true)
local callback2 = (true and make)(true)
local callback3 = (true and make)(false)
local print2 = print
local list2 = {}
print2("identity", callback == callback2, callback2 == callback3, callback(), callback2(), callback3())
local data = { [callback] = "first", [callback2] = "second", [callback3] = "third" }
print("keys", data[callback], data[callback2], data[callback3])

local function observed(p: boolean)
    local flag: boolean = false
    local function watch(): boolean
        table.insert(list2, "watch:" .. tostring(flag))
        flag = "mutated"
        return p
    end

    if (true and watch)() then
        flag = nil
    end
    return flag
end

print("observed", (true and observed)(false), (true and observed)(true))

local function shadow(p: boolean): string
    local flag: boolean = false
    if p then
        flag = flag or "inner"
    end
    table.insert(list2, "inner:" .. tostring(flag))
    return "outer"
end

print("scope", (true and shadow)(false), (true and shadow)(true))

local function initialize()
    table.insert(list2, "initialize")
    return { tag = "initial" }
end

local function decide(p: boolean): boolean
    table.insert(list2, "test:" .. tostring(p))
    return p
end

local function choose(p: boolean)
    local result = (true and initialize)()
    if (true and decide)(p) then
        result = "replacement"
    end
    return type(result)
end

print("default-effects", (true and choose)(false), (true and choose)(true))

local function closures(p: boolean)
    local result7 = nil
    if p then
        result7 = function()
            return "named"
        end

    end
    return result7
end

local callback4 = (true and closures)(true)
print("creation", debug.info(callback4, "n"), callback4(), (true and closures)(false))
print("saved", list[1](), list[2](), list[3]())
print(table.concat(list2, ","))
