-- [[ annonya.github.io ]] v0.2.0 | decompiled at 2026-11-28T00:31:13Z
-- Luau bytecode version: 14 | Luau type version: 3

local function callback(): string
    return "callback"
end

local data = { tag = "object" }

local function describe(value)
    return if value == data then "object" elseif value == callback then "callback" else tostring(value)
end

local list = {}

local function produce(mode)
    table.insert(list, "produce:" .. mode)
    if mode == 0 then
        return
    end
    if mode == 1 then
        return nil, "extra", false
    elseif mode == 2 then
        return false, true
    elseif mode == 3 then
        return data, "extra"
    else
        return callback, data, nil
    end
end

local function choose(test, mode)
    local result: boolean = false
    if test then
        table.insert(list, "produce:" .. mode)
        if mode == 0 then
            return nil
        elseif mode == 1 then
            return nil
        elseif mode == 2 then
            return false
        elseif mode == 3 then
            return data
        end
        result = callback
        return result
    end
    return result
end

local function chooseNil(test, mode)
    local result2 = nil
    if test then
        table.insert(list, "produce:" .. mode)
        if mode == 0 then
            local result = nil
            return result
        elseif mode == 1 then
            return nil
        elseif mode == 2 then
            return false
        elseif mode == 3 then
            return data
        end
        result2 = callback
        return result2
    end
    return result2
end

local function chooseTrue(left, right, mode)
    local result2: boolean = true
    if left < right then
        table.insert(list, "produce:" .. mode)
        if mode == 0 then
            local result = nil
            return result
        elseif mode == 1 then
            return nil
        elseif mode == 2 then
            return false
        elseif mode == 3 then
            return data
        end
        result2 = callback
        return result2
    end
    return result2
end

local function emit(value, ...)
    local first = ...
    print(value, select("#", ...), if first == data then "object" else if first == callback then "callback" else tostring(first))
end

local items = { false, true, 0, "", data, callback }
for _, value2 in items do
    local result2
    for index = 0, 4 do
        local result3: boolean = false
        if value2 then
            table.insert(list, "produce:" .. index)
            result3 = if index == 0 then nil elseif index == 1 then nil elseif index == 2 then false elseif index == 3 then data else callback
        end
        emit("false-default", result3)
        result2 = nil
        if value2 then
            table.insert(list, "produce:" .. index)
            result2 = if index == 0 then nil elseif index == 1 then nil elseif index == 2 then false elseif index == 3 then data else callback
        end
        emit("nil-default", result2)
    end
end
local result4
for i = 0, 4 do
    emit("nil-test", false)
    emit("nil-test-default", nil)
    emit("nan", true)
    table.insert(list, "produce:" .. i)
    result4 = if i == 0 then nil else if i == 1 then nil elseif i == 2 then false elseif i == 3 then data else callback
    emit("ordered", result4)
    emit("reversed", true)
end
local data2 = {}
data2.__lt = function(left, right)
    table.insert(list, "compare:" .. left.value .. ":" .. right.value)
    return left.value < right.value
end

local left = setmetatable({ value = 1 }, data2)
local right = setmetatable({ value = 2 }, data2)
local result5: boolean = true
if left < right then
    table.insert(list, "produce:" .. 3)
    result5 = data
end
emit("meta-yes", result5)
local result6: boolean = true
if right < left then
    table.insert(list, "produce:" .. 3)
    result6 = data
end
emit("meta-no", result6)
local reads: number = 0

local function inspect(entry)
    local result2: boolean = false
    if entry ~= nil then
        result2 = entry.ready ~= nil
    end
    return result2
end

local function __index(_, key): boolean
    reads += 1
    table.insert(list, "read:" .. key)
    return false
end

local entry = setmetatable({}, { __index = __index })
local result7: boolean = false
if entry ~= nil then
    result7 = entry.ready ~= nil
end
emit("read-present", result7)
emit("read-absent", false)
print("reads", reads)
print(table.concat(list, ","))
