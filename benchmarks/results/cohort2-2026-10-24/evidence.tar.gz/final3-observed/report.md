# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
2 programs; 6 profiles; 72 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| query-planner | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| query-planner | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| query-planner | 2 | MATCH | NO MEDIDO | NO MEDIDO |
| reactive-simulation | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| reactive-simulation | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| reactive-simulation | 2 | MATCH | NO MEDIDO | NO MEDIDO |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| query-planner/O0 | annony | 12/12 | 0.795 | 196.6 |
| query-planner/O0 | lunaux | — | — | — |
| query-planner/O0 | luaexpert | — | — | — |
| query-planner/O1 | annony | 12/12 | 0.823 | 211.0 |
| query-planner/O1 | lunaux | — | — | — |
| query-planner/O1 | luaexpert | — | — | — |
| query-planner/O2 | annony | 12/12 | 0.667 | 287.1 |
| query-planner/O2 | lunaux | — | — | — |
| query-planner/O2 | luaexpert | — | — | — |
| reactive-simulation/O0 | annony | 12/12 | 0.838 | 197.7 |
| reactive-simulation/O0 | lunaux | — | — | — |
| reactive-simulation/O0 | luaexpert | — | — | — |
| reactive-simulation/O1 | annony | 12/12 | 0.839 | 202.0 |
| reactive-simulation/O1 | lunaux | — | — | — |
| reactive-simulation/O1 | luaexpert | — | — | — |
| reactive-simulation/O2 | annony | 12/12 | 0.710 | 222.8 |
| reactive-simulation/O2 | lunaux | — | — | — |
| reactive-simulation/O2 | luaexpert | — | — | — |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- query-planner/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- query-planner/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- query-planner/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- query-planner/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- query-planner/O2 lunaux: NO MEDIDO — external requests disabled; no cached response
- query-planner/O2 luaexpert: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O2 lunaux: NO MEDIDO — external requests disabled; no cached response
- reactive-simulation/O2 luaexpert: NO MEDIDO — external requests disabled; no cached response
