# Three-engine comparison against authored originals

Compiler revision (declared): 9d7748a4f324213a18cb8283fa2a77c330225fa0. Profiles: O0/O1/O2, debug level 1.
3 programs; 9 profiles; 108 input executions per measured engine. MATCH means identical observed traces, not universal equivalence.
No ranking is assigned to unmeasured engines. Structural/token metrics are secondary lexical diagnostics, not semantic scores.

| Program | O | AnnonyA | LunaUX | Lua.Expert |
|---|---:|---|---|---|
| protocol-router | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| protocol-router | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| protocol-router | 2 | MATCH | NO MEDIDO | NO MEDIDO |
| transaction-store | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| transaction-store | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| transaction-store | 2 | MATCH | NO MEDIDO | NO MEDIDO |
| workflow-scheduler | 0 | MATCH | NO MEDIDO | NO MEDIDO |
| workflow-scheduler | 1 | MATCH | NO MEDIDO | NO MEDIDO |
| workflow-scheduler | 2 | MATCH | NO MEDIDO | NO MEDIDO |

## Evidence

| Program/profile | Engine | Matching inputs | Normalized token similarity | Time (ms) |
|---|---|---:|---:|---:|
| protocol-router/O0 | annony | 12/12 | 0.870 | 183.0 |
| protocol-router/O0 | lunaux | — | — | — |
| protocol-router/O0 | luaexpert | — | — | — |
| protocol-router/O1 | annony | 12/12 | 0.853 | 179.9 |
| protocol-router/O1 | lunaux | — | — | — |
| protocol-router/O1 | luaexpert | — | — | — |
| protocol-router/O2 | annony | 12/12 | 0.745 | 263.4 |
| protocol-router/O2 | lunaux | — | — | — |
| protocol-router/O2 | luaexpert | — | — | — |
| transaction-store/O0 | annony | 12/12 | 0.854 | 213.9 |
| transaction-store/O0 | lunaux | — | — | — |
| transaction-store/O0 | luaexpert | — | — | — |
| transaction-store/O1 | annony | 12/12 | 0.810 | 186.9 |
| transaction-store/O1 | lunaux | — | — | — |
| transaction-store/O1 | luaexpert | — | — | — |
| transaction-store/O2 | annony | 12/12 | 0.783 | 197.3 |
| transaction-store/O2 | lunaux | — | — | — |
| transaction-store/O2 | luaexpert | — | — | — |
| workflow-scheduler/O0 | annony | 12/12 | 0.754 | 270.4 |
| workflow-scheduler/O0 | lunaux | — | — | — |
| workflow-scheduler/O0 | luaexpert | — | — | — |
| workflow-scheduler/O1 | annony | 12/12 | 0.784 | 239.8 |
| workflow-scheduler/O1 | lunaux | — | — | — |
| workflow-scheduler/O1 | luaexpert | — | — | — |
| workflow-scheduler/O2 | annony | 12/12 | 0.739 | 299.3 |
| workflow-scheduler/O2 | lunaux | — | — | — |
| workflow-scheduler/O2 | luaexpert | — | — | — |

Times are single observations: HTTP elapsed time includes transport; local time measures decompilation. They are not a fair throughput benchmark.
All sources, exact bytecode, hashes, request/response records, traces and lexical counts are in report.json and sibling artifacts.
Binding/capture correctness and lost effects are exercised by input-specific traces; static scope equivalence is not established.

- protocol-router/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- protocol-router/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- protocol-router/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- protocol-router/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- protocol-router/O2 lunaux: NO MEDIDO — external requests disabled; no cached response
- protocol-router/O2 luaexpert: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O2 lunaux: NO MEDIDO — external requests disabled; no cached response
- transaction-store/O2 luaexpert: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O0 lunaux: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O0 luaexpert: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O1 lunaux: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O1 luaexpert: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O2 lunaux: NO MEDIDO — external requests disabled; no cached response
- workflow-scheduler/O2 luaexpert: NO MEDIDO — external requests disabled; no cached response
